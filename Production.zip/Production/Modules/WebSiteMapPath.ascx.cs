﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class WebSiteMapPath : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        //設定home圖示
        imgHome.ImageUrl = "~/App_Themes/" + Page.Theme + "/images/home.png";

        /*
        if (!Page.IsPostBack)
        {
            string siteMap = string.Empty;
            string strHome = "<a href='" + ResolveClientUrl("~/ManageMain.aspx") + "'>Home</a>";

            DataRow rowMenu = BLL.GetMenuInfo("", ServerInfo.GetCurrentURL());
            if (rowMenu != null)
            {
                string strMenuName = rowMenu["MenuName"].ToString();
                string strParentNo = rowMenu["ParentNo"].ToString();

                siteMap = "<span>" + strMenuName + "</span>";
                DataRow rowSubMenu = BLL.GetMenuInfo(strParentNo,"");
                if (module != null)
                {
                    if (string.IsNullOrEmpty(module.MenuLink))
                        siteMap = "<a href=\"javascript:void(0);\">" + module.MenuName + "</a> >> " + siteMap;
                    else
                        siteMap = "<a href=\"" + ResolveClientUrl("~" + module.MenuLink) + "\">" + module.MenuName + "</a> >> " + siteMap;
                    MSNCMS.Model.Menu subSystem = menuContent.GetMenuInfoByMenuNo(module.ParentNo);
                    if (subSystem != null)
                    {
                        if (string.IsNullOrEmpty(subSystem.MenuLink))
                            siteMap = "<a href=\"javascript:void(0);\">" + subSystem.MenuName + "</a> >> " + siteMap;
                        else
                            siteMap = "<a href=\"" + ResolveClientUrl("~" + subSystem.MenuLink) + "\">" + subSystem.MenuName + "</a> >> " + siteMap;
                    }
                }
            }
            if (!string.IsNullOrEmpty(siteMap))
                siteMap = strHome + " >> " + siteMap;
            else
                siteMap = strHome;

            liSiteMapPath.Text = siteMap;
        }
        */
    }
}
