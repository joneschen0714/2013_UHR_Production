﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Net.Mail;
using System.IO;
using UHR;
using UHR.Util;

public partial class ERP_Customer : UHR.BasePage.BasePage
{
    private string M_公司別, CTRL;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_公司別 = Tool.CheckQueryString("company");
        CTRL = Tool.CheckQueryString("v");

        if (!IsPostBack)
        {
            ((DropDownList)gv.FindControl("ddlpagesizeselect")).Enabled = false;

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件
        string strCode = txtCode.Text.ToUpper().Trim();
        string strName = txtName.Text.ToUpper().Trim();

        //取得資料來源
        int recordCount;
        DataTable dt = BLL_ERP.GetCustomerList(M_公司別, strCode, strName, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("客戶代號", "客戶代號", false, 100, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客戶簡稱", "客戶簡稱", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客戶全名", "客戶全名", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            //組成Script回傳值語法
            string ResponseString = "";
            string[] Items = CTRL.Split(';');
            foreach (string Item in Items)
            {
                string[] SubItem = Item.Split('=');
                string Ctrl = SubItem[0];
                string Field = Uri.UnescapeDataString(SubItem[1]);

                string Value = rowView[Field].ToString().Trim();
                ResponseString += "$(parent.window.dialogArguments.window.document).find('#" + Ctrl + "').val('" + Value + "');";
            }

            e.Row.Attributes.Add("onclick", ResponseString + "WindowClose();");
        }
    }
}