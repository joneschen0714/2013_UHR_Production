﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using UHR;
using UHR.Authority;
using UHR.Util;

public partial class TabMenu : System.Web.UI.UserControl
{
    private string query = "";
    private bool isShowOther = true;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataRow rowMainMenu = BLL.GetMenuInfo("", ServerInfo.GetCurrentURL(), "Page");
            if (rowMainMenu == null) return;

            DataTable TabMenu = BLL.GetTabMenuInfo(rowMainMenu["GroupName"].ToString());

            bool isSuper = UserInfo.SessionState.IsSuper;
            string CurrentMenuNo = rowMainMenu["MenuNo"].ToString();

            string strMenu = "";
            foreach (DataRow row1 in TabMenu.Rows)
            {
                if (isSuper || UHR.BasePage.BasePage.CheckUserAuthority(row1["MenuNo"].ToString()))
                {
                    if (IsShowOther)
                    {
                        string strMenuLink1 = Convert.ToString(row1["MenuLink"]);
                        string strMenuIco1 = Convert.ToString(row1["MenuIco"]);
                        string strMenuName1 = Convert.ToString(row1["MenuName"]);
                        string strMenuNo1 = Convert.ToString(row1["MenuNo"]);
                        string strCssName = "";
                        string strScriptHref = "";

                        if (strMenuNo1 == CurrentMenuNo)
                        {
                            strCssName = "Tab_SelectedTopLevelTab";
                        }
                        else
                        {
                            strCssName = "Tab_TopLevelTab";

                            if (query.Trim() != "") { query = "?" + query; }
                            strScriptHref = string.Format("onclick=\"location.href='{0}'\"", ResolveUrl("~" + strMenuLink1 + query));
                        }

                        strMenu += string.Format("<td {0} class='{3}'><img class='beforeImg' src='{1}' align='absmiddle' />{2}</td>",
                                        strScriptHref,
                                        ResolveUrl("~" + strMenuIco1),
                                        strMenuName1,
                                        strCssName);
                    }
                }
            }

            if (strMenu != "") { liTabMenu.Text = string.Format("<div class='Tab_TopGroup'><table cellpadding='0' cellspacing='0' border='0'><tr>{0}</tr></table></div>", strMenu); }
        }
    }

    /// <summary>存取網址參數字串</summary>
    public string Query
    {
        get { return query; }
        set { query = value; }
    }

    /// <summary>是否顯示其他Tab</summary>
    public bool IsShowOther
    {
        get { return isShowOther; }
        set { isShowOther = value; }
    }
}