﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Net.Mail;
using System.IO;
using UHR;
using UHR.Util;

public partial class ERP_User : UHR.BasePage.BasePage
{
    string CTRL;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        CTRL = Tool.CheckQueryString("ctrl");

        if (!IsPostBack)
        {
            ((DropDownList)gv.FindControl("ddlpagesizeselect")).Enabled = false;

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件
        string strCHName = txtCHName.Text.Trim();
        string strDept = txtDept.Text.Trim();

        //取得資料來源
        int recordCount;
        DataTable dt = BLL_ERP.GetUserList(null, strCHName, strDept, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("員工代號", "員工代號", false, 80, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("姓名", "姓名", false, 80, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("英文全名", "英文全名", false, 100, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("部門名稱", "部門名稱", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            string Val = rowView["員工代號"].ToString().Trim();
            e.Row.Attributes.Add("onclick", "window.dialogArguments.document.getElementById('" + CTRL + "').value='" + Val + "'; window.close();");
        }
    }
}