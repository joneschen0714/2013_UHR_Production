﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MessageInfo : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        divMessage.Visible = false;
    }

    public void ShowMessage(bool isSuccess, string message)
    {
        if (!string.IsNullOrEmpty(message))
        {
            if (isSuccess)
            {
                liTitle.Text = string.Format("<font color=Blue><b>{0}</b></font>", "Success");
                liMessage.Text = string.Format("<p>{0}</p>", message);
            }
            else
            {
                liTitle.Text = string.Format("<font color=Red><b>{0}</b></font>", "Error");
                liMessage.Text = string.Format("<p>{0}</p>", message);
            }

            divMessage.Visible = true;
        }
        else
            divMessage.Visible = false;
    }
}
