﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Net.Mail;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web_Member : UHR.BasePage.BasePage
{
    public string CTRL, MUTIL;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        CTRL = Tool.CheckQueryString("ctrl");
        MUTIL = Tool.CheckQueryString("mutil");

        if (!IsPostBack)
        {
            //顯示按鈕區
            palButtons.Visible = (MUTIL == "Y");

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件
        string strMail = txtMail.Text.Trim();
        string strCompany = txtCompany.Text.Trim();

        //取得資料來源
        int recordCount;
        DataTable dt = BLL_UHRWeb.GetMemberInfo(null, null, strMail, strCompany, null, null, null, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("ID", "ID", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("姓名", "Name", false, 80, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("公司", "Company", false, 80, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("等級", "Level", false, 100, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("Email", "Email", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("啟用碼", "Enabled", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        if (MUTIL == "Y") { gv.AddColumn("選擇", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center); }

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strName = Convert.ToString(rowView["Name"]);

            //是否多選
            if (MUTIL == "N")
            {
                string strVal = strID + " - " + strName;
                e.Row.Attributes.Add("onclick", "ReturnSingleValue('" + strVal + "')");
            }
            else
            {
                TableCell tcSelect = gv.GetTableCell(e.Row, "選擇", false);
                tcSelect.Text = string.Format("<input type='checkbox' />"); //設定CheckBox
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }
}