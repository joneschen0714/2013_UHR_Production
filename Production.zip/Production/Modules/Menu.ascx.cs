﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Authority;

public partial class Menu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string MenuKey = "MSNCMS_MENU";
            object objMenu = Session[MenuKey];
            if (objMenu != null)
            {
                liMenu.Text = objMenu.ToString();
            }
            else
            {
                string strMenu = GetMenuString();
                Session.Add(MenuKey, strMenu);
                liMenu.Text = strMenu;
            }

            txtSelectMenuNo.Text = Convert.ToString(Session["SelectMainMenuNo"]);
        }
    }

    private string GetMenuString()
    {
        bool isSuper = UserInfo.SessionState.IsSuper;
        StringBuilder sbMenu = new StringBuilder();
        DataTable dtMenu = BLL.GetMenuList("0", "True"); //取得第一層選單資料

        //循序讀取第一層選單
        foreach (DataRow row in dtMenu.Rows)
        {
            //第一層變數
            string strMenuLink = row["MenuLink"].ToString();
            string strMenuIco = row["MenuIco"].ToString();
            string strMenuName = row["MenuName"].ToString();
            string strMenuNo = row["MenuNo"].ToString();

            //第二層選單資料
            string strMenu = "";
            int iSubCount = 0;
            DataTable dtSubMenu = BLL.GetMenuList(strMenuNo, "True");

            //循序讀取第二層選單
            foreach (DataRow row1 in dtSubMenu.Rows)
            {
                if (isSuper || UHR.BasePage.BasePage.CheckUserAuthority(row1["MenuNo"].ToString()))
                {
                    string strMenuLink1 = Convert.ToString(row1["MenuLink"]);
                    string strMenuIco1 = Convert.ToString(row1["MenuIco"]);
                    string strMenuName1 = Convert.ToString(row1["MenuName"]);
                    string strMenuNo1 = Convert.ToString(row1["MenuNo"]);

                    strMenu += string.Format("<li id='{3}' url='{0}'><img class='beforeImg' src='{1}' align='absmiddle' />{2}</li>", ResolveUrl("~" + strMenuLink1), ResolveUrl("~" + strMenuIco1), strMenuName1, strMenuNo1);
                    iSubCount++;
                }
            }

            if (iSubCount > 0)
                strMenu = string.Format("<div>" +
                                            "<table cellpadding='0' cellspacing='0' class='tbSystem'>" +
                                                "<tr>" +
                                                    "<td id='{2}' jTag='tdSystemText' class='tdSystemText' url='{4}'><img class='beforeImg' src='{3}' align='absmiddle' />{1}</td>" +
                                                    "<td jTag='tdSystemArrow' class='tdSystemArrow'></td>" +
                                                "</tr>" +
                                            "</table>" +
                                            "<ul class='ModuleMenuGroup'>{0}</ul>" +
                                        "</div>",
                            strMenu,
                            strMenuName,
                            strMenuNo,
                            ResolveUrl("~" + strMenuIco),
                            ResolveUrl("~" + strMenuLink));

            sbMenu.Append(strMenu);
        }
        return sbMenu.ToString();
    }

    protected void btnSelectMenu_Click(object sender, EventArgs e)
    {
        string strMenuNo = txtSelectMenuNo.Text;
        string strRedirect = txtRedirect.Text;

        Session.Add("SelectMainMenuNo", strMenuNo);
        Response.Redirect(strRedirect);
    }
}
