using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Data.SqlClient;
using UHR.Authority;

namespace UHR.BasePage
{
    public class BasePage : System.Web.UI.Page
    {
        public BasePage()
        {

        }

        protected override void OnPreInit(EventArgs e)
        {
            CheckUserLogin();
            this.Theme = GetThemeName();
        }

        //���o�˦�����
        protected string GetThemeName()
        {
            string themeName = "Default";
            return themeName;
        }

        //����ϥΪ̬O�_�n�J
        protected void CheckUserLogin()
        {
            if (!UserInfo.Exists)
            {
                Response.Redirect("~/Login.aspx");
            }
        }

        //�ˬd�v��
        public static bool CheckUserAuthority(string PopCode)
        {
            bool flag = false;
            Authority.UserInfo ui = Authority.UserInfo.SessionState;

            if (ui.IsSuper)
            {
                flag = true;
            }
            else
            {
                string strPopList = BLL.GetUserInfo("", ui.Account, "")["PopList"].ToString();
                string strGroupPopList = BLL.GetGroupInfo(ui.GroupNumber)["PopList"].ToString();

                if (strPopList.IndexOf(PopCode) >= 0 || strGroupPopList.IndexOf(PopCode) >= 0)
                    flag = true;
            }

            return flag;
        }
        public bool CheckAuthority(string PopCode)
        {
            return BasePage.CheckUserAuthority(PopCode);
        }

        //�]�wPageLoad��Script
        public void SetPageLoadScript(string _script)
        {
            string strScript = "<script type='text/javascript'>$(document).ready(function(){{ScriptContent}});</script>";
            strScript = strScript.Replace("{ScriptContent}", _script);

            LiteralControl liScript = new LiteralControl(strScript);
            Page.Header.Controls.Add(liScript);
        }

        //�]�w����Header��Css�˦�
        public void SetPageStyle(string _style)
        {
            string strStyle = "<style type=\"text/css\">" + _style + "</style>";
            Page.Header.Controls.Add(new LiteralControl(strStyle));
        }
    }
}