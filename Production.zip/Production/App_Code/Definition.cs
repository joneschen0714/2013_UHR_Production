﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class Definition
    {
        public Definition()
        {

        }

        /// <summary>取得管理後台連線字串</summary>
        public static string AuthConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["AuthConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP的Arclite公司別連線字串</summary>
        public static string ERPConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["ERPConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP的Uhrlamps公司別連線字串</summary>
        public static string UhrlampsConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["UhrlampsConnStr"].ConnectionString; }
        }

        /// <summary>取得UHR網站連線字串</summary>
        public static string UHRWebConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["UHRWebConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP Arclite的DB前置名稱</summary>
        public static string ERPDBName
        {
            get { return ConfigurationManager.AppSettings["ERPDBNAME"]; }
        }

        /// <summary>取得ERP UHRlamps的DB前置名稱</summary>
        public static string UHRlampsDBName
        {
            get { return ConfigurationManager.AppSettings["UHRlampsDBName"]; }
        }

        /// <summary>發信人顯示名稱</summary>
        public static string SendMailDisplayName
        {
            get { return ConfigurationManager.AppSettings["SendMailDisplayName"]; }
        }

        /// <summary>發信人信箱地址</summary>
        public static string SendMailFromAddress
        {
            get { return ConfigurationManager.AppSettings["SendMailFromAddress"]; }
        }
    }
}