﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR.Authority
{
    public class UserInfo
    {
        //私有變數
        private int _id = 0;
        private string _email = "";
        private string _account = "";
        private string _dutyid = "";
        private string _firstname = "";
        private string _lastname = "";
        private string _groupnumber = "";
        private bool _issuper = false;

        public UserInfo(object id, object email, object account, object dutyid, object firstname, object lastname, object groupnumber, object issuper)
        {
            _id = Convert.ToInt32(id);
            _email = Convert.ToString(email);
            _account = Convert.ToString(account);
            _dutyid = Convert.ToString(dutyid);
            _firstname = Convert.ToString(firstname);
            _lastname = Convert.ToString(lastname);
            _groupnumber = Convert.ToString(groupnumber);
            _issuper = (issuper.ToString() == "1");
        }

        //屬性
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        public string DutyID
        {
            get { return _dutyid; }
            set { _dutyid = value; }
        }
        public string FirstName
        {
            get { return _firstname; }
            set { _firstname = value; }
        }
        public string LastName
        {
            get { return _lastname; }
            set { _lastname = value; }
        }
        public string GroupNumber
        {
            get { return _groupnumber; }
            set { _groupnumber = value; }
        }
        public bool IsSuper
        {
            get { return _issuper; }
            set { _issuper = value; }
        }

        //公有函式
        public static UserInfo SessionState
        {
            get { return (UserInfo)HttpContext.Current.Session["UserInfo"]; }
            set { HttpContext.Current.Session.Add("UserInfo", value); }
        }
        public static bool Exists
        {
            get { return (HttpContext.Current.Session["UserInfo"] != null); }
        }
        public static void Remove()
        {
            if (Exists)
            {
                HttpContext.Current.Session.Remove("UserInfo");
            }
        }
    }
}