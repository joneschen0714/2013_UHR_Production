﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR.Util;

namespace UHR
{
    public class DAL_ERP
    {
        public DAL_ERP()
        {

        }

        /// <summary>取得客戶訂單的列表資料</summary>
        public static DataTable GetOrderList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TC053 [客戶名稱], TD003 [項次], TD004 [品號], TD008 [數量], b.TB201 [客戶商品描述] " +
                        "FROM COPTC c " +
                        "INNER JOIN COPTD d ON d.TD001=c.TC001 AND d.TD002=c.TC002 " +
                        "LEFT OUTER JOIN COPTB b ON b.TB001=d.TD017 AND b.TB002=d.TD018 AND b.TB003=d.TD019 " +
                        "WHERE c.TC001=@單別 AND c.TC002=@單號 AND c.TC027='Y' AND d.TD016 IN ('Y','N') " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>取得銷貨單的列表資料</summary>
        public static DataTable GetSellingList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TG007 [客戶名稱], TG023 [確認碼], TH003 [項次], TH004 [品號], TH008 [數量] " +
                        "FROM COPTG g " +
                        "INNER JOIN COPTH h ON h.TH001=g.TG001 AND h.TH002=g.TG002 " +
                        "WHERE g.TG001=@單別 AND g.TG002=@單號 " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>取得銷退單的列表資料</summary>
        public static DataTable GetReturnGoodsList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TI021 [客戶名稱], TI019 [確認碼], TJ003 [項次], TJ004 [品號], TJ050 [數量] " +
                        "FROM COPTI i " +
                        "INNER JOIN COPTJ j ON j.TJ001=i.TI001 AND j.TJ002=i.TI002 " +
                        "WHERE i.TI001=@單別 AND i.TI002=@單號 " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>取得借入單的列表資料</summary>
        public static DataTable GetBorrowList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TF015 [客戶名稱], TF020 [確認碼], TG003 [項次], TG004 [品號], TG009 [數量], TG019 [客戶商品描述] " +
                        "FROM INVTF f " +
                        "INNER JOIN INVTG g ON g.TG001=f.TF001 AND g.TG002=f.TF002 " +
                        "WHERE f.TF001=@單別 AND f.TF002=@單號 " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>取得借入歸還單的列表資料</summary>
        public static DataTable GetLoaningList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TH015 [客戶名稱], TH020 [確認碼], TI003 [項次], TI004 [品號], TI009 [數量] " +
                        "FROM INVTH h " +
                        "INNER JOIN INVTI i ON i.TI001=h.TH001 AND i.TI002=h.TH002 " +
                        "WHERE h.TH001=@單別 AND h.TH002=@單號 " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>取得序號是否存在</summary>
        public static bool ExistsSerialNo(string 序號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("序號", 序號);
            db.SqlParams = param;

            db.StrSQL = "SELECT COUNT(*) FROM SerialNo WHERE SerialNo=@序號";
            return (db.ExecuteScalar() != "0");
        }

        /// <summary>取得序號對應的品號</summary>
        public static string GetProductWithSerialNo(string 序號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("序號", 序號);
            db.SqlParams = param;

            db.StrSQL = "SELECT ProductNo FROM SerialNo WHERE SerialNo=@序號";
            return db.ExecuteScalar();
        }

        /// <summary>取得序號資料</summary>
        public static DataTable GetSerialData(string 公司別, string 品號, string 序號, string 單別, string 單號, string 項次, string 拆單單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("品號", 品號);
            param.Add("序號", 序號);
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("項次", 項次);
            param.Add("拆單單號", 拆單單號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(公司別)) { strWhere += " AND Company=@公司別 "; }
            if (!string.IsNullOrEmpty(品號)) { strWhere += " AND ProductNo=@品號 "; }
            if (!string.IsNullOrEmpty(序號)) { strWhere += " AND SerialNo=@序號 "; }
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND ERPClass=@單別 "; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND ERPNumber=@單號 "; }
            if (!string.IsNullOrEmpty(項次)) { strWhere += " AND ERPItemNo=@項次 "; }
            if (!string.IsNullOrEmpty(拆單單號)) { strWhere += " AND p_Number=@拆單單號 "; }

            db.StrSQL = "SELECT i.Company [公司別], i.ProductNo [品號], i.SerialNo [序號], i.Status [狀態], i.ERPClass [單別], i.ERPNumber [單號], i.ERPItemNo [項次], i.p_Number [拆單單號], i.ReasonCode, r.enName [Reason], i.ReasonCodeQA, r1.enName [ReasonQA], i.Remark [備註] " +
                        "FROM SerialNoItem i " +
                        "LEFT OUTER JOIN ReasonCode r ON r.Code=i.ReasonCode " +
                        "LEFT OUTER JOIN ReasonCode r1 ON r1.Code=i.ReasonCodeQA " +
                        "WHERE 1=1 " + strWhere +
                        "ORDER BY 品號, 序號";

            return db.ExecuteDataTable();
        }

        /// <summary>取得序號單頭檔資料</summary>
        public static DataTable GetSerialHead(string 品號, string 序號清單, string 製令單別, string 製令單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("品號", 品號);
            param.Add("製令單別", 製令單別);
            param.Add("製令單號", 製令單號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(品號)) { strWhere += " AND s.ProductNo=@品號 "; }
            if (!string.IsNullOrEmpty(序號清單)) { strWhere += " AND s.SerialNo IN (" + 序號清單 + ") "; }
            if (!string.IsNullOrEmpty(製令單別)) { strWhere += " AND s.m_FormClass=@製令單別 "; }
            if (!string.IsNullOrEmpty(製令單號)) { strWhere += " AND s.m_FormNumber=@製令單號 "; }

            db.StrSQL = "SELECT s.ProductNo [品號], s.SerialNo [序號], COUNT(si.ID) [單據數] FROM SerialNo s " +
                        "LEFT OUTER JOIN SerialNoItem si ON si.ProductNo=s.ProductNo AND si.SerialNo=s.SerialNo " +
                        "WHERE 1=1 " + strWhere +
                        "GROUP BY s.ProductNo, s.SerialNo " +
                        "ORDER BY 品號, 序號";
            return db.ExecuteDataTable();
        }

        /// <summary>匯出序號清單歷史單據資料</summary>
        public static DataTable ExportSerialNoHistory(string 序號清單, string 製令單別, string 製令單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("製令單別", 製令單別);
            param.Add("製令單號", 製令單號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(序號清單)) { strWhere += " AND s.SerialNo IN (" + 序號清單 + ") "; }
            if (!string.IsNullOrEmpty(製令單別)) { strWhere += " AND s.m_FormClass=@製令單別 "; }
            if (!string.IsNullOrEmpty(製令單號)) { strWhere += " AND s.m_FormNumber=@製令單號 "; }

            db.StrSQL = "SELECT si.Company [公司別], si.Status [狀態], si.ProductNo [品號], si.SerialNo [序號], si.ERPClass [單別], si.ERPNumber [單號], si.ERPItemNo [項次] " +
                        "FROM SerialNo s " +
                        "INNER JOIN SerialNoItem si ON si.ProductNo=s.ProductNo AND si.SerialNo=s.SerialNo " +
                        "WHERE 1=1 " + strWhere +
                        "ORDER BY 品號, 序號";

            return db.ExecuteDataTable();
        }

        /// <summary>刪除序號資料</summary>
        public static void DeleteSerialNo(string 公司別, string 品號, string 序號, string 狀態, string 單別, string 單號, string 項次, string 拆單單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", Tool.GetDBNullString(公司別));
            param.Add("品號", Tool.GetDBNullString(品號));
            param.Add("序號", Tool.GetDBNullString(序號));
            param.Add("狀態", Tool.GetDBNullString(狀態));
            param.Add("單別", Tool.GetDBNullString(單別));
            param.Add("單號", Tool.GetDBNullString(單號));
            param.Add("項次", Tool.GetDBNullString(項次));
            param.Add("拆單單號", Tool.GetDBNullString(拆單單號));
            db.SqlParams = param;

            string strWhere = "";
            if (!string.IsNullOrEmpty(公司別)) { strWhere += " AND Company=@公司別"; }
            if (!string.IsNullOrEmpty(品號)) { strWhere += " AND ProductNo=@品號"; }
            if (!string.IsNullOrEmpty(序號)) { strWhere += " AND SerialNo=@序號"; }
            if (!string.IsNullOrEmpty(狀態)) { strWhere += " AND Status=@狀態"; }
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND ERPClass=@單別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND ERPNumber=@單號"; }
            if (!string.IsNullOrEmpty(項次)) { strWhere += " AND ERPItemNo=@項次"; }
            if (!string.IsNullOrEmpty(拆單單號)) { strWhere += " AND p_Number=@拆單單號"; }

            db.StrSQL = "DELETE FROM SerialNoItem WHERE 1=1" + strWhere;
            db.ExecuteSQL();
        }

        /// <summary>刪除序號定義資料</summary>
        public static bool DeleteSerialNoHead(string 序號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("序號", Tool.GetDBNullString(序號));
            db.SqlParams = param;

            db.StrSQL = "DELETE FROM SerialNo WHERE SerialNo=@序號 AND NOT Exists(SELECT * FROM SerialNoItem WHERE SerialNo=@序號)";
            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>新增&修改序號資料</summary>
        public static int ModifySerialNo(string 公司別, string 品號, string 序號, string 製令單別, string 製令單號, string 狀態, string 單別, string 單號, string 項次, string 拆單單號, string ReasonCode, string 備註)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", Tool.GetDBNullString(公司別));
            param.Add("品號", Tool.GetDBNullString(品號.Trim()));
            param.Add("序號", Tool.GetDBNullString(序號.Trim()));
            param.Add("製令單別", Tool.GetDBNullString(製令單別));
            param.Add("製令單號", Tool.GetDBNullString(製令單號));
            param.Add("狀態", Tool.GetDBNullString(狀態));
            param.Add("單別", Tool.GetDBNullString(單別));
            param.Add("單號", Tool.GetDBNullString(單號));
            param.Add("項次", Tool.GetDBNullString(項次));
            param.Add("拆單單號", Tool.GetDBNullString(拆單單號));
            param.Add("ReasonCode", Tool.GetDBNullString(ReasonCode));
            param.Add("備註", Tool.GetDBNullString(備註));
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "IF @ReasonCode IS NOT NULL AND NOT EXISTS(SELECT * FROM ReasonCode WHERE Code=@ReasonCode) BEGIN RETURN; END " + //檢查ReasonCode是否正確
                        "IF EXISTS(SELECT * FROM SerialNo WHERE SerialNo=@序號) BEGIN " + //若序號存在
                            "IF EXISTS(SELECT * FROM SerialNo WHERE ProductNo=@品號 AND SerialNo=@序號) BEGIN " + //若此序號的品號正確
                                "INSERT SerialNoItem(Company, ProductNo, SerialNo, Status, ERPClass, ERPNumber, ERPItemNo, p_Number, ReasonCode, Remark, Updater, UpdateTime) VALUES(@公司別, @品號, @序號, @狀態, @單別, @單號, @項次, @拆單單號, @ReasonCode, @備註, @Updater, getdate()); " +
                            "END " +
                        "END ELSE BEGIN " +
                            "INSERT SerialNo(ProductNo, SerialNo, m_FormClass, m_FormNumber) VALUES(@品號, @序號,@製令單別,@製令單號); " +
                            "IF @單別 IS NOT NULL AND @單號 IS NOT NULL BEGIN " +
                                "INSERT SerialNoItem(Company, ProductNo, SerialNo, Status, ERPClass, ERPNumber, ERPItemNo, p_Number, ReasonCode, Remark, Updater, UpdateTime) VALUES(@公司別, @品號, @序號, @狀態, @單別, @單號, @項次, @拆單單號, @ReasonCode, @備註, @Updater, getdate()); " +
                            "END " +
                        "END";

            return db.ExecuteSQL();
        }

        /// <summary>新增&修改序號的QA RMA ReasonCode</summary>
        public static int ModifySerialReasonCodeQA(string 公司別, string 單別, string 單號, string 項次, string 品號, string 序號, string ReasonCodeQA, string 備註)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", Tool.GetDBNullString(公司別));
            param.Add("單別", Tool.GetDBNullString(單別));
            param.Add("單號", Tool.GetDBNullString(單號));
            param.Add("項次", Tool.GetDBNullString(項次));
            param.Add("品號", Tool.GetDBNullString(品號.Trim()));
            param.Add("序號", Tool.GetDBNullString(序號.Trim()));
            param.Add("ReasonCodeQA", Tool.GetDBNullString(ReasonCodeQA.Trim()));
            param.Add("備註", Tool.GetDBNullString(備註));
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "IF @ReasonCodeQA IS NOT NULL AND NOT EXISTS(SELECT * FROM ReasonCode WHERE Code=@ReasonCodeQA) BEGIN RETURN; END " + //檢查ReasonCodeQA是否正確
                        "UPDATE SerialNoItem SET ReasonCodeQA=@ReasonCodeQA, Remark=@備註, Updater=@Updater, UpdateTime=getdate() WHERE Company=@公司別 AND ERPClass=@單別 AND ERPNumber=@單號 AND ERPItemNo=@項次 AND ProductNo=@品號 AND SerialNo=@序號";

            return db.ExecuteSQL();
        }

        /// <summary>取得最後的銷貨單號</summary>
        public static string GetLastSellingFormNumber(string 公司別, string 序號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("序號", 序號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TOP 1 ERPClass + '-' + ERPNumber [銷貨單號] FROM SerialNoItem WHERE Company=@公司別 AND SerialNo=@序號 AND Status='銷貨單' ORDER BY ERPNumber DESC";
            return db.ExecuteScalar();
        }

        /// <summary>取得ReasonCode清單資料</summary>
        public static DataTable GetReasonCodeList()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            db.StrSQL = "SELECT * FROM ReasonCode";
            return db.ExecuteDataTable();
        }

        /// <summary>取得RMA Form資料(借入單)</summary>
        public static DataSet GetRMAFormData(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT f.TF001 [借入單別], f.TF002 [借入單號], f.TF024 [單據日期], f.TF018 [其它備註], f.TF013 [件數], f.TF014 [備註], a.MA003 [客戶全名], a.MA005 [連絡人], a.MA009 [連絡人EMail], a.MA006 [Tel], a.MA008	[Fax], v.MV047 [業務員], v.MV020 [業務員EMail], 0 [InWarranty], 0 [OutWarranty], 0 [ToReplace], " +
                            "(SELECT TOP 1 TG027 FROM INVTG WHERE (TG001=f.TF001) AND (TG002=f.TF002)) [預計歸還日] " +
                        "FROM INVTF f " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=f.TF005) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=f.TF008) " +
                        "WHERE (f.TF001=@單別) AND (f.TF002=@單號) AND (f.TF020=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "RMA單頭";

            db.StrSQL = "SELECT TG003 [項次], '' [產品序號], 1 [數量], t.TG004 [品號], t.TG005 [品名], t.TG019 [備註], '1. In' [Warranty], 1 [ToReplace], 1 [ToAnalyze], '' [ReasonCode名稱], '' [ReasonCode代號], (SELECT TOP 1 MG003 FROM COPMG WHERE (MG001=f.TF005) AND (MG002=t.TG004)) [客戶品號] " +
                        "FROM INVTF f " +
                        "INNER JOIN INVTG t ON (t.TG001=f.TF001) AND (t.TG002=f.TF002) " +
                        "WHERE f.TF001=@單別 AND f.TF002=@單號";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "RMA單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得RMA Form資料(銷退單)</summary>
        public static DataSet GetRMAFormCOPTI(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT i.TI001 [借入單別], i.TI002 [借入單號], i.TI003 [單據日期], 'DOA' [其它備註], i.TI028 [件數], (i.TI001 + '-' + i.TI002) [備註], a.MA003 [客戶全名], a.MA005 [連絡人], a.MA009 [連絡人EMail], a.MA006 [Tel], a.MA008	[Fax], v.MV047 [業務員], v.MV020 [業務員EMail], 0 [InWarranty], 0 [OutWarranty], 0 [ToReplace], 'TBD' [預計歸還日] " +
                        "FROM COPTI i " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=i.TI004) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=i.TI006) " +
                        "WHERE (i.TI001=@單別) AND (i.TI002=@單號) AND (i.TI019=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "RMA單頭";

            db.StrSQL = "SELECT TJ003 [項次], '' [產品序號], 1 [數量], j.TJ004 [品號], j.TJ005 [品名], '' [備註], '1. In' [Warranty], 0 [ToReplace], 1 [ToAnalyze], '' [ReasonCode名稱], '' [ReasonCode代號], j.TJ029 [客戶品號] " +
                        "FROM COPTJ j " +
                        "WHERE j.TJ001=@單別 AND j.TJ002=@單號";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "RMA單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得受訂單的資料</summary>
        public static DataSet GetSoFormData(string 公司別, string _單別, string _單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);

            db.SqlParams = param;
            db.StrSQL = "SELECT a.MA002 [客戶簡稱], c.TC012 [客戶單號], c.TC063 [BillTo], c.TC001 [單別], c.TC002 [單號], c.TC003 [訂單日期], '' [報價單號], v.MV002 [業務人員], c.TC015 [備註], c.TC029 [訂單金額], 0 [總訂單數量], 0 [總贈備品數量], 0 [總數量], v1.MV002 [確認者], c.TC010 [ShipTo] " +
                        "FROM COPTC c " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=c.TC004) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=c.TC006) " +
                        "LEFT OUTER JOIN CMSMV v1 ON (v1.MV001=c.TC040) " +
                        "WHERE c.TC001=@單別 AND c.TC002=@單號";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "受訂單頭";

            db.StrSQL = "SELECT d.TD001 [單別], d.TD002 [單號], d.TD004 [品號], d.TD005 [品名], d.TD006 [規格], d.TD014 [客戶品號], d.TD018 [報價單號], b.TB201 [客戶商品描述], d.TD008 [訂單數量], (d.TD024 + d.TD050) [贈備品數量], d.TD013 [預交日], d.TD020 [備註] " +
                        "FROM COPTD d " +
                        "LEFT OUTER JOIN COPTB b ON (b.TB001=d.TD017) AND (b.TB002=d.TD018) AND (b.TB003=TD019) " +
                        "WHERE d.TD001=@單別 AND d.TD002=@單號 AND d.TD016 IN ('Y','N') " +
                        "ORDER BY d.TD003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "受訂單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得Invoice的資料</summary>
        public static DataSet GetInvoiceFormData(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT g.TG007 [客戶全名], g.TG066 [連絡人], g.TG078 [TEL], g.TG079 [FAX], g.TG008 [ShipTo], g.TG018 [BillTo], g.TG020 [備註], g.TG027 [備註一], g.TG040 [InvoiceNo], g.TG001 [銷貨單別], g.TG002 [銷貨單號], g.TG003 [銷貨日期], g.TG011 [幣別], n.NA003 [付款條件], k.NK002 [交易條件], v.MV047 [業務員], 0 [TotalQty], 0.00 [Amount], g.TG025 [Tax], 0.00 [TotalDiscount], g.TG013 + g.TG025 [TotalAmount], a.MA049 [HarmonCode], m.MA022 [Beneficiary], m.MA004 [銀行帳號], m.MA017 [銀行英文全名], m.MA018 [銀行英文地址], m.MA020 [SWIFT] " +
                        "FROM COPTG g " +
                        "LEFT OUTER JOIN CMSNA n ON (n.NA002=g.TG047) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=g.TG006) " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=TG004) " +
                        "LEFT OUTER JOIN NOTMA m ON (m.MA001=a.MA200) " +
                        "LEFT OUTER JOIN CMSNK k ON (k.NK001=g.TG082) " +
                        "WHERE (g.TG001=@單別) AND (g.TG002=@單號) AND (g.TG023=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "Invoice單頭";

            db.StrSQL = "SELECT h.TH001 [銷貨單別], h.TH002 [銷貨單號], b.TB001 + '-' +b.TB002 [報價單號], c.TC012 [客戶單號], b.TB201 [客戶商品描述], h.TH004 [品號], h.TH005 [品名], h.TH019 [客戶品號], SUM(h.TH008 + h.TH024) [數量], h.TH012 [單價], SUM(h.TH013) [金額], h.TH025 [折扣率], h.TH018 [備註] " +
                        "FROM COPTH h " +
                        "LEFT OUTER JOIN COPTD d ON (d.TD001=h.TH014) AND (d.TD002=h.TH015) AND (d.TD003=h.TH016) " +
                        "LEFT OUTER JOIN COPTC c ON (c.TC001=d.TD001) AND (c.TC002=d.TD002) " +
                        "LEFT OUTER JOIN COPTB b ON (b.TB001=d.TD017) AND (b.TB002=d.TD018) AND (b.TB003=d.TD019) " +
                        "WHERE h.TH001=@單別 AND h.TH002=@單號 " +
                        "GROUP BY h.TH001, h.TH002, b.TB001, b.TB002, c.TC012, b.TB201, h.TH004, h.TH005, h.TH019, h.TH012, h.TH025, h.TH018 " +
                        "ORDER BY h.TH004";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "Invoice單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得Invoice RMA的資料</summary>
        public static DataSet GetInvoiceFormRMA(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT g.TG007 [客戶全名], g.TG066 [連絡人], g.TG078 [TEL], g.TG079 [FAX], g.TG008 [ShipTo], g.TG018 [BillTo], g.TG020 [備註], g.TG027 [備註一], g.TG040 [InvoiceNo], g.TG001 [銷貨單別], g.TG002 [銷貨單號], g.TG003 [銷貨日期], g.TG011 [幣別], n.NA003 [付款條件], k.NK002 [交易條件], v.MV047 [業務員], 0 [TotalQty], 0.00 [Amount], g.TG025 [Tax], 0.00 [TotalDiscount], 0 [TotalAmount], a.MA049 [HarmonCode], m.MA022 [Beneficiary], m.MA004 [銀行帳號], m.MA017 [銀行英文全名], m.MA018 [銀行英文地址], m.MA020 [SWIFT] " +
                        "FROM COPTG g " +
                        "LEFT OUTER JOIN CMSNA n ON (n.NA002=g.TG047) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=g.TG006) " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=TG004) " +
                        "LEFT OUTER JOIN NOTMA m ON (m.MA001=a.MA200) " +
                        "LEFT OUTER JOIN CMSNK k ON (k.NK001=g.TG082) " +
                        "WHERE (g.TG001=@單別) AND (g.TG002=@單號) AND (g.TG023=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "Invoice單頭";

            db.StrSQL = "SELECT h.TH001 [銷貨單別], h.TH002 [銷貨單號], b.TB001 + '-' +b.TB002 [報價單號], c.TC012 [客戶單號], b.TB201 [客戶商品描述], h.TH004 [品號], h.TH005 [品名], h.TH019 [客戶品號], h.TH008 [數量], 1 [單價], h.TH008 [金額], 1 [折扣率], '' [備註] " +
                        "FROM COPTH h " +
                        "LEFT OUTER JOIN COPTD d ON (d.TD001=h.TH014) AND (d.TD002=h.TH015) AND (d.TD003=h.TH016) " +
                        "LEFT OUTER JOIN COPTC c ON (c.TC001=d.TD001) AND (c.TC002=d.TD002) " +
                        "LEFT OUTER JOIN COPTB b ON (b.TB001=d.TD017) AND (b.TB002=d.TD018) AND (b.TB003=d.TD019) " +
                        "WHERE h.TH001=@單別 AND h.TH002=@單號 " +
                        "ORDER BY h.TH003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "Invoice單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得Invoice的資料(從借出入歸還單)</summary>
        public static DataSet GetInvoiceFromINVTH(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT a.MA003 [客戶全名], a.MA005 [連絡人], a.MA006 [TEL], a.MA008 [FAX], a.MA027 [ShipTo], a.MA025 [BillTo], '' [備註], '' [備註一], h.TH018 [InvoiceNo], h.TH001 [銷貨單別], h.TH002 [銷貨單號], h.TH003 [銷貨日期], h.TH011 [幣別], '' [付款條件], '' [交易條件], v.MV047 [業務員], 0 [TotalQty], 0.00 [Amount], h.TH026 [Tax], 0.00 [TotalDiscount], h.TH022 + h.TH026 [TotalAmount], a.MA049 [HarmonCode], m.MA022 [Beneficiary], m.MA004 [銀行帳號], m.MA017 [銀行英文全名], m.MA018 [銀行英文地址], m.MA020 [SWIFT] " +
                        "FROM INVTH h " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=h.TH008) " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=h.TH005) " +
                        "LEFT OUTER JOIN NOTMA m ON (m.MA001=a.MA200) " +
                        "WHERE (h.TH001=@單別) AND (h.TH002=@單號) AND (h.TH020=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "Invoice單頭";

            db.StrSQL = "SELECT h.TH001 [銷貨單別], h.TH002 [銷貨單號], h.TH014 [報價單號], (i.TI014 + '-' + TI015) [客戶單號], i.TI021 [客戶商品描述], i.TI004 [品號], i.TI005 [品名], '' [客戶品號], i.TI009 [數量], 1 [單價], i.TI009 [金額], 1 [折扣率], '' [備註] " +
                        "FROM INVTH h " +
                        "INNER JOIN INVTI i ON (i.TI001=h.TH001) AND (i.TI002=h.TH002) " +
                        "WHERE h.TH001=@單別 AND h.TH002=@單號 " +
                        "ORDER BY i.TI003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "Invoice單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得Invoice的資料(從暫出入單)</summary>
        public static DataSet GetInvoiceFromINVTF(string 公司別, string _單別, string _單號, string _確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", _單別);
            param.Add("單號", _單號);
            param.Add("確認碼", _確認碼);

            db.SqlParams = param;
            db.StrSQL = "DECLARE @來源單別 varchar(4);" +
                        "DECLARE @來源單號 varchar(10);" +
                        "SELECT TOP 1 @來源單別=TG014, @來源單號=TG015 FROM INVTG WHERE TG001=@單別 AND TG002=@單號 AND TG022=@確認碼;" +

                        "SELECT a.MA003 [客戶全名], a.MA005 [連絡人], a.MA006 [TEL], a.MA008 [FAX], c.TC010 [ShipTo], c.TC063 [BillTo], '' [備註], '' [備註一], f.TF018 [InvoiceNo], f.TF001 [銷貨單別], f.TF002 [銷貨單號], f.TF003 [銷貨日期], f.TF011 [幣別], n.NA003 [付款條件], k.NK002 [交易條件], v.MV047 [業務員], 0 [TotalQty], 0.00 [Amount], f.TF027 [Tax], 0.00 [TotalDiscount], f.TF023 + f.TF027 [TotalAmount], a.MA049 [HarmonCode], m.MA022 [Beneficiary], m.MA004 [銀行帳號], m.MA017 [銀行英文全名], m.MA018 [銀行英文地址], m.MA020 [SWIFT] " +
                        "FROM INVTF f " +
                        "INNER JOIN COPTC c ON (c.TC001=@來源單別) AND (c.TC002=@來源單號) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=f.TF008) " +
                        "LEFT OUTER JOIN CMSNA n ON (n.NA002=c.TC042) " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=f.TF005) " +
                        "LEFT OUTER JOIN NOTMA m ON (m.MA001=a.MA200) " +
                        "LEFT OUTER JOIN CMSNK k ON (k.NK001=c.TC068) " +
                        "WHERE (f.TF001=@單別) AND (f.TF002=@單號) AND (f.TF020=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "Invoice單頭";

            db.StrSQL = "SELECT g.TG001 [銷貨單別], g.TG002 [銷貨單號], b.TB001 + '-' + b.TB002 [報價單號], c.TC012 [客戶單號], b.TB201 [客戶商品描述], g.TG004 [品號], g.TG005 [品名], d.TD014 [客戶品號], g.TG009 [數量], g.TG012 [單價], g.TG013 [金額], d.TD026 [折扣率], d.TD020 [備註] " +
                        "FROM INVTG g " +
                        "LEFT OUTER JOIN COPTC c ON (c.TC001=g.TG014) AND (c.TC002=g.TG015) " +
                        "LEFT OUTER JOIN COPTD d ON (d.TD001=g.TG014) AND (d.TD002=g.TG015) AND (d.TD003=g.TG016) " +
                        "LEFT OUTER JOIN COPTB b ON (b.TB001=d.TD017) AND (b.TB002=d.TD018) AND (b.TB003=d.TD019) " +
                        "WHERE g.TG001=@單別 AND g.TG002=@單號 AND g.TG022=@確認碼 " +
                        "ORDER BY g.TG003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "Invoice單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得Invoice的資料(從銷退單)</summary>
        public static DataSet GetInvoiceFormCOPTI(string 公司別, string 單別, string 單號, string 確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("確認碼", 確認碼);

            db.SqlParams = param;
            db.StrSQL = "SELECT a.MA003 [客戶全名], a.MA023 [客戶登記地址], a.MA006 [客戶Tel], a.MA008 [客戶Fax], v.MV047 [業務人員], i.TI003 [銷退日], i.TI008 [幣別], a.MA005 [客戶聯絡人], i.TI029 [總數量], i.TI010 [原幣銷退金額] " +
                        "FROM COPTI i " +
                        "INNER JOIN COPMA a ON a.MA001=i.TI004 " +
                        "INNER JOIN CMSMV v ON v.MV001=i.TI006 " +
                        "WHERE (i.TI001=@單別) AND (i.TI002=@單號) AND (i.TI019=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "Invoice單頭";

            db.StrSQL = "SELECT b.TB001 + '-' +b.TB002 [報價單號], c.TC012 [客戶單號], j.TJ004 [品號], j.TJ005 [品名], j.TJ029 [客戶品號], j.TJ011 [單價], j.TJ007 [數量], j.TJ012 [金額], b.TB201 [客戶商品描述], g.TG040 [InvoiceNo] " +
                        "FROM COPTJ j " +
                        "LEFT OUTER JOIN COPTH h ON h.TH001=j.TJ015 AND h.TH002=j.TJ016 AND h.TH003=j.TJ017 " +
                        "LEFT OUTER JOIN COPTG g ON g.TG001=h.TH001 AND g.TG002=h.TH002 " +
                        "LEFT OUTER JOIN COPTD d ON d.TD001=h.TH014 AND d.TD002=h.TH015 AND d.TD003=h.TH016 " +
                        "LEFT OUTER JOIN COPTC c ON c.TC001=d.TD001 AND c.TC002=d.TD002 " +
                        "LEFT OUTER JOIN COPTB b ON b.TB001=d.TD017 AND b.TB002=d.TD018 AND b.TB003=d.TD019 " +
                        "WHERE j.TJ001=@單別 AND j.TJ002=@單號 " +
                        "ORDER BY j.TJ003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "Invoice單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>取得ERP009的資料</summary>
        public static DataSet GetERP009(string 公司別, object 單別, object 單號, string 確認碼)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("確認碼", 確認碼);
            db.SqlParams = param;

            db.SqlParams = param;
            db.StrSQL = "SELECT i.TI021 [客戶全名], i.TI049 [連絡人], a.MA006 [TEL], a.MA008 [FAX], i.TI046 [ShipTo], a.MA025 [BillTo], (i.TI001 + '-' + i.TI002) [CreditNoteNo], i.TI020 [CreditNo], i.TI003 [CreditNoteDate], v.MV047 [Sales], '' [Note], i.TI008 [Currency], n.NA003 [付款條件], k.NK002 [交易條件], 0 [TotalQty], 0.00 [Amount], 0.00 [Tax], 0.00 [TotalAmount], m.MA022 [Beneficiary], m.MA004 [銀行帳號], m.MA017 [銀行英文全名], m.MA018 [銀行英文地址], m.MA020 [SWIFT], (SELECT MV047 FROM CMSMV WHERE MV001=i.TI035) [IssuedBy] " +
                        "FROM COPTI i " +
                        "LEFT OUTER JOIN CMSNA n ON (n.NA002=i.TI039) " +
                        "LEFT OUTER JOIN CMSMV v ON (v.MV001=i.TI006) " +
                        "LEFT OUTER JOIN COPMA a ON (a.MA001=i.TI004) " +
                        "LEFT OUTER JOIN NOTMA m ON (m.MA001=a.MA200) " +
                        "LEFT OUTER JOIN CMSNK k ON (k.NK001=i.TI057) " +
                        "WHERE (i.TI001=@單別) AND (i.TI002=@單號) AND (i.TI019=@確認碼)";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "CREDIT單頭";

            db.StrSQL = "SELECT j.TJ001 [FormClass], j.TJ002 [FormNumber], g.TG040 [InvoiceNo], c.TC012 [PONumber], 'Lamp Module' [Type], j.TJ004 [PartName], j.TJ029 [Description], CASE WHEN j.TJ001='2410' THEN j.TJ007 ELSE j.TJ050 END [Qty], j.TJ011 [UnitPrice], j.TJ012 [SubTotal] " +
                        "FROM COPTJ j " +
                        "LEFT OUTER JOIN COPTH h ON h.TH001=j.TJ015 AND h.TH002=j.TJ016 AND h.TH003=j.TJ017 " +
                        "LEFT OUTER JOIN COPTG g ON g.TG001=h.TH001 AND g.TG002=h.TH002 " +
                        "LEFT OUTER JOIN COPTC c ON c.TC001=h.TH014 AND c.TC002=h.TH015 " +
                        "WHERE (j.TJ001=@單別) AND (j.TJ002=@單號) AND (j.TJ021=@確認碼) " +
                        "ORDER BY j.TJ003";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "CREDIT單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }

        /// <summary>匯出銷貨單的單據與序號資料</summary>
        public static DataTable ExportSellingData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TH003 [Item], (d.TD017 + '-' + d.TD018) [PI Number], c.TC012 [PO Number], TH004 [Arclite P/N], TH005 [Arclite Part Name], TH019 [Description], '' [Serial Number], TH014 + '-' + TH015 [SO Number], TG040 [Invoice Number] FROM COPTG g " +
                        "INNER JOIN COPTH h ON h.TH001=g.TG001 AND h.TH002=g.TG002 " +
                        "INNER JOIN COPTD d ON d.TD001=h.TH014 AND d.TD002=h.TH015 AND d.TD003=h.TH016 " +
                        "INNER JOIN COPTC c ON c.TC001=d.TD001 AND c.TC002=d.TD002 " +
                        "WHERE TG001=@單別 AND TG002=@單號";

            return db.ExecuteDataTable();
        }

        /// <summary>匯出借入單的單據與序號資料</summary>
        public static DataTable ExportBorrowData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TG001 [單別], TG002 [單號], TG003 [項次], TG004 [品號], '' [序號], '' [ReasonCode], '' [Reason], '' ReasonCodeQA, '' [ReasonQA], '' [最後銷貨單號], '' [備註] FROM INVTG WHERE TG001=@單別 AND TG002=@單號";
            return db.ExecuteDataTable();
        }

        /// <summary>匯出銷退單的單據與序號資料</summary>
        public static DataTable ExportReturnGoodsData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TJ001 [單別], TJ002 [單號], TJ003 [項次], TJ004 [品號], '' [序號], '' ReasonCodeQA, '' [ReasonQA], '' [最後銷貨單號], '' [備註] FROM COPTJ WHERE TJ001=@單別 AND TJ002=@單號";
            return db.ExecuteDataTable();
        }

        /// <summary>匯出借入歸還單的單據與序號資料</summary>
        public static DataTable ExportReturnBorrowData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TI003 [Item], ('RMA' + TI015) [PI Number], TH017 [PO Number], TI004 [Arclite P/N], TI005 [Arclite Part Name], TI021 [Description], '' [Serial Number], (TH001 + '-' + TH002) [SO Number], TH018 [Invoice Number] " +
                        "FROM INVTH " +
                        "INNER JOIN INVTI ON TI001=TH001 AND TI002=TH002 " +
                        "WHERE TH001=@單別 AND TH002=@單號";

            return db.ExecuteDataTable();
        }

        /// <summary>匯出訂單的單據與序號資料</summary>
        public static DataTable ExportOrderData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TD003 [Item], (d.TD017 + '-' + d.TD018) [PI Number], c.TC012 [PO Number], TD004 [Arclite P/N], TD005 [Arclite Part Name], TD008 [Qty], b.MB013 [EAN Code], '' [Serial Number], TD001 + '-' + TD002 [SO Number], TD014 [客戶品號], t.TB201 [客戶商品描述] " +
                        "FROM COPTD d " +
                        "INNER JOIN INVMB b ON b.MB001=d.TD004 " +
                        "INNER JOIN COPTC c ON c.TC001=d.TD001 AND c.TC002=d.TD002 " +
                        "LEFT OUTER JOIN COPTB t ON t.TB001=d.TD017 AND t.TB002=d.TD018 AND t.TB003=d.TD019 " +
                        "WHERE TD001=@單別 AND TD002=@單號 " +
                        "ORDER BY TD003";

            return db.ExecuteDataTable();
        }

        /// <summary>取得品號</summary>
        public static DataRow GetINVMB(string 品號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("品號", 品號);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM INVMB WHERE MB001=@品號";
            DataTable dt = db.ExecuteDataTable();

            DataRow row = null;
            if (dt.Rows.Count > 0)
            {
                row = dt.Rows[0];
            }

            return row;
        }

        /// <summary>取得報價單的單頭列表</summary>
        public static DataTable GetQuotationHeadList(string 公司別, string 單別, string 單號, string 確認碼, string 客戶代碼, string 員工代碼, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號 + "%");
            param.Add("確認碼", 確認碼);
            param.Add("客戶代碼", 客戶代碼);
            param.Add("員工代碼", 員工代碼);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND a.TA001=@單別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND a.TA002 LIKE @單號"; }
            if (!string.IsNullOrEmpty(確認碼)) { strWhere += " AND a.TA019=@確認碼"; }
            if (!string.IsNullOrEmpty(客戶代碼)) { strWhere += " AND a.TA004=@客戶代碼"; }
            if (!string.IsNullOrEmpty(員工代碼)) { strWhere += " AND a.TA005=@員工代碼"; }

            //SQL
            string strSQL = "SELECT a.TA001 [單別], a.TA002 [單號], a.TA003 [日期], a.TA004 [客戶代碼], a.TA006 [客戶全名], a.TA005 [員工代號], v.MV002 [員工姓名], a.TA007 [幣別], a.TA021 [備註二], a.TA019 [確認碼], CAST(ROUND(a.TA025,0) AS Int) [總數量] " +
                            "FROM COPTA a " +
                            "INNER JOIN CMSMV v ON v.MV001=a.TA005 " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "日期 DESC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得報價單的單身列表</summary>
        public static DataTable GetQuotationBodyList(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "SELECT TB001 [單別], TB002 [單號], TB003 [項次], TB004 [品號], TB007 [數量], TB009 [單價], TB011 [確認碼], TB012 [備註], TB016 [生效日], TB018 [客戶品號], TB200 [原廠燈號], TB201 [客戶商品描述] " +
                        "FROM COPTB b " +
                        "WHERE TB001=@單別 AND TB002=@單號 " +
                        "ORDER BY 項次";

            return db.ExecuteDataTable();
        }

        /// <summary>更新報價單的單身備註</summary>
        public static void EditQuotationBodyRemark(string 公司別, string 單別, string 單號, string 項次, string 備註)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("項次", 項次);
            param.Add("備註", 備註);
            db.SqlParams = param;

            db.StrSQL = "UPDATE COPTB SET TB012=@備註 WHERE TB001=@單別 AND TB002=@單號 AND TB003=@項次";
            db.ExecuteSQL();
        }

        /// <summary>新增或修改報價單資料</summary>
        public static void ModifyQuotationFormData(string 公司別, string _單別, string _單號, DataTable dtBody, bool b單價, ref bool Result, ref string Message)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //增加SQL參數
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("單別", _單別));
                cmd.Parameters.Add(new SqlParameter("單號", _單號));
                cmd.Parameters.Add(new SqlParameter("項次", DBNull.Value));
                cmd.Parameters.Add(new SqlParameter("品號", DBNull.Value));
                cmd.Parameters.Add(new SqlParameter("數量", DBNull.Value));
                cmd.Parameters.Add(new SqlParameter("生效日", DBNull.Value));
                cmd.Parameters.Add(new SqlParameter("備註", DBNull.Value));
                cmd.Parameters.Add(new SqlParameter("帶入單價", b單價 ? 1 : 0));

                #region 刪除原有資料
                cmd.CommandText = "DELETE FROM COPTB WHERE TB001=@單別 AND TB002=@單號";
                cmd.ExecuteNonQuery();
                #endregion

                #region 寫入單身
                //循序讀取單身項目
                string strItemNo = "0000";
                foreach (DataRow rowItem in dtBody.Rows)
                {
                    //設定SQL參數
                    strItemNo = Tool.GetPadLeftString(strItemNo, 1);
                    cmd.Parameters["項次"].Value = strItemNo;
                    cmd.Parameters["品號"].Value = rowItem["品號"].ToString().Trim();
                    cmd.Parameters["數量"].Value = rowItem["數量"].ToString().Trim();
                    cmd.Parameters["生效日"].Value = DateTime.Parse(rowItem["生效日"].ToString()).ToString("yyyyMMdd");
                    cmd.Parameters["備註"].Value = rowItem["備註"].ToString().Trim();

                    //SQL
                    cmd.CommandText = "DECLARE @客戶代號 varchar(10), @匯率 numeric(20,9), @品名 varchar(120), @規格 varchar(120), @單位 varchar(6), @單價 numeric(21,6), @客戶品號 varchar(40), @原廠燈號 varchar(40), @客戶商品描述 varchar(255), @業務底價 numeric(21,6), @營業稅率 numeric(8,5), @單價取位 varchar(1), @金額取位 varchar(1); " +

                                      "SELECT @品名=MB002, @規格=MB003, @單位=MB004, @業務底價=MB097 FROM INVMB WHERE MB001=@品號; " +

                                      "SELECT @客戶代號=TA004, @匯率=TA008, @營業稅率=TA024 FROM COPTA WHERE TA001=@單別 AND TA002=@單號; " +

                                      "SELECT TOP 1 @單價=(CASE WHEN @帶入單價=1 THEN TB009 ELSE 0 END), @客戶品號=TB018, @原廠燈號=TB200, @客戶商品描述=TB201 FROM COPTA, COPTB WHERE TA001=TB001 AND TA002=TB002 AND TA004=@客戶代號 AND TB004=@品號 AND TB009<>0 ORDER BY TA003 DESC; " +

                                      "IF (@客戶品號 IS NOT NULL) BEGIN " +
                                          "INSERT COPTB(COMPANY, CREATOR, USR_GROUP, CREATE_DATE, FLAG, TB001, TB002, TB003, TB004, TB005, TB006, TB007, TB008, TB009, TB010, TB011, TB012, TB016, TB017, TB018, TB025, TB042, TB200, TB201, TB202, TB203) " +
                                          "VALUES ('Arclite', 'DS', 'Arclite', CONVERT(VARCHAR(8),GETDATE(),112), 1, @單別, @單號, @項次, @品號, @品名, @規格, @數量, @單位, @單價, (@數量 * @單價), 'N', @備註, @生效日, '', @客戶品號, 1, @營業稅率, @原廠燈號, @客戶商品描述, (@業務底價 / @匯率), (@數量 * (@業務底價 / @匯率))); " +
                                      "END";

                    //若寫入失敗，則設定訊息
                    int iResult = cmd.ExecuteNonQuery();
                    if (iResult < 1) { Message += rowItem["品號"].ToString().Trim() + " 寫入失敗! <br/>"; }
                }
                #endregion

                #region 更新單頭
                cmd.CommandText = "DECLARE @底價備註 varchar(255), @底價條件 nchar(1), @報價金額 numeric(20,9), @稅額 numeric(20,9), @總數量 int; " +
                                  "SET @底價備註 = (SELECT STUFF((SELECT ',' + TB003 FROM COPTB WHERE TB001=@單別 AND TB002=@單號 AND TB009<TB202 FOR XML PATH('')), 1, 1, '')); " +
                                  "IF(@底價備註 IS NULL) BEGIN SET @底價條件='N' END ELSE BEGIN SET @底價條件='Y' END " +
                                  "SELECT @報價金額=SUM(TB010), @總數量=SUM(TB007) FROM COPTB WHERE TB001=@單別 AND TB002=@單號; " +
                                  "SELECT @稅額=@報價金額 * TA024 FROM COPTA WHERE TA001=@單別 AND TA002=@單號; " +
                                  "UPDATE COPTA SET TA009=@報價金額, TA023=@稅額, TA025=@總數量, TA203=@底價條件, TA204=@底價備註 WHERE TA001=@單別 AND TA002=@單號;";

                cmd.ExecuteNonQuery();
                #endregion

                trans.Commit();
                Result = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>由三角貿易帶入報價單資料</summary>
        public static void TriangleTradeToQuotation(string 來源公司別, string 來源採購單別, string 來源採購單號, string 目的公司別, string 目的報價單別, string 目的報價單號, ref bool Result, ref string Message)
        {
            try
            {
                //物件初始化
                Company c1 = CompanyCollection.Get(目的公司別);
                Company c = CompanyCollection.Get(來源公司別);
                DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

                //資料庫參數
                DataBase.SqlParams param = new UHR.DataBase.SqlParams();
                param.Add("來源採購單別", 來源採購單別);
                param.Add("來源採購單號", 來源採購單號);
                param.Add("目的報價單別", 目的報價單別);
                param.Add("目的報價單號", 目的報價單號);
                db.SqlParams = param;

                string 採購單號 = 來源採購單別 + "-" + 來源採購單號;

                db.StrSQL = "CREATE TABLE #tempPI([項次] nchar(4), [品號] nvarchar(40), [品名] nvarchar(120), [規格] nvarchar(120), [數量] numeric(16, 3), [單位] nvarchar(6), [單價] numeric(21, 6), [金額] numeric(21, 6), [備註] nvarchar(255), [客戶品號] nvarchar(40), [原廠燈號] nchar(40), [客戶商品描述] nvarchar(255)); " +
                            "IF EXISTS(SELECT * FROM PURTB WHERE TB022 LIKE '" + 採購單號 + "%' AND TB029 <> '') BEGIN " +
                                "INSERT #tempPI([項次], [品號], [品名], [規格], [數量], [單位], [單價], [金額], [備註], [客戶品號], [原廠燈號], [客戶商品描述]) " +
                                "SELECT d.TD003 [項次], c.TB004 [品號], c.TB005 [品名], c.TB006 [規格], d.TD008 [數量], c.TB008 [單位], d.TD010 [單價], d.TD011 [金額], c.TB012 [備註], c.TB018 [客戶品號], c.TB200 [原廠燈號], c.TB201 [客戶商品描述] " +
                                "FROM PURTD d " +
                                "LEFT OUTER JOIN PURTB b ON b.TB001=d.TD026 AND b.TB002=d.TD027 AND b.TB003=d.TD028 " +
                                "LEFT OUTER JOIN COPTD e ON e.TD001=b.TB029 AND e.TD002=b.TB030 AND e.TD003=b.TB031 " +
                                "LEFT OUTER JOIN COPTB c ON c.TB001=e.TD017 AND c.TB002=e.TD018 AND c.TB003=e.TD019 " +
                                "WHERE d.TD001=@來源採購單別 AND d.TD002=@來源採購單號; " +
                            "END ELSE BEGIN " +
                                "INSERT #tempPI([項次], [品號], [品名], [規格], [數量], [單位], [單價], [金額], [備註], [客戶品號], [原廠燈號], [客戶商品描述]) " +
                                "SELECT d.TD003 [項次], d.TD004 [品號], d.TD005 [品名], d.TD006 [規格], d.TD008 [數量], d.TD009 [單位], d.TD010 [單價], d.TD011 [金額], '' [備註], b.TB018 [客戶品號], b.TB200 [原廠燈號], b.TB201 [客戶商品描述] " +
                                "FROM PURTD d " +
                                "LEFT OUTER JOIN (SELECT b.TB004, b.TB018, b.TB200, b.TB201 " +
                                                 "FROM COPTB b, (SELECT TB004, MAX(TB001+TB002+TB003) [KeyVal] FROM COPTB GROUP BY TB004) b1 " +
                                                 "WHERE b.TB001+b.TB002+b.TB003 = b1.KeyVal) b ON b.TB004=d.TD004 " +
                                "WHERE d.TD001=@來源採購單別 AND d.TD002=@來源採購單號; " +
                            "END " +

                            "DELETE FROM " + c1.DBName + "COPTB WHERE TB001=@目的報價單別 AND TB002=@目的報價單號; " +

                            "INSERT " + c1.DBName + "COPTB(COMPANY, CREATOR, USR_GROUP, CREATE_DATE, FLAG, TB001, TB002, TB003, TB004, TB005, TB006, TB007, TB008, TB009, TB010, TB011, TB012, TB016, TB017, TB018, TB025, TB042, TB200, TB201, TB202, TB203) " +
                            "SELECT a.COMPANY, a.CREATOR, a.USR_GROUP, a.CREATE_DATE, a.FLAG, TA001, TA002, 項次, 品號, 品名, 規格, 數量, 單位, 單價, 金額, TA019, 備註, TA003, '', 客戶品號, 1, TA024, 原廠燈號, 客戶商品描述, (MB097 / TA008), (數量 * (MB097 / TA008)) " +
                            "FROM " + c1.DBName + "COPTA a " +
                            "LEFT OUTER JOIN #tempPI b ON 1=1 " +
                            "LEFT OUTER JOIN " + c1.DBName + "INVMB m ON m.MB001=品號 " +
                            "WHERE TA001=@目的報價單別 AND TA002=@目的報價單號; " +

                            "DECLARE @底價備註 varchar(255), @底價條件 nchar(1), @報價金額 numeric(20,9), @稅額 numeric(20,9), @總數量 int; " +
                            "SET @底價備註 = (SELECT STUFF((SELECT ',' + TB003 FROM " + c1.DBName + "COPTB WHERE TB001=@目的報價單別 AND TB002=@目的報價單號 AND TB009<TB202 FOR XML PATH('')), 1, 1, '')); " +
                            "IF(@底價備註 IS NULL) BEGIN SET @底價條件='N' END ELSE BEGIN SET @底價條件='Y' END " +
                            "SELECT @報價金額=SUM(TB010), @總數量=SUM(TB007) FROM " + c1.DBName + "COPTB WHERE TB001=@目的報價單別 AND TB002=@目的報價單號; " +
                            "SELECT @稅額=@報價金額 * TA024 FROM " + c1.DBName + "COPTA WHERE TA001=@目的報價單別 AND TA002=@目的報價單號; " +
                            "UPDATE " + c1.DBName + "COPTA SET TA009=@報價金額, TA023=@稅額, TA025=@總數量, TA203=@底價條件, TA204=@底價備註 WHERE TA001=@目的報價單別 AND TA002=@目的報價單號;";

                db.ExecuteSQL();
                Result = true;
            }
            catch (Exception e)
            {
                Result = false;
                Message = e.Message;
            }
        }

        /// <summary>取得ERP使用者清單</summary>
        public static DataTable GetUserList(string 工號, string 中文姓名, string 部門名稱, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", 工號);
            param.Add("cName", "%" + 中文姓名 + "%");
            param.Add("Dept", "%" + 部門名稱 + "%");
            db.SqlParams = param;

            //查詢條件
            string strWHERE = "";
            if (!string.IsNullOrEmpty(工號)) { strWHERE += " AND MA001=@Code"; }
            if (!string.IsNullOrEmpty(中文姓名)) { strWHERE += " AND MV002 LIKE @cName"; }
            if (!string.IsNullOrEmpty(部門名稱)) { strWHERE += " AND ME002 LIKE @Dept"; }

            string strSQL = "";
            strSQL = "SELECT MV001 [員工代號], MV002 [姓名], MV047 [英文全名], MV004 [部門代號], ME002 [部門名稱], MA008 [鎖定碼] " +
                     "FROM CMSMV v " +
                     "INNER JOIN DSCSYS..DSCMA a ON a.MA001=v.MV001 " +
                     "INNER JOIN CMSME e ON e.ME001=v.MV004 " +
                     "WHERE 1=1 AND MA008='N'" + strWHERE;
            DataTable dt = db.ExecuteDataTable(strSQL, "員工代號 ASC", _pageindex, _pagesize, out _recordcount);

            return dt;
        }

        /// <summary>取得ERP客戶清單</summary>
        public static DataTable GetCustomerList(string 公司別, string 客戶代號, string 客戶簡稱, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", 客戶代號);
            param.Add("Name", "%" + 客戶簡稱 + "%");
            db.SqlParams = param;

            //查詢條件
            string strWHERE = "";
            if (!string.IsNullOrEmpty(客戶代號)) { strWHERE += " AND Upper(MA001) = @Code"; }
            if (!string.IsNullOrEmpty(客戶簡稱)) { strWHERE += " AND Upper(MA002) LIKE @Name"; }

            string strSQL = "";
            strSQL = "SELECT MA001 [客戶代號], MA002 [客戶簡稱], MA003 [客戶全名] FROM COPMA WHERE 1=1" + strWHERE;
            DataTable dt = db.ExecuteDataTable(strSQL, "客戶代號 ASC", _pageindex, _pagesize, out _recordcount);

            return dt;
        }

        /// <summary>取得銷售預測資料-依品號</summary>
        public static DataTable GetSellingDivinationByProduct(string 期間, string 業務員)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("期間", 期間);
            param.Add("業務員", 業務員);
            db.SqlParams = param;

            #region 指定日期往前減三個月
            //轉換日期物件
            DateTime date = Convert.ToDateTime(期間.Substring(0, 4) + "/" + 期間.Substring(4, 2) + "/" + "01");

            string strField = "", strCondition = "";
            for (int i = 3; i >= 0; i--)
            {
                string strMM = date.AddMonths(0 - i).ToString("yyyyMM");

                strField += "[" + strMM + "],";
                strCondition += "'" + strMM + "',";
            }
            strField = strField.Trim(',');
            strCondition = strCondition.Trim(',');
            #endregion

            #region 分批撈數量
            //SQL-銷售數量
            db.StrSQL = "SELECT [客戶代號],[客戶簡稱],[品號]," + strField + " [本月銷售數量],null [累計未銷售數量],null [預測數量] FROM( " +
                            "SELECT TG004 [客戶代號], MA002 [客戶簡稱], TH004 [品號], SUBSTRING(TG003,1,6) [DATE], SUM(TH008) [數量] " +
                            "FROM COPTG g " +
                            "INNER JOIN COPTH h ON h.TH001=g.TG001 AND h.TH002=g.TG002 " +
                            "INNER JOIN COPMA a ON a.MA001=g.TG004 " +
                            "INNER JOIN INVMB b ON b.MB001=h.TH004 " +
                            "WHERE TG023='Y' AND TH020='Y' AND b.MB005='5' AND a.MA016=@業務員 AND (SUBSTRING(TG003,1,6) IN (" + strCondition + ")) " +
                            "GROUP BY TG004, MA002, TH004, SUBSTRING(TG003,1,6) " +
                        ")GroupTable " +
                        "PIVOT " +
                        "(SUM(數量) FOR [DATE] IN (" + strField + "))PivotTable";
            DataTable dt = db.ExecuteDataTable();

            //SQL-累計未銷售數量
            db.StrSQL = "SELECT TC004 [客戶代號], MA002 [客戶簡稱], TD004 [品號], SUM(TD008 - TD009) [累計未銷售數量] " +
                        "FROM COPTC c " +
                        "INNER JOIN COPTD d ON d.TD001=c.TC001 AND d.TD002=c.TC002 " +
                        "INNER JOIN COPMA a ON a.MA001=c.TC004 " +
                        "INNER JOIN INVMB b ON b.MB001=d.TD004 " +
                        "WHERE c.TC027='Y' AND d.TD016='N' AND b.MB005='5' AND a.MA016=@業務員 " +
                        "GROUP BY TC004, MA002, TD004 " +
                        "HAVING SUM(TD008 - TD009) > 0";
            DataTable dt1 = db.ExecuteDataTable();

            //SQL-預測數量
            db.StrSQL = "SELECT ME002 [客戶代號], MA002 [客戶簡稱], MF003 [品號], SUM(MF008) [預測數量] " +
                        "FROM COPME e " +
                        "INNER JOIN COPMF f ON f.MF001=e.ME001 " +
                        "INNER JOIN COPMA a ON a.MA001=e.ME002 " +
                        "INNER JOIN INVMB b ON b.MB001=f.MF003 " +
                        "WHERE e.ME014='1' AND b.MB005='5' AND e.ME007=@業務員 AND SUBSTRING(MF006,1,6)=@期間 " +
                        "GROUP BY ME002, MA002, MF003";
            DataTable dt2 = db.ExecuteDataTable();
            #endregion

            #region 寫入累計未銷售數量
            foreach (DataRow row in dt1.Rows)
            {
                string strWhere = string.Format("客戶代號='{0}' AND 品號='{1}'", row["客戶代號"], row["品號"]);
                DataRow[] rows = dt.Select(strWhere);
                if (rows.Length > 0)
                {
                    rows[0]["累計未銷售數量"] = row["累計未銷售數量"];
                }
                else
                {
                    DataRow newRow = dt.NewRow();
                    newRow["客戶代號"] = row["客戶代號"];
                    newRow["客戶簡稱"] = row["客戶簡稱"];
                    newRow["品號"] = row["品號"];
                    newRow["累計未銷售數量"] = row["累計未銷售數量"];

                    dt.Rows.Add(newRow);
                }
            }
            #endregion

            #region 寫入預測數量
            foreach (DataRow row in dt2.Rows)
            {
                string strWhere = string.Format("客戶代號='{0}' AND 品號='{1}'", row["客戶代號"], row["品號"]);
                DataRow[] rows = dt.Select(strWhere);
                if (rows.Length > 0)
                {
                    rows[0]["預測數量"] = row["預測數量"];
                }
                else
                {
                    DataRow newRow = dt.NewRow();
                    newRow["客戶代號"] = row["客戶代號"];
                    newRow["客戶簡稱"] = row["客戶簡稱"];
                    newRow["品號"] = row["品號"];
                    newRow["預測數量"] = row["預測數量"];

                    dt.Rows.Add(newRow);
                }
            }
            #endregion

            return dt;
        }

        /// <summary>取得銷售預測資料-依類別</summary>
        public static DataTable GetSellingDivinationByClass(string 期間, string 業務員)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("期間", 期間);
            param.Add("業務員", 業務員);
            db.SqlParams = param;

            #region 指定日期往前減三個月
            //轉換日期物件
            DateTime date = Convert.ToDateTime(期間.Substring(0, 4) + "/" + 期間.Substring(4, 2) + "/" + "01");

            string strField = "", strCondition = "";
            for (int i = 3; i >= 0; i--)
            {
                string strMM = date.AddMonths(0 - i).ToString("yyyyMM");

                strField += "[" + strMM + "],";
                strCondition += "'" + strMM + "',";
            }
            strField = strField.Trim(',');
            strCondition = strCondition.Trim(',');
            #endregion

            #region 分批撈數量
            //SQL-銷售數量
            db.StrSQL = "SELECT [客戶代號],[客戶簡稱],[類別代號],[類別名稱]," + strField + " [本月銷售數量],null [累計未銷售數量],null [預測數量] FROM( " +
                            "SELECT TG004 [客戶代號], a.MA002 [客戶簡稱], m.MA002 [類別代號], m.MA003 [類別名稱], SUBSTRING(TG003,1,6) [DATE], SUM(TH008) [數量] " +
                            "FROM COPTG g " +
                            "INNER JOIN COPTH h ON h.TH001=g.TG001 AND h.TH002=g.TG002 " +
                            "INNER JOIN COPMA a ON a.MA001=g.TG004 " +
                            "INNER JOIN INVMB b ON b.MB001=h.TH004 " +
                            "INNER JOIN INVMA m ON m.MA002=b.MB005 " +
                            "WHERE TG023='Y' AND TH020='Y' AND a.MA016=@業務員 AND (SUBSTRING(TG003,1,6) IN (" + strCondition + ")) " +
                            "GROUP BY TG004, a.MA002, m.MA002, m.MA003, SUBSTRING(TG003,1,6) " +
                        ")GroupTable " +
                        "PIVOT " +
                        "(SUM(數量) FOR [DATE] IN (" + strField + "))PivotTable";
            DataTable dt = db.ExecuteDataTable();

            //SQL-累計未銷售數量
            db.StrSQL = "SELECT c.TC004 [客戶代號], a.MA002 [客戶簡稱], m.MA002 [類別代號], m.MA003 [類別名稱], SUM(TD008 - TD009) [累計未銷售數量] " +
                        "FROM COPTC c " +
                        "INNER JOIN COPTD d ON d.TD001=c.TC001 AND d.TD002=c.TC002 " +
                        "INNER JOIN COPMA a ON a.MA001=c.TC004 " +
                        "INNER JOIN INVMB b ON b.MB001=d.TD004 " +
                        "INNER JOIN INVMA m ON m.MA002=b.MB005 " +
                        "WHERE c.TC027='Y' AND d.TD016='N' AND a.MA016=@業務員 " +
                        "GROUP BY c.TC004, a.MA002, m.MA002, m.MA003 " +
                        "HAVING SUM(TD008 - TD009) > 0";
            DataTable dt1 = db.ExecuteDataTable();

            //SQL-預測數量
            db.StrSQL = "SELECT e.ME002 [客戶代號], a.MA002 [客戶簡稱], m.MA002 [類別代號], m.MA003 [類別名稱], SUM(MF008) [預測數量] " +
                        "FROM COPME e " +
                        "INNER JOIN COPMF f ON f.MF001=e.ME001 " +
                        "INNER JOIN COPMA a ON a.MA001=e.ME002 " +
                        "INNER JOIN INVMA m ON m.MA002=f.MF016 " +
                        "WHERE e.ME014='2' AND e.ME007=@業務員 AND SUBSTRING(MF006,1,6)=@期間 " +
                        "GROUP BY e.ME002, a.MA002, m.MA002, m.MA003";
            DataTable dt2 = db.ExecuteDataTable();
            #endregion

            #region 寫入累計未銷售數量
            foreach (DataRow row in dt1.Rows)
            {
                string strWhere = string.Format("客戶代號='{0}' AND 類別代號='{1}'", row["客戶代號"], row["類別代號"]);
                DataRow[] rows = dt.Select(strWhere);
                if (rows.Length > 0)
                {
                    rows[0]["累計未銷售數量"] = row["累計未銷售數量"];
                }
                else
                {
                    DataRow newRow = dt.NewRow();
                    newRow["客戶代號"] = row["客戶代號"];
                    newRow["客戶簡稱"] = row["客戶簡稱"];
                    newRow["類別代號"] = row["類別代號"];
                    newRow["類別名稱"] = row["類別名稱"];
                    newRow["累計未銷售數量"] = row["累計未銷售數量"];

                    dt.Rows.Add(newRow);
                }
            }
            #endregion

            #region 寫入預測數量
            foreach (DataRow row in dt2.Rows)
            {
                string strWhere = string.Format("客戶代號='{0}' AND 類別代號='{1}'", row["客戶代號"], row["類別代號"]);
                DataRow[] rows = dt.Select(strWhere);
                if (rows.Length > 0)
                {
                    rows[0]["預測數量"] = row["預測數量"];
                }
                else
                {
                    DataRow newRow = dt.NewRow();
                    newRow["客戶代號"] = row["客戶代號"];
                    newRow["客戶簡稱"] = row["客戶簡稱"];
                    newRow["類別代號"] = row["類別代號"];
                    newRow["類別名稱"] = row["類別名稱"];
                    newRow["預測數量"] = row["預測數量"];

                    dt.Rows.Add(newRow);
                }
            }
            #endregion

            return dt;
        }

        /// <summary>匯入銷售預測資料-依品號</summary>
        public static void ImportSellingDivinationToProduct(string 日期, DataTable dt, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //只取出相異的客戶代號
                DataTable dtCustomCode = dt.DefaultView.ToTable(true, "客戶代號");

                //循序讀取客戶代號
                foreach (DataRow rowCustomCode in dtCustomCode.Rows)
                {
                    string strCustomCode = rowCustomCode["客戶代號"].ToString().Trim(); //客戶代號

                    //判斷當月是否有已存在的客戶代號，若有則刪除原單據
                    cmd.CommandText = "DECLARE @KeyCode varchar(15); " +
                                      "SET @KeyCode = (SELECT ME001 FROM COPME WHERE ME001 LIKE '" + 日期 + "%' AND ME002='" + strCustomCode + "' AND ME014=1); " +
                                      "IF(@KeyCode IS NOT NULL) BEGIN " +
                                          "DELETE FROM COPME WHERE ME001=@KeyCode; " +
                                          "DELETE FROM COPMF WHERE MF001=@KeyCode; " +
                                      "END ";
                    cmd.ExecuteNonQuery();

                    //取出當月的最後預測代號
                    string strKeyVal = "";
                    cmd.CommandText = "SELECT TOP 1 ME001 FROM COPME WHERE ME001 LIKE '" + 日期 + "%' ORDER BY ME001 DESC";
                    object objKeyVal = cmd.ExecuteScalar();
                    if (objKeyVal == null) { strKeyVal = 日期 + "0001"; }
                    else { strKeyVal = Tool.GetPadLeftString(objKeyVal.ToString().Trim(), 1); }

                    //找出符合客戶代號的資料
                    DataRow[] rowList = dt.Select("客戶代號='" + strCustomCode + "' AND 預測數量 IS NOT NULL");
                    if (rowList.Length > 0)
                    {
                        //增加SQL參數
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add(new SqlParameter("預測代號", strKeyVal));
                        cmd.Parameters.Add(new SqlParameter("客戶代號", strCustomCode));

                        //建立銷售預測單頭檔
                        cmd.CommandText = "INSERT COPME(FLAG, ME001, ME002, ME003, ME004, ME005, ME006, ME007, ME008, ME009, ME010, ME011, ME012, ME013, ME014) " +
                                          "SELECT 1, @預測代號, @客戶代號, MA017, MA018, MA019, MA015, MA016, 'N', '', MA076, MA077, MA078, '001', 1 FROM COPMA a WHERE a.MA001=@客戶代號";
                        cmd.ExecuteNonQuery();

                        //循序讀取品號資料
                        string strItemNo = "0000";
                        foreach (DataRow row in rowList)
                        {
                            strItemNo = Tool.GetPadLeftString(strItemNo, 1);
                            string strProduct = row["品號"].ToString().Trim(); //品號
                            string strQty = row["預測數量"].ToString().Trim(); //數量

                            //增加SQL參數
                            cmd.Parameters.Clear();
                            cmd.Parameters.Add(new SqlParameter("預測代號", strKeyVal));
                            cmd.Parameters.Add(new SqlParameter("項次", strItemNo));
                            cmd.Parameters.Add(new SqlParameter("品號", strProduct));
                            cmd.Parameters.Add(new SqlParameter("數量", strQty));
                            cmd.Parameters.Add(new SqlParameter("日期", 日期 + "01"));

                            //建立銷售預測單身檔
                            cmd.CommandText = "INSERT COPMF(FLAG, MF001, MF002, MF003, MF004, MF005, MF006, MF007, MF008, MF009, MF010, MF011, MF012, MF013, MF014, MF015, MF016, MF017, MF018, MF019, MF020) " +
                                              "SELECT 1, @預測代號, @項次, @品號, MB002, MB003, @日期, MB017, @數量, 0, MB004, 'NT$', MB047, '', @數量 * MB047, 0, MB005, MB006, MB007, MB008, 'N' FROM INVMB b WHERE b.MB001=@品號";
                            cmd.ExecuteNonQuery();
                        }
                    }
                }

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>匯入銷售預測資料-依類別</summary>
        public static void ImportSellingDivinationToClass(string 日期, DataTable dt, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //只取出相異的客戶代號
                DataTable dtCustomCode = dt.DefaultView.ToTable(true, "客戶代號");

                //循序讀取客戶代號
                foreach (DataRow rowCustomCode in dtCustomCode.Rows)
                {
                    string strCustomCode = rowCustomCode["客戶代號"].ToString().Trim(); //客戶代號

                    //判斷當月是否有已存在的客戶代號，若有則刪除原單據
                    cmd.CommandText = "DECLARE @KeyCode varchar(15); " +
                                      "SET @KeyCode = (SELECT ME001 FROM COPME WHERE ME001 LIKE '" + 日期 + "%' AND ME002='" + strCustomCode + "' AND ME014=2); " +
                                      "IF(@KeyCode IS NOT NULL) BEGIN " +
                                          "DELETE FROM COPME WHERE ME001=@KeyCode; " +
                                          "DELETE FROM COPMF WHERE MF001=@KeyCode; " +
                                      "END ";
                    cmd.ExecuteNonQuery();

                    //取出當月的最後預測代號
                    string strKeyVal = "";
                    cmd.CommandText = "SELECT TOP 1 ME001 FROM COPME WHERE ME001 LIKE '" + 日期 + "%' ORDER BY ME001 DESC";
                    object objKeyVal = cmd.ExecuteScalar();
                    if (objKeyVal == null) { strKeyVal = 日期 + "0001"; }
                    else { strKeyVal = Tool.GetPadLeftString(objKeyVal.ToString().Trim(), 1); }

                    //找出符合客戶代號的資料
                    DataRow[] rowList = dt.Select("客戶代號='" + strCustomCode + "' AND 預測數量 IS NOT NULL");
                    if (rowList.Length > 0)
                    {
                        //增加SQL參數
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add(new SqlParameter("預測代號", strKeyVal));
                        cmd.Parameters.Add(new SqlParameter("客戶代號", strCustomCode));

                        //建立銷售預測單頭檔
                        cmd.CommandText = "INSERT COPME(FLAG, ME001, ME002, ME003, ME004, ME005, ME006, ME007, ME008, ME009, ME010, ME011, ME012, ME013, ME014) " +
                                          "SELECT 1, @預測代號, @客戶代號, MA017, MA018, MA019, MA015, MA016, 'N', '', MA076, MA077, MA078, '001', 2 FROM COPMA a WHERE a.MA001=@客戶代號";
                        cmd.ExecuteNonQuery();

                        //循序讀取品號資料
                        string strItemNo = "0000";
                        foreach (DataRow row in rowList)
                        {
                            strItemNo = Tool.GetPadLeftString(strItemNo, 1);
                            string strClassCode = row["類別代號"].ToString().Trim(); //類別代號
                            string strQty = row["預測數量"].ToString().Trim(); //數量

                            //不匯入代號5的資料
                            if (strClassCode != "5")
                            {
                                //增加SQL參數
                                cmd.Parameters.Clear();
                                cmd.Parameters.Add(new SqlParameter("預測代號", strKeyVal));
                                cmd.Parameters.Add(new SqlParameter("項次", strItemNo));
                                cmd.Parameters.Add(new SqlParameter("類別代號", strClassCode));
                                cmd.Parameters.Add(new SqlParameter("數量", strQty));
                                cmd.Parameters.Add(new SqlParameter("日期", 日期 + "01"));

                                //建立銷售預測單身檔
                                cmd.CommandText = "INSERT COPMF(FLAG, MF001, MF002, MF003, MF004, MF005, MF006, MF007, MF008, MF009, MF010, MF011, MF012, MF013, MF014, MF015, MF016, MF017, MF018, MF019, MF020) " +
                                                  "VALUES(1, @預測代號, @項次, '********************', '', '', @日期, '', @數量, 0, 'EA', 'NT$', 0, '', 0, 0, @類別代號, '', '', '', 'N')";
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                }

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>匯出RMA分析資料</summary>
        public static DataSet ExportRMARateData(string S製造期間, string E製造期間, string S出貨期間, string E出貨期間, string S借入期間, string E借入期間, string 品號, string 版次, string 客戶代號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("S製造期間", Tool.GetDBNullString(S製造期間));
            param.Add("E製造期間", Tool.GetDBNullString(E製造期間));
            param.Add("S出貨期間", Tool.GetDBNullString(S出貨期間));
            param.Add("E出貨期間", Tool.GetDBNullString(E出貨期間));
            param.Add("S借入期間", Tool.GetDBNullString(S借入期間));
            param.Add("E借入期間", Tool.GetDBNullString(E借入期間));
            param.Add("客戶代號", Tool.GetDBNullString(客戶代號));
            param.Add("品號", 品號 + "%");
            param.Add("版次", Tool.GetDBNullString(版次));
            db.SqlParams = param;

            //查詢條件
            string strWHERE = "";
            if (!string.IsNullOrEmpty(S製造期間) && !string.IsNullOrEmpty(E製造期間)) { strWHERE += " AND (Substring(SerialNo,1,2) BETWEEN @S製造期間 AND @E製造期間)"; }
            if (!string.IsNullOrEmpty(版次)) { strWHERE += " AND (Substring(SerialNo,6,1)=@版次)"; }

            //出貨序號
            db.StrSQL = "SELECT [公司別], [銷貨單別], [銷貨單號], [客戶代號], [客戶全名], [品號], i.SerialNo [序號], CASE WHEN i.SerialNo IS NULL THEN [Qty] ELSE 1 END [Qty] FROM (" +
                            "SELECT g.COMPANY [公司別], TG001 [銷貨單別], TG002 [銷貨單號], TG003 [銷貨日期], TH003 [項次], TG004 [客戶代號], TG007 [客戶全名], RTRIM(TH004) [品號], TH008 [Qty] FROM {DBName1}COPTG g, {DBName1}COPTH h " +
                            "WHERE TH001=TG001 AND TH002=TG002 AND TG023='Y' AND TH020='Y' " +
                            "UNION ALL " +
                            "SELECT g.COMPANY [公司別], TG001 [銷貨單別], TG002 [銷貨單號], TG003 [銷貨日期], TH003 [項次], TG004 [客戶代號], TG007 [客戶全名], RTRIM(TH004) [品號], TH008 [Qty] FROM {DBName2}COPTG g, {DBName2}COPTH h " +
                            "WHERE TH001=TG001 AND TH002=TG002 AND TG023='Y' AND TH020='Y' " +
                        ") r " +
                        "LEFT OUTER JOIN SerialNoItem i ON i.Company=r.公司別 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                          "ERPClass=r.銷貨單別 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                          "ERPNumber=r.銷貨單號 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                          "ERPItemNo=r.項次 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                        "WHERE 銷貨單別='2310' AND (客戶全名 NOT LIKE 'UHRlamps%' AND 客戶全名 NOT LIKE 'Arclite%') {WHERE1} {WHERE2} {WHERE3} {WHERE4} {WHERE5}";
            db.StrSQL = db.StrSQL.Replace("{DBName1}", Definition.ERPDBName)
                                 .Replace("{DBName2}", Definition.UHRlampsDBName)
                                 .Replace("{WHERE1}", (!string.IsNullOrEmpty(S出貨期間) && !string.IsNullOrEmpty(E出貨期間)) ? " AND (r.銷貨日期 BETWEEN @S出貨期間 AND @E出貨期間)" : "")
                                 .Replace("{WHERE2}", (!string.IsNullOrEmpty(客戶代號)) ? " AND (r.客戶代號=@客戶代號)" : "")
                                 .Replace("{WHERE3}", (!string.IsNullOrEmpty(品號)) ? " AND (r.品號 LIKE @品號)" : "")
                                 .Replace("{WHERE4}", (!string.IsNullOrEmpty(版次)) ? " AND (Substring(i.SerialNo,6,1)=@版次)" : "")
                                 .Replace("{WHERE5}", (!string.IsNullOrEmpty(S製造期間) && !string.IsNullOrEmpty(E製造期間)) ? " AND (Substring(i.SerialNo,1,2) BETWEEN @S製造期間 AND @E製造期間)" : "");
            DataTable dtSell = db.ExecuteDataTable();
            dtSell.TableName = "Sell";

            //RMA序號
            db.StrSQL = "SELECT r.公司別, r.單號, RTRIM(i.ProductNo) [品號], i.SerialNo [序號], Substring(i.SerialNo,6,1) [版次], r.客戶代號, r.客戶全名, 1 [Qty], rc.enName [RMA Reason], rc1.enName [QA RMA Reason], i.Remark " +
                        "FROM(SELECT COMPANY [公司別], TF001+'-'+TF002 [單號], TF005 [客戶代號], TF015 [客戶全名], TF003 [單據日期] FROM {DBName1}INVTF WHERE TF020='Y' UNION " +
                             "SELECT COMPANY [公司別], TI001+'-'+TI002 [單號], TI004 [客戶代號], TI021 [客戶全名], TI003 [單據日期] FROM {DBName1}COPTI WHERE TI019='Y' UNION " +
                             "SELECT COMPANY [公司別], TF001+'-'+TF002 [單號], TF005 [客戶代號], TF015 [客戶全名], TF003 [單據日期] FROM {DBName2}INVTF WHERE TF020='Y' UNION " +
                             "SELECT COMPANY [公司別], TI001+'-'+TI002 [單號], TI004 [客戶代號], TI021 [客戶全名], TI003 [單據日期] FROM {DBName2}COPTI WHERE TI019='Y' " +
                        ") r " +
                        "LEFT OUTER JOIN SerialNoItem i ON i.Company=r.公司別 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                     "i.ERPClass+'-'+i.ERPNumber=r.單號 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                        "LEFT OUTER JOIN ReasonCode rc ON rc.Code=i.ReasonCode " +
                        "LEFT OUTER JOIN ReasonCode rc1 ON rc1.Code=i.ReasonCodeQA " +
                        "WHERE (客戶全名 NOT LIKE 'UHRlamps%' AND 客戶全名 NOT LIKE 'Arclite%') {WHERE1} {WHERE2} {WHERE3} {WHERE4} {WHERE5}";
            db.StrSQL = db.StrSQL.Replace("{DBName1}", Definition.ERPDBName)
                                 .Replace("{DBName2}", Definition.UHRlampsDBName)
                                 .Replace("{WHERE1}", (!string.IsNullOrEmpty(S借入期間) && !string.IsNullOrEmpty(E借入期間)) ? " AND (r.單據日期 BETWEEN @S借入期間 AND @E借入期間)" : "")
                                 .Replace("{WHERE2}", (!string.IsNullOrEmpty(客戶代號)) ? " AND (r.客戶代號=@客戶代號)" : "")
                                 .Replace("{WHERE3}", (!string.IsNullOrEmpty(品號)) ? " AND (i.ProductNo LIKE @品號)" : "")
                                 .Replace("{WHERE4}", (!string.IsNullOrEmpty(版次)) ? " AND (Substring(i.SerialNo,6,1)=@版次)" : "")
                                 .Replace("{WHERE5}", (!string.IsNullOrEmpty(S製造期間) && !string.IsNullOrEmpty(E製造期間)) ? " AND (Substring(i.SerialNo,1,2) BETWEEN @S製造期間 AND @E製造期間)" : "");
            DataTable dtRMA = db.ExecuteDataTable();
            dtRMA.TableName = "RMA";

            DataSet ds = new DataSet();
            ds.Tables.Add(dtSell);
            ds.Tables.Add(dtRMA);

            return ds;
        }

        /// <summary>匯出各月RMA統計表</summary>
        public static DataTable ExportMonthRMARateData(string S製造期間, string E製造期間, string S出貨期間, string E出貨期間, string 品號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("S製造期間", Tool.GetDBNullString(S製造期間));
            param.Add("E製造期間", Tool.GetDBNullString(E製造期間));
            param.Add("S出貨期間", Tool.GetDBNullString(S出貨期間));
            param.Add("E出貨期間", Tool.GetDBNullString(E出貨期間));
            param.Add("品號", 品號 + "%");
            db.SqlParams = param;

            //查詢條件
            string strWHERE = "";
            if (!string.IsNullOrEmpty(S出貨期間) && !string.IsNullOrEmpty(E出貨期間)) { strWHERE += " AND (r.TG003 BETWEEN @S出貨期間 AND @E出貨期間)"; }
            if (!string.IsNullOrEmpty(S製造期間) && !string.IsNullOrEmpty(E製造期間)) { strWHERE += " AND (Substring(i.SerialNo,1,2) BETWEEN @S製造期間 AND @E製造期間)"; }

            SqlCommand cmd = db.SqlCommand;
            cmd.CommandText = "SELECT r.Company [公司別], LEFT(TG003,6) [銷貨年月], (TG001+'-'+TG002) [銷貨單號], TG004 [客戶代號], TG007 [客戶全名], a.MA003 [品保分類], TH004 [品號], TH006 [規格], CASE WHEN i.SerialNo IS NULL THEN TH008 ELSE 1 END [Qty], i.SerialNo [序號], LEFT(i.SerialNo,2) [製造期間], Substring(i.SerialNo,6,1) [版次] " +
                              "INTO #Sell FROM(" +
                                              "SELECT g.COMPANY, TG001, TG002, TG003, TG004, TG007, TH003, TH004, TH006, TH008, TH020 FROM {DBName1}COPTG g, {DBName1}COPTH h WHERE TG001=TH001 AND TG002=TH002 " +
                                              "UNION ALL " +
                                              "SELECT g.COMPANY, TG001, TG002, TG003, TG004, TG007, TH003, TH004, TH006, TH008, TH020 FROM {DBName2}COPTG g, {DBName2}COPTH h WHERE TG001=TH001 AND TG002=TH002) r " +
                              "INNER JOIN {DBName1}INVMB b ON b.MB001=r.TH004 " +
                              "INNER JOIN {DBName1}INVMA a ON a.MA001='2' AND a.MA002=b.MB006 " +
                              "LEFT OUTER JOIN SerialNoItem i ON i.Company=r.Company COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                "i.ERPClass=r.TG001 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                "i.ERPNumber=r.TG002 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                "i.ERPItemNo=r.TH003 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                              "WHERE r.TG001='2310' AND TH020='Y' AND (TG007 NOT LIKE 'UHRlamps%' AND TG007 NOT LIKE 'Arclite%') AND r.TH004 LIKE @品號 " + strWHERE + "; " +

                              "SELECT s.*, (i.ERPClass+'-'+i.ERPNumber) [RMA單號], rc.enName [RMA Reason], rc1.enName [QA RMA Reason], i.Remark FROM #Sell s " +
                              "LEFT OUTER JOIN SerialNoItem i ON i.SerialNo=s.序號 AND (i.ERPClass IN ('1401','2410')) " +
                              "LEFT OUTER JOIN (SELECT COMPANY, TF001, TF002, TF015 FROM {DBName1}INVTF WHERE TF020='Y' UNION " +
                                               "SELECT COMPANY, TI001, TI002, TI021 FROM {DBName1}COPTI WHERE TI019='Y' UNION " +
                                               "SELECT COMPANY, TF001, TF002, TF015 FROM {DBName2}INVTF WHERE TF020='Y' UNION " +
                                               "SELECT COMPANY, TI001, TI002, TI021 FROM {DBName2}COPTI WHERE TI019='Y') v ON v.Company=i.Company COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                                                             "v.TF001=i.ERPClass COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                                                             "v.TF002=i.ERPNumber COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                                                             "(v.TF015 NOT LIKE 'UHRlamps%' AND v.TF015 NOT LIKE 'Arclite%') " +
                              "LEFT OUTER JOIN ReasonCode rc ON rc.Code=i.ReasonCode " +
                              "LEFT OUTER JOIN ReasonCode rc1 ON rc1.Code=i.ReasonCodeQA";

            cmd.CommandText = cmd.CommandText.Replace("{DBName1}", Definition.ERPDBName)
                                             .Replace("{DBName2}", Definition.UHRlampsDBName);

            DataTable dt = new DataTable();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(dt);

            return dt;
        }

        /// <summary>取得借入單的單頭列表</summary>
        public static DataTable GetBorrowHeadList(string 公司別, string 單別, string 單號, string 確認碼, string 客戶代碼, string 員工代碼, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號 + "%");
            param.Add("確認碼", 確認碼);
            param.Add("客戶代碼", 客戶代碼);
            param.Add("員工代碼", 員工代碼);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND f.TF001=@單別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND f.TF002 LIKE @單號"; }
            if (!string.IsNullOrEmpty(確認碼)) { strWhere += " AND f.TF020=@確認碼"; }
            if (!string.IsNullOrEmpty(客戶代碼)) { strWhere += " AND f.TF005=@客戶代碼"; }
            if (!string.IsNullOrEmpty(員工代碼)) { strWhere += " AND f.TF008=@員工代碼"; }

            //SQL
            string strSQL = "SELECT f.TF001 [單別], f.TF002 [單號], f.TF003 [日期], f.TF005 [客戶代碼], f.TF006 [客戶簡稱], f.TF008 [員工代號], v.MV002 [員工姓名], f.TF011 [幣別], f.TF014 [備註], f.TF020 [確認碼], CAST(ROUND(f.TF022,0) AS Int) [總數量] " +
                            "FROM INVTF f " +
                            "INNER JOIN CMSMV v ON v.MV001=f.TF008 " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "日期 DESC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>刪除借入單的單身資料</summary>
        public static bool DeleteBorrowData(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "DELETE FROM INVTG WHERE TG001=@單別 AND TG002=@單號";
            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>新增借入單的單身資料</summary>
        public static bool InsertBorrowData(string 公司別, string 單別, string 單號, string 項次, string 品號, int 數量, string 預計歸還日, string 備註)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("項次", 項次);
            param.Add("品號", 品號.Trim());
            param.Add("轉出庫", c.RmaOutHouse);
            param.Add("轉入庫", c.RmaInHouse);
            param.Add("數量", 數量);
            param.Add("批號", "RMA" + 單號);
            param.Add("預計歸還日", 預計歸還日);
            param.Add("備註", 備註.Trim());
            db.SqlParams = param;

            db.StrSQL = "DECLARE @營業稅率 numeric(8,5); " +
                        "SELECT @營業稅率=TF026 FROM INVTF WHERE TF001=@單別 AND TF002=@單號; " +
                        "INSERT INVTG(FLAG, TG001, TG002, TG003, TG004, TG005, TG006, TG007, TG008, TG009, TG010, TG011, TG012, TG013, TG014, TG015, TG016, TG017, TG018, TG019, TG020, TG021, TG022, TG023, TG024, TG025, TG026, TG027, TG042) " +
                        "SELECT 1, @單別, @單號, @項次, @品號, MB002, MB003, @轉出庫, @轉入庫, @數量, MB004, MB072, 0, 0, '', '', '', @批號, '', @備註, 0, 0, 'N', 'N', 'N', '', '', @預計歸還日, @營業稅率 FROM INVMB WHERE MB001=@品號";
            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>重計借入單的單頭小計</summary>
        public static void SubtotalBorrowQty(string 公司別, string 單別, string 單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            db.StrSQL = "DECLARE @Qty int; " +
                        "SET @Qty = (SELECT SUM(TG009) FROM INVTG WHERE TG001=@單別 AND TG002=@單號); " +
                        "IF @Qty IS NULL BEGIN SET @Qty = 0; END " +
                        "UPDATE INVTF SET TF022=@Qty WHERE TF001=@單別 AND TF002=@單號";
            db.ExecuteSQL();
        }

        /// <summary>取得製令單資料</summary>
        public static DataTable GetManufactureForm(string 單別, string 單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND a.TA001=@單別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND a.TA002=@單號"; }

            //SQL
            db.StrSQL = "SELECT a.TA001 [製令單別], a.TA002 [製令單號], a.TA006 [品號] " +
                        "FROM MOCTA a " +
                        "WHERE a.TA011='1' AND a.TA013='Y'" + strWhere;

            return db.ExecuteDataTable();
        }

        /// <summary>取得ERP帳號資料</summary>
        public static DataTable GetEmployee(string 工號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("工號", 工號);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT MA001 [工號], MA002 [姓名] FROM ERP.DSCSYS.dbo.DSCMA WHERE MA001=@工號";
            return db.ExecuteDataTable();
        }
    }
}