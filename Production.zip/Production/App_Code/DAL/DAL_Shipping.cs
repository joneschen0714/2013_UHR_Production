﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR.Util;

namespace UHR
{
    public class DAL_Shipping
    {
        public DAL_Shipping()
        {

        }

        #region 出貨通知單
        /// <summary>取得出貨通知單列表</summary>
        public static DataTable GetShippingAdviseList(string 公司別, string 單號, string 客戶代號, string 狀態碼, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //取得公司別物件
            Company c = CompanyCollection.Get(公司別);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("客戶代號", 客戶代號);
            param.Add("狀態碼", 狀態碼);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND FormNo=@單號"; }
            if (!string.IsNullOrEmpty(客戶代號)) { strWhere += " AND CustomCode=@客戶代號"; }
            if (!string.IsNullOrEmpty(狀態碼)) { strWhere += " AND Status=@狀態碼"; }

            //SQL
            string strSQL = "SELECT FormNo, CustomCode, CustomName, ShippingDate, Status, outFormNum, " +
                                "(SELECT ISNULL(SUM(Qty),0) FROM s_ShippingAdviseItem WHERE Company=@公司別 AND FormNo=a.FormNo) [TotalQty], " +
                                "(SELECT ISNULL(SUM(Qty),0) FROM s_PackingList WHERE Company=@公司別 AND FormNo=a.FormNo AND Type='General') [PackingQty] " +
                            "FROM s_ShippingAdvise a " +
                            "WHERE Company=@公司別 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, _sort, _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>修改出貨通知單</summary>
        public static void ModifyShippingAdvise(string 公司別, string 單號, string 客戶代號, string 客戶名稱, DateTime 預計出貨日, string 狀態碼)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("客戶代號", 客戶代號);
            param.Add("客戶名稱", 客戶名稱);
            param.Add("預計出貨日", 預計出貨日.ToShortDateString());
            param.Add("狀態碼", 狀態碼);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "IF Exists(SELECT * FROM s_ShippingAdvise WHERE Company=@公司別 AND FormNo=@單號) BEGIN " +
                            "UPDATE s_ShippingAdvise SET ShippingDate=@預計出貨日, Status=@狀態碼, Updater=@Updater, UpdateTime=getdate() WHERE Company=@公司別 AND FormNo=@單號; " +
                        "END ELSE BEGIN " +
                            "INSERT s_ShippingAdvise(Company, FormNo, CustomCode, CustomName, ShippingDate, Status, Creater, CreateTime, Updater, UpdateTime) VALUES(@公司別, @單號, @客戶代號, @客戶名稱, @預計出貨日, @狀態碼, @Updater, getdate(), @Updater, getdate()); " +
                        "END";

            db.ExecuteSQL();
        }

        /// <summary>更新出口單號</summary>
        public static void ModifyShippingSellingNumber(string 公司別, string 單號, string 出口單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("出口單號", 出口單號);
            db.SqlParams = param;

            db.StrSQL = "UPDATE s_ShippingAdvise SET outFormNum=@出口單號 WHERE Company=@公司別 AND FormNo=@單號";
            db.ExecuteSQL();
        }

        /// <summary>取得新的出貨通知單號</summary>
        public static string GetNewShippingAdviseNo(string 公司別)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", DateTime.Today.ToString("yyMMdd") + "%");
            db.SqlParams = param;

            db.StrSQL = "SELECT TOP 1 FormNo FROM s_ShippingAdvise WHERE Company=@公司別 AND FormNo LIKE @單號 ORDER BY FormNo DESC";

            //組成單號
            string 單號 = db.ExecuteScalar();
            if (string.IsNullOrEmpty(單號))
                單號 = DateTime.Today.ToString("yyMMdd") + "0001";
            else
                單號 = Tool.GetPadLeftString(單號, 1);

            return 單號;
        }
        #endregion

        #region 出貨通知單明細
        /// <summary>取得出貨通知單明細列表</summary>
        public static DataTable GetShippingAdviseItemList(string 公司別, string 單號, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            //SQL
            string strSQL = "SELECT * FROM s_ShippingAdviseItem i WHERE Company=@公司別 AND FormNo=@單號";

            DataTable dtResult = db.ExecuteDataTable(strSQL, "BaseClass, BaseNumber, ProductNo", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得出貨通知單的可選未結案清單</summary>
        public static DataTable GetShippingAdviseBaseItemList(string 公司別, string 出貨通知單號, string 單別, string 單號, string 客戶代號, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //取得公司別物件
            Company c = CompanyCollection.Get(公司別);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("出貨通知單號", 出貨通知單號);
            param.Add("客戶代號", 客戶代號);
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (單別 != "") { strWhere += " AND TD001=@單別"; }
            if (單號 != "") { strWhere += " AND TD002=@單號"; }

            //訂單SQL
            string strSQL = "SELECT TD001 [來源單別], TD002 [來源單號], TD003 [來源項次], TD004 [品號], TD005 [品名], RTRIM(TB201) [客戶商品描述], CAST((TD008 + TD024 + TD050) AS int) [數量], Qty [已交數量], TD020 [備註] FROM " + c.DBName + "COPTC " +
                            "INNER JOIN " + c.DBName + "COPTD ON TC001=TD001 AND TC002=TD002 " +
                            "INNER JOIN " + c.DBName + "COPTB ON TD017=TB001 AND TD018=TB002 AND TD019=TB003 " +
                            "LEFT OUTER JOIN (Select BaseClass, BaseNumber, BaseItemNo, Sum(Qty) [Qty] " +
                                             "From s_ShippingAdviseItem b, s_ShippingAdvise h " +
                                             "Where h.Company=b.Company And h.FormNo=b.FormNo And h.Company=@公司別 And h.Status<>'V' And h.FormNo <> @出貨通知單號 " +
                                             "Group By BaseClass, BaseNumber, BaseItemNo) i ON BaseClass=TD001 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                              "BaseNumber=TD002 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                              "BaseItemNo=TD003 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                            "WHERE TC004=@客戶代號 AND TC027='Y' AND TD016='N' AND ((TD008 + TD024 + TD050) <> ISNULL(Qty,0)) " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "來源單別, 來源單號, 來源項次", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>刪除出貨通知單的明細資料</summary>
        public static bool DeleteShippingAdviseItem(string 公司別, string 出貨通知單號, string 單別, string 單號, string 項次, string 品號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("出貨通知單號", 出貨通知單號);
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("項次", 項次);
            param.Add("品號", 品號);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(出貨通知單號)) { strWhere += " AND FormNo=@出貨通知單號"; }
            if (!string.IsNullOrEmpty(單別)) { strWhere += " AND BaseClass=@單別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND BaseNumber=@單號"; }
            if (!string.IsNullOrEmpty(項次)) { strWhere += " AND BaseItemNo=@項次"; }
            if (!string.IsNullOrEmpty(品號)) { strWhere += " AND ProductNo=@品號"; }

            db.StrSQL = "DELETE FROM s_ShippingAdviseItem WHERE Company=@公司別 " + strWhere;
            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>新增出貨通知單的明細資料</summary>
        public static bool InsertShippingAdviseItem(string 公司別, string 出貨通知單號, string 客戶代號, string 來源單別, string 來源單號, string 來源項次, int 數量)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //取得公司別物件
            Company c = CompanyCollection.Get(公司別);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("出貨通知單號", 出貨通知單號);
            param.Add("客戶代號", 客戶代號);
            param.Add("來源單別", 來源單別);
            param.Add("來源單號", 來源單號);
            param.Add("來源項次", 來源項次);
            param.Add("數量", 數量);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "INSERT s_ShippingAdviseItem(Company, FormNo, BaseClass, BaseNumber, BaseItemNo, CustomerPO, PIClass, PINumber, PIItemNo, ProductNo, ProductName, CustomerPN, CustomerDESC, Qty, Creater, CreateTime, Updater, UpdateTime) " +
                        "SELECT @公司別, @出貨通知單號, @來源單別, @來源單號, @來源項次, RTRIM(TC012), TD017, TD018, TD019, RTRIM(TD004), RTRIM(TD005), RTRIM(TD014), RTRIM(TB201), @數量, @Updater, getdate(), @Updater, getdate() " +
                        "FROM " + c.DBName + "COPTC, " + c.DBName + "COPTD, " + c.DBName + "COPTB " +
                        "WHERE TC001=TD001 AND TC002=TD002 AND TD001=@來源單別 AND TD002=@來源單號 AND TD003=@來源項次 AND TD017=TB001 AND TD018=TB002 AND TD019=TB003";

            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>匯出出貨通知單</summary>
        public static DataTable ExportShippingAdvise(string 公司別, string 單號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT ROW_NUMBER() OVER(ORDER BY BaseClass, BaseNumber, ProductNo) AS [Item No], " +
                               "BaseClass + '-' + BaseNumber [SO Number], " +
                               "CustomerPO [Customer PO Number], " +
                               "PIClass + '-' + PINumber [PI Number], " +
                               "ProductNo [Arclite P/N], " +
                               "CustomerPN [Customer P/N], " +
                               "CustomerDESC [Description], " +
                               "Qty [Qty of today's shipment] " +
                        "FROM s_ShippingAdviseItem " +
                        "WHERE Company=@公司別 AND FormNo=@單號 " +
                        "ORDER BY BaseClass, BaseNumber, ProductNo";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>修改出貨原因備註</summary>
        public static void ModifyRemark(string 公司別, string 單別, string 單號, string 項次, string 備註)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("單別", 單別);
            param.Add("單號", 單號);
            param.Add("項次", 項次);
            param.Add("備註", 備註);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "UPDATE COPTD SET TD020=@備註 WHERE TD001=@單別 AND TD002=@單號 AND TD003=@項次";
            db.ExecuteSQL();
        }
        #endregion

        #region 箱號
        /// <summary>取得對應單號的箱號資料</summary>
        public static DataTable GetCartonItem(string 公司別, string 單號, string 箱號, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND FormNo=@單號"; }
            if (!string.IsNullOrEmpty(箱號)) { strWhere += " AND CartonNo=@箱號"; }

            //SQL
            string strSQL = "SELECT c.PalletNo, c.CartonNo, c.[G.W], c.[N.W], c.[W/M], ISNULL((SELECT SUM(p.Qty) FROM s_PackingList p WHERE Company=@公司別 AND p.FormNo=c.FormNo AND p.CartonNo=c.CartonNo AND Type='General'), 0) [Qty] " +
                            "FROM s_Carton c " +
                            "WHERE Company=@公司別 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "CartonNo ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>新增箱號資料</summary>
        public static int InsertCartonItem(string 公司別, string 單號, string 棧板號, string 箱號, string WM, string GW, string NW)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("棧板號", 棧板號);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            param.Add("WM", WM);
            param.Add("GW", GW);
            param.Add("NW", NW);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "IF NOT EXISTS(SELECT * FROM s_Carton WHERE Company=@公司別 AND FormNo=@單號 AND CartonNo=@箱號) BEGIN " +
                            "INSERT s_Carton(Company, FormNo, CartonNo, PalletNo, [W/M], [G.W], [N.W], Creater, CreateTime, Updater, UpdateTime) VALUES(@公司別, @單號, @箱號, @棧板號, @WM, @GW, @NW, @Updater, getdate(), @Updater, getdate()); " +
                        "END";

            return db.ExecuteSQL();
        }

        /// <summary>修改箱號資料</summary>
        public static void EditCartonItem(string 公司別, string 單號, string 棧板號, string 箱號, string WM, string GW, string NW)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("棧板號", 棧板號);
            param.Add("箱號", 箱號);
            param.Add("WM", WM);
            param.Add("GW", GW);
            param.Add("NW", NW);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "UPDATE s_Carton SET PalletNo=@棧板號, [G.W]=@GW, [N.W]=@NW, [W/M]=@WM, Updater=@Updater, UpdateTime=getdate() WHERE Company=@公司別 AND FormNo=@單號 AND CartonNo=@箱號";
            db.ExecuteSQL();
        }

        /// <summary>刪除對應單號的箱號資料</summary>
        public static void DelCartonItem(string 公司別, string 單號, string 箱號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            db.SqlParams = param;

            db.StrSQL = "DELETE FROM s_Carton WHERE Company=@公司別 AND FormNo=@單號 AND CartonNo=@箱號; " +
                        "DELETE FROM s_PackingList WHERE Company=@公司別 AND FormNo=@單號 AND CartonNo=@箱號;";
            db.ExecuteSQL();
        }

        /// <summary>複製箱號資料</summary>
        public static void CopyCatonItem(string 公司別, string 單號, string 箱號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "DECLARE @新箱號 int; " +
                        "SET @新箱號 = (SELECT MAX(CartonNo) + 1 FROM s_Carton WHERE Company=@公司別 AND FormNo=@單號); " +
                        "INSERT s_Carton(Company, FormNo,CartonNo,PalletNo,[G.W],[N.W],[W/M],Creater,CreateTime,Updater,UpdateTime) SELECT @公司別, FormNo, @新箱號, PalletNo, [G.W], [N.W], [W/M], @Updater, getdate(), @Updater, getdate() FROM s_Carton WHERE FormNo=@單號 AND CartonNo=@箱號; " +
                        "INSERT s_PackingList(Company, CartonNo,FormNo,Type,BaseClass,BaseNumber,BaseItemNo,ProductNo,Qty,Creater,CreateTime,Updater,UpdateTime) SELECT @公司別, @新箱號,FormNo,Type,BaseClass,BaseNumber,BaseItemNo,ProductNo,Qty,@Updater, getdate(), @Updater, getdate() FROM s_PackingList WHERE FormNo=@單號 AND CartonNo=@箱號;";
            db.ExecuteSQL();
        }
        #endregion

        #region PackingList
        /// <summary>取得Packing List包裝來源</summary>
        public static DataTable GetPackingSource(string 公司別, string 單號, string 箱號, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            db.SqlParams = param;

            //SQL
            string strSQL = "SELECT i.FormNo, i.BaseClass, i.BaseNumber, i.BaseItemNo, i.ProductNo, i.CustomerPN, i.Qty, ISNULL(p.Qty,0) sQty " +
                            "FROM s_ShippingAdviseItem i " +
                            "LEFT OUTER JOIN (Select Company, FormNo, BaseClass, BaseNumber, BaseItemNo, ProductNo, Sum(Qty) Qty " +
                                             "From s_PackingList " +
                                             "Where CartonNo <> @箱號 " +
                                             "Group By Company, FormNo, BaseClass, BaseNumber, BaseItemNo, ProductNo) p ON p.Company=i.Company AND " +
                                                                                                            "p.FormNo = i.FormNo AND " +
                                                                                                            "p.BaseClass = i.BaseClass AND " +
                                                                                                            "p.BaseNumber = i.BaseNumber AND " +
                                                                                                            "p.BaseItemNo = i.BaseItemNo AND " +
                                                                                                            "p.ProductNo = i.ProductNo " +
                            "WHERE i.Company=@公司別 AND i.FormNo=@單號 AND (i.Qty - ISNULL(p.Qty,0)) > 0";

            DataTable dtResult = db.ExecuteDataTable(strSQL, "BaseClass, BaseNumber, ProductNo", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得Packing List項目</summary> 
        public static DataTable GetPackingItems(string 公司別, string 單號, string 箱號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND FormNo=@單號"; }
            if (!string.IsNullOrEmpty(箱號)) { strWhere += " AND CartonNo=@箱號"; }

            //SQL
            db.StrSQL = "SELECT Id, CartonNo, FormNo, Type, BaseClass, BaseNumber, BaseItemNo, ProductNo, Qty FROM s_PackingList p WHERE Company=@公司別 " + strWhere;

            return db.ExecuteDataTable();
        }

        /// <summary>新增Packing的明細資料</summary>
        public static bool InsertPackingItem(string 公司別, string 單號, string 類型, string 箱號, string 來源單別, string 來源單號, string 來源項次, string 品號, string 數量)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("類型", 類型);
            param.Add("箱號", 箱號);
            param.Add("來源單別", 來源單別);
            param.Add("來源單號", 來源單號);
            param.Add("來源項次", 來源項次);
            param.Add("品號", 品號);
            param.Add("數量", 數量);
            param.Add("Updater", Authority.UserInfo.SessionState.ID);
            db.SqlParams = param;

            db.StrSQL = "INSERT s_PackingList(Company, CartonNo, FormNo, Type, BaseClass, BaseNumber, BaseItemNo, ProductNo, Qty, Creater, CreateTime, Updater, UpdateTime) " +
                        "VALUES(@公司別, @箱號, @單號, @類型, @來源單別, @來源單號, @來源項次, @品號, @數量, @Updater, getdate(), @Updater, getdate())";
            int iResult = db.ExecuteSQL();
            return (iResult > 0);
        }

        /// <summary>刪除Packing的明細資料</summary>
        public static bool DeletePackingItem(string 主鍵, string 公司別, string 單號, string 箱號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("主鍵", 主鍵);
            param.Add("單號", 單號);
            param.Add("箱號", 箱號);
            db.SqlParams = param;

            //條件
            string strWhere = "";
            if (!string.IsNullOrEmpty(主鍵)) { strWhere += " AND Id=@主鍵"; }
            if (!string.IsNullOrEmpty(公司別)) { strWhere += " AND Company=@公司別"; }
            if (!string.IsNullOrEmpty(單號)) { strWhere += " AND FormNo=@單號"; }
            if (!string.IsNullOrEmpty(箱號)) { strWhere += " AND CartonNo=@箱號"; }

            db.StrSQL = "DELETE FROM s_PackingList WHERE 1=1" + strWhere;
            int iResult = db.ExecuteSQL();

            return (iResult > 0);
        }

        /// <summary>取得PackingList的報表資料</summary>
        public static DataSet GetPackingListFormData(string 公司別, string 單號, string 替代公司別, string 替代客戶代號)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //取得公司別物件
            Company c;
            if (string.IsNullOrEmpty(替代公司別)) { c = CompanyCollection.Get(公司別);  }
            else { c = CompanyCollection.Get(替代公司別); }

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("公司別", 公司別);
            param.Add("單號", 單號);
            param.Add("替代客戶代號", 替代客戶代號);
            db.SqlParams = param;

            db.StrSQL = "IF (@替代客戶代號 = '') BEGIN " +
                            "DECLARE @CustomCode varchar(10), @ERPClass varchar(10), @ERPNumber varchar(10); " +
                            "SELECT TOP 1 @ERPClass=BaseClass, @ERPNumber=BaseNumber FROM s_ShippingAdviseItem WHERE Company=@公司別 AND FormNo=@單號 ORDER BY BaseClass; " + //單別排序，2210優先

                            "SELECT TC066 [TEL], TC067 [FAX], TC018 [Attn], TC053 [CompanyName], TC010 [ShipTo], ML014 [ShippedBy], ML015 [From], 0 [TotalCarton], 0 [TotalQty], '' [TotalGW], '' [TotalNW] FROM " + c.DBName + "COPTC " +
                            "INNER JOIN " + c.DBName + "CMSML ON 1=1 " +
                            "WHERE TC001=@ERPClass AND TC002=@ERPNumber; " +
                        "END ELSE BEGIN " +
                            "SELECT MA006 [TEL], MA008 [FAX], MA005 [Attn], MA003 [CompanyName], MA027 [ShipTo], ML014 [ShippedBy], ML015 [From], 0 [TotalCarton], 0 [TotalQty], '' [TotalGW], '' [TotalNW] " +
                            "FROM " + c.DBName + "COPMA " +
                            "INNER JOIN " + c.DBName + "CMSML ON 1=1 " +
                            "WHERE MA001=@替代客戶代號; " +
                        "END ";
            DataTable dt單頭 = db.ExecuteDataTable();
            dt單頭.TableName = "單頭";

            db.StrSQL = "SELECT c.FormNo, c.PalletNo, c.CartonNo, c.[G.W], c.[N.W], c.[W/M], p.Qty, i.ProductNo, CASE p.Type WHEN 'General' THEN i.ProductName ELSE p.ProductNo END [ProductName], i.CustomerPN, i.CustomerDESC, " +
                        "CASE WHEN @替代客戶代號 = '' THEN TC012 ELSE TC015 END [CustomerPO] " +
                        "FROM s_Carton c " +
                        "LEFT OUTER JOIN s_PackingList p ON p.Company=c.Company AND p.FormNo=c.FormNo AND p.CartonNo=c.CartonNo " +
                        "LEFT OUTER JOIN s_ShippingAdviseItem i ON i.Company=p.Company AND i.FormNo=p.FormNo AND i.BaseClass=p.BaseClass AND i.BaseNumber=p.BaseNumber AND i.BaseItemNo=p.BaseItemNo AND i.ProductNo=p.ProductNo " +
                        "LEFT OUTER JOIN " + CompanyCollection.Get(公司別).DBName + "COPTC ON i.BaseClass=TC001 COLLATE Chinese_Taiwan_Stroke_CI_AS AND " +
                                                                                             "i.BaseNumber=TC002 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                        "WHERE c.Company=@公司別 AND c.FormNo=@單號";
            DataTable dt單身 = db.ExecuteDataTable();
            dt單身.TableName = "單身";

            DataSet ds = new DataSet();
            ds.Tables.Add(dt單頭);
            ds.Tables.Add(dt單身);

            return ds;
        }
        #endregion

        /// <summary>取得指定的ERP來源單據資料</summary>
        public static DataTable GetSellingFormData(string 公司別, string 單別單號)
        {
            //物件初始化
            Company c = CompanyCollection.Get(公司別);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //SQL
            db.StrSQL = "SELECT 來源單別, 來源單號, 來源項次, 品號, SUM(數量) [數量], '' [數量1] FROM ( " +
			                "SELECT TH001 [單別], TH002 [單號], TH014 [來源單別], TH015 [來源單號], TH016 [來源項次], TH004 [品號], Convert(int,TH008 + TH024) [數量], '' [數量1] FROM COPTH " +
			                "UNION ALL " +
			                "SELECT TG001 [單別], TG002 [單號], TG014 [來源單別], TG015 [來源單號], TG016 [來源項次], TG004 [品號], Convert(int,TG009) [數量], '' [數量1] FROM INVTG " +
                        ") result " +
                        "WHERE (單別 + '-' + 單號) IN (" + 單別單號 + ") " +
                        "GROUP BY 單別, 單號, 來源單別, 來源單號, [來源項次], [品號]";

            return db.ExecuteDataTable();
        }
    }
}