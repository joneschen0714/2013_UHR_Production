﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR.Util;

namespace UHR
{
    public class DAL_UHRWeb
    {
        public DAL_UHRWeb()
        {

        }

        #region Brand

        /// <summary>取得所有Brand內容(分頁)</summary>
        public static DataTable GetAllBrand(string OEMLampModule, string OEMMarking, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OEMLampModule", "%" + OEMLampModule + "%");
            param.Add("OEMMarking", "%" + OEMMarking + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(OEMLampModule)) { strWhere += " AND Replace(Replace(m.OEM_LM,' ',''),'-','') LIKE @OEMLampModule "; }
            if (!string.IsNullOrEmpty(OEMMarking)) { strWhere += " AND m.Marking LIKE @OEMMarking "; }

            string strSQL = "SELECT b.ID, b.Brand FROM Brand b " +
                            "LEFT OUTER JOIN OEMLampModule m ON b.ID=m.BrandID " +
                            "WHERE 1=1 " + strWhere +
                            "GROUP BY b.ID, b.Brand";

            DataTable dtResult = db.ExecuteDataTable(strSQL, "Brand ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得指定的Brand內容</summary>
        public static DataRow GetBrandData(object _id)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _id);

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Brand WHERE ID=@ID";
            DataRow row = db.ExecuteDataTable().Rows[0];
            return row;
        }

        /// <summary>新增&修改Brand內容</summary>
        public static void ModifyBrand(object ID, object Brand, object ImgSrc)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", Util.Tool.GetDBNullString(ID));
            param.Add("Brand", Brand);
            param.Add("ImgSrc", ImgSrc);

            db.SqlParams = param;
            db.StrSQL = "IF @ID IS NULL BEGIN " +
                            "INSERT Brand(Brand, ImgSrc) VALUES(@Brand, @ImgSrc); " +
                        "END ELSE BEGIN " +
                            "UPDATE Brand SET Brand=@Brand, ImgSrc=@ImgSrc WHERE ID=@ID; " +
                        "END";
            db.ExecuteSQL();
        }
        #endregion

        #region UHR Lamp Module

        /// <summary>取得所有LampModule資料(分頁)</summary>
        public static DataTable GetLampModuleList(string ID, string LampModule, string LM_Status, string BareLamp, string BL_Status, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("LampModule", "%" + LampModule + "%");
            param.Add("LM_Status", LM_Status);
            param.Add("BareLamp", "%" + BareLamp + "%");
            param.Add("BL_Status", BL_Status);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND m.ID = @ID"; }
            if (!string.IsNullOrEmpty(LampModule)) { strWhere += " AND m.LM LIKE @LampModule"; }
            if (!string.IsNullOrEmpty(LM_Status)) { strWhere += " AND m.LM_Status = @LM_Status"; }
            if (!string.IsNullOrEmpty(BareLamp)) { strWhere += " AND m.BL LIKE @BareLamp"; }
            if (!string.IsNullOrEmpty(BL_Status)) { strWhere += " AND m.BL_Status = @BL_Status"; }

            string strSQL = "SELECT m.ID, c.Name [Class], m.LM [UHR_LM], t.Name [Type], hs.Name [LM_Status], m.LM_Price, m.Description, m.BL [UHR_BL], bs.Name [BL_Status], m.BL_Price " +
                            "FROM UHRLampModule m " +
                            "INNER JOIN Config c ON c.Type='ProductClass' AND c.Value=m.Class " +
                            "INNER JOIN Config t ON t.Type='LampType' AND t.Value=m.LM_Type " +
                            "INNER JOIN Config hs ON hs.Type='ProductStatus' AND hs.Value=m.LM_Status " +
                            "LEFT OUTER JOIN Config bs ON bs.Type='ProductStatus' AND bs.Value=m.BL_Status " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "UHR_LM ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得對應的UHR_LMID</summary>
        public static string GetUhrLMID(string LampModule)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("LM", LampModule);

            db.SqlParams = param;
            db.StrSQL = "SELECT ID FROM UHRLampModule WHERE LM=@LM";
            return db.ExecuteScalar();
        }

        /// <summary>取得圖片附件資料</summary>
        public static DataTable GetAttachment(string UHR_LMID, string LampModule, string Status)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LMID", UHR_LMID);
            param.Add("LampModule", "%" + LampModule + "%");
            param.Add("Status", Status);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(UHR_LMID)) { strWhere += " AND m.ID = @UHR_LMID"; }
            if (!string.IsNullOrEmpty(LampModule)) { strWhere += " AND m.LM LIKE @LampModule"; }
            if (!string.IsNullOrEmpty(Status)) { strWhere += " AND m.LM_Status = @Status"; }

            db.StrSQL = "SELECT m.LM [UHR_LM], a.FileName, a.Enabled FROM Attachment a " +
                        "INNER JOIN UHRLampModule m ON m.ID = a.UHR_LMID " +
                        "WHERE 1=1 " + strWhere;

            return db.ExecuteDataTable();
        }

        /// <summary>刪除指定的UHRLampModule</summary>
        public static void DeleteUHRLampModule(string ID, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("outError", ParameterDirection.Output);
            param.Add("outMessage", ParameterDirection.Output);
            db.SqlParams = param;

            db.StrSQL = "IF NOT EXISTS(SELECT * FROM Product WHERE UHR_LMID=@ID) BEGIN " +
                            "DELETE FROM UHRLampModule WHERE ID=@ID; " +
                            "DELETE FROM Attachment WHERE UHR_LMID=@ID; " +
                        "END ELSE BEGIN " +
                            "SELECT @outError='1', @outMessage='作業中斷，此項已使用於上架產品中!'; " +
                        "END";

            db.ExecuteSQL();

            Result = param["outError"].Value.ToString() == "";
            Message = param["outMessage"].Value.ToString();
        }

        #endregion

        #region Projector

        /// <summary>取得所有Projector資料(分頁)</summary>
        public static DataTable GetProjectorList(string ID, string BrandID, string Projector, string UHR_LM, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("BrandID", BrandID);
            param.Add("Projector", "%" + Projector + "%");
            param.Add("UHR_LM", "%" + UHR_LM + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND p.ID = @ID"; }
            if (!string.IsNullOrEmpty(BrandID)) { strWhere += " AND BrandID = @BrandID"; }
            if (!string.IsNullOrEmpty(Projector)) { strWhere += " AND ProjectorModel LIKE @Projector"; }
            if (!string.IsNullOrEmpty(UHR_LM)) { strWhere += " AND LM LIKE @UHR_LM"; }

            string strSQL = "SELECT p.ID, b.Brand, '!' + p.ProjectorModel [ProjectorModel], p.OEM_LT, p.ProduceDate [LifePeriod], m.LM [UHR_LM], p.Enabled, " +
                                "[OEMLampModule]= '!' + STUFF((SELECT ',' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) FOR XML PATH('')), 1, 1, '') " +
                            "FROM Product p " +
                            "INNER JOIN Brand b ON b.ID = p.BrandID " +
                            "INNER JOIN UHRLampModule m ON m.ID = p.UHR_LMID " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "Brand, ProjectorModel", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        #endregion

        #region Product

        /// <summary>新增或修改OEM Product資料</summary>
        public static void ModifyOEMProductList(DataTable dt, out bool Result, out string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region Projector
                //循序讀取Projector資料
                foreach (DataRow row in dt.Rows)
                {
                    //變數
                    string ID = row["ID"].ToString().Trim();
                    string Brand = row["Brand"].ToString().Trim();
                    string ProjectorModel = row["ProjectorModel"].ToString().Trim('!');
                    string OEM_LT = row["OEM_LT"].ToString().Trim();
                    string UHR_LM = row["UHR_LM"].ToString().Trim();
                    string ProduceDate = row["LifePeriod"].ToString().Trim();
                    string Enabled = row["Enabled"].ToString().Trim();
                    string OEMLampModuleArray = Tool.SetSplitSingleMark(row["OEMLampModule"].ToString().Trim('!'), "'", ',');

                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("ID", Tool.GetDBNullString(ID)));
                    cmd.Parameters.Add(new SqlParameter("Brand", Brand));
                    cmd.Parameters.Add(new SqlParameter("ProjectorModel", ProjectorModel));
                    cmd.Parameters.Add(new SqlParameter("OEM_LT", OEM_LT));
                    cmd.Parameters.Add(new SqlParameter("ProduceDate", ProduceDate));
                    cmd.Parameters.Add(new SqlParameter("UHR_LM", UHR_LM));
                    cmd.Parameters.Add(new SqlParameter("Enabled", Enabled));

                    cmd.CommandText = "DECLARE @BrandID int, @UHR_LMID int, @OEMLMCount int; " +
                                      "SET @BrandID = (SELECT ID FROM Brand WHERE Brand=@Brand); " +
                                      "SET @UHR_LMID = (SELECT ID FROM UHRLampModule WHERE LM=@UHR_LM); " +

                                      "IF (@ID IS NULL) BEGIN " +
                                          "INSERT Product(BrandID, ProjectorModel, OEM_LT, ProduceDate, UHR_LMID, Enabled) VALUES(@BrandID, @ProjectorModel, @OEM_LT, @ProduceDate, @UHR_LMID, @Enabled); " +
                                          "SET @ID = (SELECT @@Identity); " +
                                      "END ELSE BEGIN " +
                                          "UPDATE Product SET OEM_LT=@OEM_LT, ProduceDate=@ProduceDate, UHR_LMID=@UHR_LMID, Enabled=@Enabled WHERE ID=@ID; " +
                                      "END " +

                                      "DELETE FROM LampModuleRelProduct WHERE P_ID=@ID; " +
                                      "INSERT LampModuleRelProduct(P_ID, OEM_LMID) SELECT @ID, ID FROM OEMLampModule WHERE BrandID=@BrandID AND OEM_LM IN (" + OEMLampModuleArray + "); ";

                    cmd.ExecuteNonQuery();
                }
                #endregion

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>新增或修改UHR Product資料</summary>
        public static void ModifyUHRProductList(DataTable dt, out bool Result, out string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region UHR LampModule
                //循序讀取UHR LampModule資料
                foreach (DataRow row in dt.Rows)
                {
                    //變數
                    string ID = row["ID"].ToString().Trim();
                    string Class = row["Class"].ToString().Trim();
                    string UHR_LM = row["UHR_LM"].ToString().Trim();
                    string Type = row["Type"].ToString().Trim();
                    string LM_Status = row["LM_Status"].ToString().Trim();
                    string LM_Price = row["LM_Price"].ToString().Trim();
                    string Description = row["Description"].ToString().Trim();
                    string UHR_BL = row["UHR_BL"].ToString().Trim();
                    string BL_Status = row["BL_Status"].ToString().Trim();
                    string BL_Price = row["BL_Price"].ToString().Trim();

                    //驗証BareLamp是否都有必填欄位
                    if (string.IsNullOrEmpty(UHR_BL) != string.IsNullOrEmpty(BL_Status)) { throw new Exception("BareLamp缺少必要欄位!"); }

                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("ID", Tool.GetDBNullString(ID)));
                    cmd.Parameters.Add(new SqlParameter("Class", Class));
                    cmd.Parameters.Add(new SqlParameter("UHR_LM", UHR_LM));
                    cmd.Parameters.Add(new SqlParameter("Type", Type));
                    cmd.Parameters.Add(new SqlParameter("LM_Status", LM_Status));
                    cmd.Parameters.Add(new SqlParameter("LM_Price", Tool.GetDBNullString(LM_Price)));
                    cmd.Parameters.Add(new SqlParameter("Description", Description));
                    cmd.Parameters.Add(new SqlParameter("UHR_BL", Tool.GetDBNullString(UHR_BL)));
                    cmd.Parameters.Add(new SqlParameter("BL_Status", Tool.GetDBNullString(BL_Status)));
                    cmd.Parameters.Add(new SqlParameter("BL_Price", Tool.GetDBNullString(BL_Price)));

                    cmd.CommandText = "SET @Class = (SELECT Value FROM Config WHERE Type='ProductClass' AND Name=@Class); " +
                                      "SET @Type = (SELECT Value FROM Config WHERE Type='LampType' AND Name=@Type); " +
                                      "SET @LM_Status = (SELECT Value FROM Config WHERE Type='ProductStatus' AND Name=@LM_Status); " +
                                      "SET @BL_Status = (SELECT Value FROM Config WHERE Type='ProductStatus' AND Name=@BL_Status); " +
                                      "IF (@ID IS NULL) BEGIN " +
                                          "INSERT UHRLampModule(Class, LM, LM_Type, LM_Status, LM_Price, Description, BL, BL_Status, BL_Price) VALUES(@Class, @UHR_LM, @Type, @LM_Status, @LM_Price, @Description, @UHR_BL, @BL_Status, @BL_Price); " +
                                      "END ELSE BEGIN " +
                                          "UPDATE UHRLampModule SET Class=@Class, LM_Type=@Type, LM_Status=@LM_Status, LM_Price=@LM_Price, Description=@Description, BL=@UHR_BL, BL_Status=@BL_Status, BL_Price=@BL_Price WHERE ID=@ID; " +
                                      "END";

                    cmd.ExecuteNonQuery();
                }
                #endregion

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>新增或修改UHR Attachment資料</summary>
        public static void ModifyUHRAttachment(DataTable dt, out bool Result, out string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //循序讀取UHR Attachment資料
                foreach (DataRow row in dt.Rows)
                {
                    //變數
                    string UHR_LM = row["UHR_LM"].ToString().Trim();
                    string FileName = row["FileName"].ToString().Trim();
                    string Enabled = row["Enabled"].ToString().Trim();

                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("UHR_LM", UHR_LM));
                    cmd.Parameters.Add(new SqlParameter("FileName", Tool.GetDBNullString(FileName)));
                    cmd.Parameters.Add(new SqlParameter("Enabled", Tool.GetDBNullString(Enabled)));

                    cmd.CommandText = "DECLARE @UHR_LMID int; " +
                                      "SET @UHR_LMID = (SELECT ID FROM UHRLampModule WHERE LM=@UHR_LM); " +
                                      "DELETE FROM Attachment WHERE UHR_LMID=@UHR_LMID; " +
                                      "IF (@FileName IS NOT NULL) BEGIN " +
                                         "INSERT Attachment(UHR_LMID, FileName, Enabled, Sort) VALUES(@UHR_LMID, @FileName, @Enabled, 1); " +
                                      "END";

                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>取得相關OEM Lamp Module</summary>
        public static DataTable GetRelatedOEMLampModule(string UHR_LMID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LMID", UHR_LMID);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT o.ID, b.ID BrandID, b.Brand, o.OEM_LM, m.LM_Status, m.BL_Status " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "INNER JOIN LampModuleRelProduct r ON r.P_ID=p.ID " +
                        "INNER JOIN OEMLampModule o ON o.ID=r.OEM_LMID " +
                        "WHERE m.ID=@UHR_LMID AND p.Enabled=1 " +
                        "GROUP BY o.ID, b.ID, b.Brand, o.OEM_LM, m.LM_Status, m.BL_Status " +
                        "ORDER BY b.Brand, o.OEM_LM";
            DataTable dtResult = db.ExecuteDataTable();

            return dtResult;
        }

        #endregion

        #region OEM Lamp Module

        /// <summary>取得所有OEM Lamp Module資料(分頁)</summary>
        public static DataTable GetOEMLampModuleList(string ID, string BrandID, string OEMLampModule, string Marking, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("BrandID", BrandID);
            param.Add("OEMLampModule", "%" + OEMLampModule + "%");
            param.Add("Marking", "%" + Marking + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND m.ID=@ID "; }
            if (!string.IsNullOrEmpty(BrandID)) { strWhere += " AND b.ID=@BrandID "; }
            if (!string.IsNullOrEmpty(OEMLampModule)) { strWhere += " AND Replace(Replace(m.OEM_LM,' ',''),'-','') LIKE @OEMLampModule "; }
            if (!string.IsNullOrEmpty(Marking)) { strWhere += " AND m.Marking LIKE @Marking"; }

            string strSQL = "SELECT b.Brand, m.ID, m.OEM_LM, m.Marking FROM OEMLampModule m " +
                            "INNER JOIN Brand b ON b.ID = m.BrandID " +
                            "WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "OEM_LM ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>新增或修改OEM Lamp Module</summary>
        public static bool ModifyOEMLampModule(string ID, string Brand, string OEMLampModule, string Marking, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("Brand", Brand);
            param.Add("OEMLampModule", Tool.GetDBNullString(OEMLampModule));
            param.Add("Marking", Tool.GetDBNullString(Marking));
            db.SqlParams = param;

            db.StrSQL = "DECLARE @Count int, @BrandID int; " +
                        "SELECT @BrandID=ID FROM Brand WHERE Brand=@Brand; " +
                        "IF (@ID='') BEGIN " +
                            "SET @Count = (SELECT COUNT(ID) FROM OEMLampModule WHERE BrandID=@BrandID AND OEM_LM=@OEMLampModule); " +
                            "IF (@Count = 0) BEGIN " +
                                "INSERT OEMLampModule(BrandID, OEM_LM, Marking) VALUES(@BrandID, @OEMLampModule, @Marking); " +
                            "END " +
                        "END ELSE BEGIN " +
                            "SET @Count = (SELECT COUNT(ID) FROM OEMLampModule WHERE BrandID=@BrandID AND OEM_LM=@OEMLampModule AND ID<>@ID); " +
                            "IF (@Count = 0) BEGIN " +
                                "UPDATE OEMLampModule SET OEM_LM=@OEMLampModule, Marking=@Marking WHERE ID=@ID; " +
                            "END " +
                        "END";

            int iResult = db.ExecuteSQL();
            return (iResult > 0);
        }

        #endregion

        #region News

        /// <summary>取得所有News資料(分頁)</summary>
        public static DataTable GetNewsList(string strLang, string strType, string strTitle, string strEffectiveDate, string strExpiryDate, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", strLang);
            param.Add("Type", strType);
            param.Add("Title", "%" + strTitle + "%");
            param.Add("EffectiveDate", strEffectiveDate);
            param.Add("ExpiryDate", strExpiryDate);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(strLang)) { strWhere += " AND Lang=@Lang"; }
            if (!string.IsNullOrEmpty(strType)) { strWhere += " AND Type=@Type"; }
            if (!string.IsNullOrEmpty(strTitle)) { strWhere += " AND Title=@Title"; }
            if (!string.IsNullOrEmpty(strEffectiveDate)) { strWhere += " AND EffectiveDate >= @EffectiveDate"; }
            if (!string.IsNullOrEmpty(strExpiryDate)) { strWhere += " AND ExpiryDate <= @ExpiryDate"; }

            //SQL
            string strSQL = "SELECT ID, Lang, Type, Title, EffectiveDate, ExpiryDate FROM News WHERE 1=1 " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "ID ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得News內容</summary>
        public static DataRow GetNewsDetail(string ID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT * FROM News WHERE ID=@ID";

            DataRow row = null;
            DataTable dt = db.ExecuteDataTable();
            if (dt.Rows.Count > 0)
                row = dt.Rows[0];

            return row;
        }

        /// <summary>新增或修改News內容</summary>
        public static void ModifyNews(string ID, string Lang, string Type, string Title, string Description, string Content, string SlideContent, string TimeSpan, string EffectiveDate, string ExpiryDate)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", Tool.GetDBNullString(ID));
            param.Add("Lang", Lang);
            param.Add("Type", Type);
            param.Add("Title", Title);
            param.Add("Description", Tool.GetDBNullString(Description));
            param.Add("Content", Tool.GetDBNullString(Content));
            param.Add("SlideContent", Tool.GetDBNullString(SlideContent));
            param.Add("SlideTimeSpan", Tool.GetDBNullString(TimeSpan));
            param.Add("EffectiveDate", EffectiveDate);
            param.Add("ExpiryDate", ExpiryDate);
            db.SqlParams = param;

            db.SqlParams = param;
            db.StrSQL = "IF @ID IS NULL BEGIN " +
                            "INSERT News(Lang, Type, Title, Description, Content, SlideContent, SlideTimeSpan, EffectiveDate, ExpiryDate) VALUES(@Lang, @Type, @Title, @Description, @Content, @SlideContent, @SlideTimeSpan, @EffectiveDate, @ExpiryDate); " +
                        "END ELSE BEGIN " +
                            "UPDATE News SET Lang=@Lang, Type=@Type, Title=@Title, Description=@Description, Content=@Content, SlideContent=@SlideContent, SlideTimeSpan=@SlideTimeSpan, EffectiveDate=@EffectiveDate, ExpiryDate=@ExpiryDate WHERE ID=@ID; " +
                        "END";

            db.ExecuteSQL();
        }

        #endregion

        #region StaticPage

        /// <summary>取得所有靜態頁面資料</summary>
        public static DataTable GetStaticPageList(string Lang, string Type)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", Lang);
            param.Add("Type", Type);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(Lang)) { strWhere += " AND Lang=@Lang"; }
            if (!string.IsNullOrEmpty(Type)) { strWhere += " AND Type=@Type"; }

            //SQL
            db.StrSQL = "SELECT * FROM StaticPage WHERE 1=1 " + strWhere;

            return db.ExecuteDataTable();
        }

        /// <summary>修改靜態頁面內容</summary>
        public static void ModifyStaticPage(string Lang, string Type, string Content)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", Lang);
            param.Add("Type", Type);
            param.Add("Content", Content);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "UPDATE StaticPage SET Content=@Content WHERE Lang=@Lang AND Type=@Type";

            db.ExecuteSQL();
        }

        #endregion

        #region Catalog
        /// <summary>取得所有Catalog清單</summary>
        public static DataTable GetCatalogList(int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            string strSQL = "SELECT * FROM Catalog";
            DataTable dtResult = db.ExecuteDataTable(strSQL, "ID ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得指定的Catalog資料</summary>
        public static DataRow GetCatalogData(string _id)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _id);

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Catalog WHERE ID=@ID";
            DataRow row = db.ExecuteDataTable().Rows[0];
            return row;
        }

        /// <summary>新增 & 修改Catalog資料</summary>
        public static bool ModifyCatalog(string _id, string _name, string _effectivedate, string _expirydate, string _showinlist, string _description, out string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", Tool.GetDBNullString(_id));
            param.Add("Name", Tool.GetDBNullString(_name));
            param.Add("EffectiveDate", Tool.GetDBNullString(_effectivedate));
            param.Add("ExpiryDate", Tool.GetDBNullString(_expirydate));
            param.Add("ShowInList", Tool.GetDBNullString(_showinlist));
            param.Add("Description", Tool.GetDBNullString(_description));
            db.SqlParams = param;

            bool bResult = false;
            try
            {
                db.StrSQL = "IF (@ID IS NULL) BEGIN " +
                                "INSERT Catalog(Name, EffectiveDate, ExpiryDate, ShowInList, Description) VALUES(@Name, @EffectiveDate, @ExpiryDate, @ShowInList, @Description); " +
                            "END ELSE BEGIN " +
                                "UPDATE Catalog SET Name=@Name, EffectiveDate=@EffectiveDate, ExpiryDate=@ExpiryDate, ShowInList=@ShowInList, Description=@Description WHERE ID=@ID; " +
                            "END";

                db.ExecuteSQL();
                bResult = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                db.CloseDatabaseState("N"); //關閉連線
                bResult = false;
                Message = e.Message;
            }

            return bResult;
        }

        /// <summary>取得指定Catalog的Item資料</summary>
        public static DataTable GetCatalogItem(string _catalogid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("CatalogID", _catalogid);

            db.SqlParams = param;
            db.StrSQL = "SELECT i.UHR_LMID, m.LM, i.Enabled FROM CatalogItem i " +
                        "INNER JOIN UHRLampModule m ON m.ID=i.UHR_LMID " +
                        "WHERE CatalogID=@CatalogID";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>批次修改Catalog下的Item</summary>
        public static void ModifyCatalogItem(string _catalogid, DataTable _dt)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("CatalogID", _catalogid);

            //刪除此Catalog下的所有Item
            db.SqlParams = param;
            db.StrSQL = "DELETE FROM CatalogItem WHERE CatalogID=@CatalogID";
            db.ExecuteSQL();

            //循序新增Item
            foreach (DataRow row in _dt.Rows)
            {
                param.Clear();
                param.Add("CatalogID", _catalogid);
                param.Add("UHR_LMID", row["UHR_LMID"]);
                param.Add("Enabled", row["Enabled"]);

                db.SqlParams = param;
                db.StrSQL = "INSERT CatalogItem(CatalogID, UHR_LMID, Enabled, UpdateTime) VALUES(@CatalogID, @UHR_LMID, @Enabled, getdate())";
                db.ExecuteSQL();
            }
        }

        /// <summary>更新New Product的Item</summary>
        public static void UpdateNewProduct(string UHR_LM)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LM", UHR_LM);
            db.SqlParams = param;

            db.StrSQL = "DECLARE @CatalogID int, @CatalogItemID int, @UHRLampModule int; " +
                        "SET @CatalogID = (SELECT ID FROM Catalog WHERE Name='New Product'); " +
                        "SET @UHRLampModule = (SELECT ID FROM UHRLampModule WHERE LM=@UHR_LM); " +
                        "IF NOT EXISTS(SELECT * FROM CatalogItem WHERE CatalogID=@CatalogID AND UHR_LMID=@UHRLampModule) BEGIN " +
                            "INSERT CatalogItem(CatalogID, UHR_LMID, Enabled, UpdateTime) VALUES(@CatalogID, @UHRLampModule, 1, getdate()); " +
                            "DELETE FROM CatalogItem WHERE ID IN(SELECT TOP 1 ID FROM CatalogItem WHERE CatalogID=@CatalogID ORDER BY UpdateTime); " +
                        "END";
            db.ExecuteSQL();
        }
        #endregion

        #region FAQ

        /// <summary>取得所有FAQ資料(分頁)</summary>
        public static DataTable GetFAQList(string Type, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(Type)) { strWhere += " AND q.Type=@Type "; }

            //SQL
            string strSQL = "SELECT q.ID, c.Name [Country], m.Company, m.Name, q.Type, q.Subject, COUNT(q1.ID) [ReplyCount] FROM FAQ q " +
                            "INNER JOIN Member m ON m.ID = q.Member_ID " +
                            "INNER JOIN Country c ON c.Code = m.Country " +
                            "LEFT OUTER JOIN FAQ q1 ON q1.c_ID = q.ID " +
                            "WHERE q.c_ID IS NULL " + strWhere +
                            "GROUP BY q.ID, c.Name, m.Company, m.Name, q.Type, q.Subject";

            DataTable dtResult = db.ExecuteDataTable(strSQL, "ID ASC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得指定的FAQ內容</summary>
        public static DataTable GetFAQDetail(string ID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT * FROM FAQ WHERE ID=@ID OR c_ID=@ID";

            return db.ExecuteDataTable();
        }

        /// <summary>回覆FAQ問題</summary>
        public static void ReplyFAQ(string c_ID, string MemberID, string Subject, string ReplyContent)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("c_ID", c_ID);
            param.Add("MemberID", MemberID);
            param.Add("Subject", Subject);
            param.Add("ReplyContent", ReplyContent);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "INSERT FAQ(c_ID, Member_ID, Subject, Contents, UpdateTime) VALUES(@c_ID, @MemberID, @Subject, @ReplyContent, getdate())";

            db.ExecuteSQL();
        }

        #endregion

        #region Member

        /// <summary>取得Member資料</summary>
        public static DataTable GetMemberInfo(string ID, string Name, string Email, string Company, string Country, string ERPCompany, string ERPCustomCode, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("Name", "%" + Name + "%");
            param.Add("Email", "%" + Email + "%");
            param.Add("Company", string.Format("%{0}%", Company));
            param.Add("Country", Country);
            param.Add("ERPCompany", ERPCompany);
            param.Add("ERPCustomCode", ERPCustomCode);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND m.ID=@ID "; }
            if (!string.IsNullOrEmpty(Name)) { strWhere += " AND m.Name LIKE @Name "; }
            if (!string.IsNullOrEmpty(Email)) { strWhere += " AND m.Email LIKE @Email "; }
            if (!string.IsNullOrEmpty(Company)) { strWhere += " AND m.Company LIKE @Company "; }
            if (!string.IsNullOrEmpty(Country)) { strWhere += " AND c.Code=@Country "; }
            if (!string.IsNullOrEmpty(ERPCompany)) { strWhere += " AND m.ERP_Company=@ERPCompany "; }
            if (!string.IsNullOrEmpty(ERPCustomCode)) { strWhere += " AND m.ERP_CustomCode=@ERPCustomCode "; }

            //SQL
            string strSQL = "SELECT m.ID, m.Name, m.Sex, m.Email, m.Tel, c.Name [CountryName], m.Address, m.Company, m.Currency, m.Level, m.ERP_Company, m.ERP_CustomCode, m.ContactSalesMail, m.Enabled, m.CreateDate FROM Member m " +
                            "INNER JOIN Country c ON c.Code=m.Country " +
                            "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "ID ASC", _pageindex, _pagesize, out _recordcount);

            return dtResult;
        }

        /// <summary>修改Member資料</summary>
        public static void ModifyMemberInfo(string ID, string Level, string ContactSalesMail, string Currency, string ERP_Company, string ERP_CustomCode, string Enabled)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("Level", Tool.GetDBNullString(Level));
            param.Add("ContactSalesMail", Tool.GetDBNullString(ContactSalesMail));
            param.Add("Currency", Tool.GetDBNullString(Currency));
            param.Add("ERP_Company", ERP_Company);
            param.Add("ERP_CustomCode", ERP_CustomCode);
            param.Add("Enabled", Enabled);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "UPDATE Member SET Level=@Level, ContactSalesMail=@ContactSalesMail, Currency=@Currency, ERP_Company=@ERP_Company, ERP_CustomCode=@ERP_CustomCode, Enabled=@Enabled WHERE ID=@ID";

            db.ExecuteSQL();
        }

        /// <summary>取得Country資料</summary>
        public static DataTable GetCountry(string Code)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", Code);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(Code)) { strWhere += " AND Code=@Code"; }

            //SQL
            db.StrSQL = "SELECT * FROM Country WHERE 1=1 " + strWhere + " ORDER BY Name";

            return db.ExecuteDataTable();
        }

        #endregion

        #region MailLog

        /// <summary>取得所有廣告信發送記錄</summary>
        public static DataTable GetMailLogList(string Subject, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Subject", "%" + Subject + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(Subject)) { strWhere += " AND Subject LIKE @Subject "; }

            string strSQL = "SELECT m.ID, m.Subject, m.CreateDate, Count(mi.m_ID) [Count] " +
                            "FROM MailLog m " +
                            "LEFT OUTER JOIN MailLogItem mi ON mi.m_ID = m.ID " +
                            "WHERE 1=1" + strWhere +
                            "GROUP BY m.ID, m.Subject, m.CreateDate";

            DataTable dtResult = db.ExecuteDataTable(strSQL, "CreateDate DESC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得指定的廣告信發送對象記錄</summary>
        public static DataTable GetMailLogItem(string ID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM MailLogItem WHERE m_ID=@ID";
            return db.ExecuteDataTable();
        }

        /// <summary>取得指定的廣告信資料</summary>
        public static DataRow GetMailLogData(string ID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM MailLog WHERE ID=@ID";

            return db.ExecuteDataTable().Rows[0];
        }

        /// <summary>新增或修改廣告信資料</summary>
        public static void ModifyMailLog(string ID, string Subject, string Content, string EmailList, out bool Result, out string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                #region MailLog
                //增加SQL參數
                cmd.Parameters.Clear();
                cmd.Parameters.Add(new SqlParameter("ID", Tool.GetDBNullString(ID)));
                cmd.Parameters.Add(new SqlParameter("Subject", Subject));
                cmd.Parameters.Add(new SqlParameter("Content", Content));
                cmd.Parameters.Add(new SqlParameter("Creater", Authority.UserInfo.SessionState.ID));

                cmd.CommandText = "IF (@ID IS NULL) BEGIN " +
                                      "INSERT MailLog(Subject, Content, Creater, CreateDate) VALUES(@Subject, @Content, @Creater, getdate()); " +
                                  "END";
                cmd.ExecuteNonQuery();

                #region MailLogItem
                //循序讀取Email對象地址
                foreach (string strEmail in EmailList.Split(','))
                {
                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("ID", Tool.GetDBNullString(ID)));
                    cmd.Parameters.Add(new SqlParameter("Email", strEmail));
                    cmd.Parameters.Add(new SqlParameter("Creater", Authority.UserInfo.SessionState.ID));

                    cmd.CommandText = "IF (@ID IS NULL) BEGIN " +
                                          "SET @ID = (SELECT MAX(ID) FROM MailLog); " +
                                      "END " +
                                      "INSERT MailLogItem(m_ID, Email, Creater, CreateDate) VALUES(@ID, @Email, @Creater, getdate());";
                    cmd.ExecuteNonQuery();
                }
                #endregion

                #endregion

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        #endregion

        #region Price

        /// <summary>新增會員的價格定義表</summary>
        public static void InsertMemberPriceTitle(string MemberID, string Title, string Description, string OrderType, string StartQty, string EndQty, string Sort, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            param.Add("Title", Title);
            param.Add("Description", Tool.GetDBNullString(Description));
            param.Add("Type", OrderType);
            param.Add("StartQty", Tool.GetDBNullString(StartQty));
            param.Add("EndQty", Tool.GetDBNullString(EndQty));
            param.Add("Sort", Sort);
            param.Add("outError", ParameterDirection.Output);
            param.Add("outMessage", ParameterDirection.Output);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "IF NOT EXISTS(SELECT * FROM PriceTitle WHERE Member_ID=@MemberID AND Title=@Title) BEGIN " +
                            "IF NOT EXISTS(SELECT * FROM PriceTitle WHERE Member_ID=@MemberID AND Sort=@Sort) BEGIN " +
                                "INSERT PriceTitle(Member_ID, Title, Description, Type, StartQty, EndQty, Sort, DateTime) VALUES(@MemberID, @Title, @Description, @Type, @StartQty, @EndQty, @Sort, getdate()); " +
                            "END ELSE BEGIN " +
                                "SELECT @outError='1', @outMessage='作業中斷，排序碼重覆!'; " +
                            "END " +
                        "END ELSE BEGIN " +
                            "SELECT @outError='1', @outMessage='作業中斷，標題可能已存在!'; " +
                        "END ";

            db.ExecuteSQL();

            Result = param["outError"].Value.ToString() == "";
            Message = param["outMessage"].Value.ToString();
        }

        /// <summary>修改會員的價格定義表</summary>
        public static void UpdateMemberPriceTitle(string ID, string MemberID, string Description, string OrderType, string StartQty, string EndQty, string Sort, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("MemberID", MemberID);
            param.Add("Description", Tool.GetDBNullString(Description));
            param.Add("Type", OrderType);
            param.Add("StartQty", Tool.GetDBNullString(StartQty));
            param.Add("EndQty", Tool.GetDBNullString(EndQty));
            param.Add("Sort", Sort);
            param.Add("outError", ParameterDirection.Output);
            param.Add("outMessage", ParameterDirection.Output);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "IF NOT EXISTS(SELECT * FROM PriceTitle WHERE Member_ID=@MemberID AND Sort=@Sort AND ID<>@ID) BEGIN " +
                            "UPDATE PriceTitle SET Description=@Description, Type=@Type, StartQty=@StartQty, EndQty=@EndQty, Sort=@Sort, DateTime=getdate() WHERE ID=@ID; " +
                        "END ELSE BEGIN " +
                            "SELECT @outError='1', @outMessage='作業中斷，排序碼重覆!'; " +
                        "END ";

            db.ExecuteSQL();

            Result = param["outError"].Value.ToString() == "";
            Message = param["outMessage"].Value.ToString();
        }

        /// <summary>刪除會員的價格定義表</summary>
        public static void DeleteMemberPriceTitle(string MemberID, string Title, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            param.Add("Title", Title);
            param.Add("outError", ParameterDirection.Output);
            param.Add("outMessage", ParameterDirection.Output);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "DELETE FROM PriceTitle WHERE Member_ID=@MemberID AND Title=@Title; " +
                        "UPDATE PriceList SET PriceXml.modify('delete /Price/Item[@Title=\"" + Title + "\"]') WHERE Member_ID=@MemberID; ";

            try
            {
                db.ExecuteSQL();
                Result = true;
            }
            catch (Exception e)
            {
                Result = false;
                Message = e.Message;
            }
        }

        /// <summary>匯出會員的價格定義表</summary>
        public static DataTable GetMemberPriceTable(string ID, string MemberID, string Title)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("MemberID", MemberID);
            param.Add("Title", Title);
            db.SqlParams = param;

            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND ID=@ID "; }
            if (!string.IsNullOrEmpty(MemberID)) { strWhere += " AND Member_ID=@MemberID "; }
            if (!string.IsNullOrEmpty(Title)) { strWhere += " AND Title=@Title "; }

            //SQL
            db.StrSQL = "SELECT * FROM PriceTitle WHERE 1=1 " + strWhere + " ORDER BY Sort";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>匯出會員的價格表</summary>
        public static DataTable GetMemberPriceList(string MemberID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            db.SqlParams = param;

            db.StrSQL = "WITH temp AS (SELECT LM [ProductName] FROM UHRLampModule UNION SELECT BL FROM UHRLampModule) " +
                        "SELECT * FROM temp t " +
                        "LEFT OUTER JOIN PriceList p ON p.ProductName=t.ProductName AND p.Member_ID=@MemberID";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>匯入會員的價格表</summary>
        public static void ImportMemberPriceList(string MemberID, DataTable dt, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                //刪除此會員的價格表記錄
                cmd.CommandText = "DELETE FROM PriceList WHERE Member_ID=" + MemberID;
                cmd.ExecuteNonQuery();

                DataTable dtColumnTable = GetMemberPriceTable(null, MemberID, null); //取得價格定義表

                //依序讀取價格列
                foreach (DataRow row in dt.Rows)
                {
                    string strProductName = row["ProductName"].ToString(); //取得品名

                    //依序組成價格XML項目
                    string strXml = "", strItems = "";
                    foreach (DataRow rowTitle in dtColumnTable.Rows)
                    {
                        string strTitle = rowTitle["Title"].ToString();
                        string strPrice = row[strTitle].ToString();

                        decimal outValue;
                        decimal.TryParse(strPrice, out outValue);
                        if (outValue > 0)
                        {
                            strItems += string.Format("<Item Title=\"{0}\">{1}</Item>", strTitle, outValue.ToString("F2"));
                        }
                    }

                    //若有XML項目則執行新增SQL
                    if (!string.IsNullOrEmpty(strItems))
                    {
                        strXml += "<Price>" + strItems + "</Price>";

                        //增加SQL參數
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add(new SqlParameter("MemberID", MemberID));
                        cmd.Parameters.Add(new SqlParameter("ProductName", strProductName));
                        cmd.Parameters.Add(new SqlParameter("PriceXml", strXml));
                        cmd.Parameters.Add(new SqlParameter("Error", SqlDbType.Int, 1)).Direction = ParameterDirection.ReturnValue;

                        //增加價格表記錄
                        cmd.CommandText = "IF EXISTS(SELECT * FROM UHRLampModule WHERE LM=@ProductName OR BL=@ProductName) BEGIN " +
                                             "INSERT PriceList(Member_ID, ProductName, PriceXml, DateTime) VALUES(@MemberID, @ProductName, @PriceXml, getdate()); " +
                                          "END";

                        if (cmd.ExecuteNonQuery() < 1) throw new Exception(strProductName + " 作業失敗!");
                    }
                }

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        /// <summary>複製會員的價格表</summary>
        public static void CopyMemberPrice(string MainID, string EditIDList, ref bool Result, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);
            SqlCommand cmd = db.SqlCommand;
            SqlTransaction trans = db.SetTransaction(cmd);

            try
            {
                foreach (string id in EditIDList.Split(';'))
                {
                    //增加SQL參數
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("MainID", MainID));
                    cmd.Parameters.Add(new SqlParameter("EditID", id));

                    cmd.CommandText = "DELETE FROM PriceTitle WHERE Member_ID = @EditID; " +
                                      "DELETE FROM PriceList WHERE Member_ID = @EditID; " +

                                      "INSERT PriceTitle(Member_ID, Title, Description, Type, StartQty, EndQty, Sort, DateTime) " +
                                      "SELECT @EditID, Title, Description, Type, StartQty, EndQty, Sort, getdate() FROM PriceTitle WHERE Member_ID = @MainID; " +

                                      "INSERT PriceList(Member_ID, ProductName, PriceXml, DateTime) " +
                                      "SELECT @EditID, ProductName, PriceXml, getdate() FROM PriceList WHERE Member_ID = @MainID; ";

                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                Result = true;
                Message = "作業成功!";
            }
            catch (Exception e)
            {
                trans.Rollback();
                Result = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            trans.Dispose();
            cmd.Dispose();
        }

        #endregion

        #region Log

        /// <summary>匯出瀏覽記錄Log</summary>
        public static DataTable GetLog(string Type, string StartDate, string EndDate)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);
            param.Add("StartDate", StartDate);
            param.Add("EndDate", EndDate);
            db.SqlParams = param;

            string strWhere = "";
            if (!string.IsNullOrEmpty(Type)) { strWhere += " AND l.Type=@Type "; }
            if (!string.IsNullOrEmpty(StartDate)) { strWhere += " AND l.DateTime >= @StartDate "; }
            if (!string.IsNullOrEmpty(EndDate)) { strWhere += " AND l.DateTime <= @EndDate "; }

            //SQL
            db.StrSQL = "IF(@Type='B') BEGIN " +
                            "SELECT m.LM [Lamp Module], a.Name [Member], a.Company, c.Name [Country], l.DateTime " +
                            "FROM Log l " +
                            "LEFT OUTER JOIN Product p ON p.ID=l.P_ID " +
                            "LEFT OUTER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                            "LEFT OUTER JOIN Member a ON a.ID=l.Member_ID " +
                            "LEFT OUTER JOIN Country c ON c.Code=a.Country " +
                            "WHERE 1=1 " + strWhere + " ORDER BY DateTime; " +
                        "END ELSE IF(@Type='K') BEGIN " +
                            "SELECT l.Keyword, a.Name [Member], a.Company, c.Name [Country], l.DateTime " +
                            "FROM Log l " +
                            "LEFT OUTER JOIN Member a ON a.ID=l.Member_ID " +
                            "LEFT OUTER JOIN Country c ON c.Code=a.Country " +
                            "WHERE 1=1 " + strWhere + " ORDER BY DateTime; " +
                        "END";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        #endregion

        #region 訂單

        /// <summary>取得訂單記錄</summary>
        public static DataTable GetOrderHistory(string ID, string OrderNo, string Email, string ERPCompany, string ERPCustomCode, string StartDate, string EndDate, string Company, string Name, string DataType, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //設定參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("OrderNo", OrderNo);
            param.Add("Email", "%" + Email + "%");
            param.Add("ERPCompany", ERPCompany);
            param.Add("ERPCustomCode", ERPCustomCode);
            param.Add("StartDate", StartDate);
            param.Add("EndDate", EndDate);
            param.Add("Company", "%" + Company + "%");
            param.Add("Name", "%" + Name + "%");
            db.SqlParams = param;

            //SqlCommand物件
            SqlCommand cmd = db.SqlCommand;

            //若DataType為未轉ERP
            string strTable = "";
            if (DataType == "N")
            {
                //建立暫存表
                db.CloseDatabaseState("Y");
                cmd.CommandText = "SELECT TB012 INTO tmp001 FROM " + Definition.ERPDBName + "COPTB UNION SELECT TB012 FROM " + Definition.UHRlampsDBName + "COPTB";
                cmd.ExecuteNonQuery();
                db.CloseDatabaseState("N");

                strTable += "LEFT OUTER JOIN tmp001 b ON b.TB012 COLLATE Chinese_Taiwan_Stroke_CI_AS=o.OrderNum ";
            }

            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND o.ID=@ID"; }
            if (!string.IsNullOrEmpty(OrderNo)) { strWhere += " AND o.OrderNum=@OrderNo "; }
            if (!string.IsNullOrEmpty(Email)) { strWhere += " AND m.Email LIKE @Email "; }
            if (!string.IsNullOrEmpty(ERPCompany)) { strWhere += " AND m.ERP_Company=@ERPCompany "; }
            if (!string.IsNullOrEmpty(ERPCustomCode)) { strWhere += " AND m.ERP_CustomCode=@ERPCustomCode "; }
            if (!string.IsNullOrEmpty(StartDate)) { strWhere += " AND o.Date >= @StartDate "; }
            if (!string.IsNullOrEmpty(EndDate)) { strWhere += " AND o.Date <= @EndDate "; }
            if (!string.IsNullOrEmpty(Company)) { strWhere += " AND m.Company LIKE @Company "; }
            if (!string.IsNullOrEmpty(Name)) { strWhere += " AND m.Name LIKE @Name "; }
            if (DataType == "N") { strWhere += " AND o.Date >= '2013/7/1' AND o.Cancel IS NULL AND b.TB012 IS NULL "; }

            //SQL
            string strSQL = "SELECT m.Email, m.ERP_Company, m.ERP_CustomCode, o.ID, o.Member_ID, o.OrderNum, c.Name [Type], o.Attn, o.PO, o.Tel, o.ShippingAddress, o.BillingAddress, o.Comment, Convert(Varchar(10), o.Date,111) [Date], o.Attachment, o.Cancel FROM [Order] o " +
                            "INNER JOIN Config c ON c.Type='OrderType' AND o.Type=c.Value " +
                            "INNER JOIN Member m ON m.ID=o.Member_ID " + strTable +
                            "WHERE 1=1" + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "OrderNum DESC", _pageindex, _pagesize, out _recordcount);

            //若DataType為未轉ERP
            if (DataType == "N")
            {
                db.CloseDatabaseState("Y");
                cmd.CommandText = "DROP TABLE tmp001";
                cmd.ExecuteNonQuery();
                db.CloseDatabaseState("N");
            }

            return dtResult;
        }

        /// <summary>取得訂單單身項目歷史記錄</summary>
        public static DataTable GetOrderItemList(string OrderID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderID", OrderID);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM OrderItem WHERE Order_ID=@OrderID";

            return db.ExecuteDataTable();
        }

        /// <summary>取得OrderNumber對應ERP的報價單號</summary>
        public static DataTable GetInquiryNumberInERP(string OrderNumber)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderNumber", OrderNumber);
            db.SqlParams = param;

            db.StrSQL = "SELECT COMPANY,TB001,TB002 FROM (" +
                            "SELECT COMPANY,TB001,TB002,TB012 FROM " + Definition.ERPDBName + "COPTB UNION " +
                            "SELECT COMPANY,TB001,TB002,TB012 FROM " + Definition.UHRlampsDBName + "COPTB " +
                        ")r " +
                        "WHERE TB012=@OrderNumber " +
                        "ORDER BY COMPANY,TB001,TB002";

            return db.ExecuteDataTable();
        }

        /// <summary>取消訂單</summary>
        public static void CancelOrder(string OrderNumber)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderNumber", OrderNumber);
            db.SqlParams = param;

            db.StrSQL = "UPDATE [Order] SET Cancel='Y' WHERE OrderNum=@OrderNumber";

            db.ExecuteSQL();
        }

        /// <summary>取得訂單匯出明細</summary>
        public static DataTable GetOrderExportDetail(string OrderType, string StartDate, string EndDate)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderType", OrderType);
            param.Add("StartDate", StartDate);
            param.Add("EndDate", EndDate);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(OrderType)) { strWhere += " AND o.Type=@OrderType "; }
            if (!string.IsNullOrEmpty(StartDate)) { strWhere += " AND o.Date >= @StartDate "; }
            if (!string.IsNullOrEmpty(EndDate)) { strWhere += " AND o.Date <= @EndDate "; }

            db.StrSQL = "SELECT m.ERP_Company, m.ERP_CustomCode, m.Company, o.PO, oi.ProductNo, oi.CustomPN, oi.CustomDESC, oi.Quantity, oi.Currency + ' ' + Convert(varchar(10),oi.UnitPrice) [UnitPrice], o.OrderNum, o.Date FROM [Order] o " +
                        "INNER JOIN Member m ON m.ID=o.Member_ID " +
                        "INNER JOIN OrderItem oi ON oi.Order_ID=o.ID " +
                        "WHERE 1=1" + strWhere +
                        "ORDER BY m.ERP_Company, m.ERP_CustomCode, o.OrderNum";

            return db.ExecuteDataTable();
        }

        #endregion

        /// <summary>取得Config定義表的資料</summary>
        public static DataTable GetConfigData(string Type)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRWebConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Config WHERE Type=@Type";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }
    }
}