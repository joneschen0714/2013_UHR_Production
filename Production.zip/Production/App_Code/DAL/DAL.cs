﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class DAL
    {
        public DAL()
        {

        }

        /// <summary>取得使用者相關資料</summary>
        public static DataRow GetUserInfo(string _id, string _account, string _email)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _id);
            param.Add("Email", _email);
            param.Add("Account", _account);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_id != "") { strWhere += " AND ID=@ID "; }
            if (_email != "") { strWhere += " AND Email=@Email "; }
            if (_account != "") { strWhere += " AND Account=@Account "; }

            db.StrSQL = "SELECT * FROM Admin WHERE 1=1" + strWhere;

            DataRow row = null;
            DataTable dtResult = db.ExecuteDataTable();
            if (dtResult.Rows.Count > 0) { row = dtResult.Rows[0]; }

            return row;
        }

        /// <summary>取得使用者群組相關資料</summary>
        public static DataRow GetGroupInfo(string _groupnum)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("GroupNumber", _groupnum);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM AdminGroup WHERE GroupNumber=@GroupNumber";

            DataRow row = null;
            DataTable dtResult = db.ExecuteDataTable();
            if (dtResult.Rows.Count > 0) { row = dtResult.Rows[0]; }

            return row;
        }

        /// <summary>取得選單相關資料</summary>
        public static DataTable GetMenuList(string ParentNo, string Enabled)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ParentNo", ParentNo);
            param.Add("Enabled", Enabled);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ParentNo)) { strWhere += " AND ParentNo=@ParentNo "; }
            if (!string.IsNullOrEmpty(Enabled)) { strWhere += " AND Enabled=@Enabled "; }

            db.StrSQL = "SELECT * FROM Menu WHERE 1=1 " + strWhere + " ORDER BY OrderID";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得單一選單相關資料</summary>
        public static DataRow GetMenuInfo(string _menuno, string _menulink, string _type)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MenuNo", _menuno);
            param.Add("MenuLink", _menulink);
            param.Add("Type", _type);
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (_menuno != "") { strWhere += " AND MenuNo=@MenuNo "; }
            if (_menulink != "") { strWhere += " AND MenuLink=@MenuLink "; }
            if (_menulink != "") { strWhere += " AND Type=@Type "; }

            db.StrSQL = "SELECT * FROM Menu WHERE 1=1" + strWhere;

            DataRow row = null;
            DataTable dtResult = db.ExecuteDataTable();
            if (dtResult.Rows.Count > 0) { row = dtResult.Rows[0]; }

            return row;
        }

        /// <summary>取得TabMenu選單資料</summary>
        public static DataTable GetTabMenuInfo(string _groupname)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.AuthConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("GroupName", _groupname);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM Menu WHERE GroupName=@GroupName AND Type='Page' AND Enabled=1 AND GroupName<>'' ORDER BY OrderID";
            return db.ExecuteDataTable();
        }
    }
}