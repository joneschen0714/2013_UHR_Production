﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR.Util;
using System.Linq;

namespace UHR
{
    public class BLL_ERP
    {
        public BLL_ERP()
        {

        }

        /// <summary>取得客戶訂單的列表資料</summary>
        public static DataTable GetOrderList(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.GetOrderList(公司別, 單別, 單號);
        }

        /// <summary>取得銷貨單的列表資料</summary>
        public static DataTable GetSellingList(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.GetSellingList(公司別, 單別, 單號);
        }

        /// <summary>取得銷退單的列表資料</summary>
        public static DataTable GetReturnGoodsList(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.GetReturnGoodsList(公司別, 單別, 單號);
        }

        /// <summary>取得借入單的列表資料</summary>
        public static DataTable GetBorrowList(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.GetBorrowList(公司別, 單別, 單號);
        }

        /// <summary>取得借入歸還單的列表資料</summary>
        public static DataTable GetLoaningList(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.GetLoaningList(公司別, 單別, 單號);
        }

        /// <summary>取得序號是否存在</summary>
        public static bool ExistsSerialNo(string 序號)
        {
            return DAL_ERP.ExistsSerialNo(序號);
        }

        /// <summary>取得序號對應的品號</summary>
        public static string GetProductWithSerialNo(string 序號)
        {
            return DAL_ERP.GetProductWithSerialNo(序號);
        }

        /// <summary>取得序號資料</summary>
        public static DataTable GetSerialData(string 公司別, string 品號, string 序號, string 單別, string 單號, string 項次, string 拆單單號)
        {
            return DAL_ERP.GetSerialData(公司別, 品號, 序號, 單別, 單號, 項次, 拆單單號);
        }

        /// <summary>取得序號單頭檔資料</summary>
        public static DataTable GetSerialHead(string 品號, string 序號清單, string 製令單別, string 製令單號)
        {
            string[] strSplit = new string[] { System.Environment.NewLine };
            string[] strSerialNoList = 序號清單.Split(strSplit, StringSplitOptions.RemoveEmptyEntries); //序號清單

            序號清單 = "";
            foreach (string strSerialNo in strSerialNoList)
            {
                序號清單 += "'" + strSerialNo.Trim() + "',";
            }
            序號清單 = 序號清單.Trim(',');

            return DAL_ERP.GetSerialHead(品號, 序號清單, 製令單別, 製令單號);
        }

        /// <summary>匯出序號清單歷史單據資料</summary>
        public static DataTable ExportSerialNoHistory(string 序號清單, string 製令單別, string 製令單號)
        {
            string[] strSplit = new string[] { System.Environment.NewLine };
            string[] strSerialNoList = 序號清單.Split(strSplit, StringSplitOptions.RemoveEmptyEntries); //序號清單

            序號清單 = "";
            foreach (string strSerialNo in strSerialNoList)
            {
                序號清單 += "'" + strSerialNo.Trim() + "',";
            }
            序號清單 = 序號清單.Trim(',');

            return DAL_ERP.ExportSerialNoHistory(序號清單, 製令單別, 製令單號);
        }

        /// <summary>刪除序號資料</summary>
        public static void DeleteSerialNo(string 公司別, string 品號, string 序號, string 狀態, string 單別, string 單號, string 項次, string 拆單單號)
        {
            DAL_ERP.DeleteSerialNo(公司別, 品號, 序號, 狀態, 單別, 單號, 項次, 拆單單號);
        }

        /// <summary>刪除序號定義資料</summary>
        public static bool DeleteSerialNoHead(string 序號)
        {
            return DAL_ERP.DeleteSerialNoHead(序號);
        }

        /// <summary>新增&修改序號資料</summary>
        public static int ModifySerialNo(string 公司別, string 品號, string 序號, string 製令單別, string 製令單號, string 狀態, string 單別, string 單號, string 項次, string 拆單單號, string ReasonCode, string 備註)
        {
            return DAL_ERP.ModifySerialNo(公司別, 品號, 序號, 製令單別, 製令單號, 狀態, 單別, 單號, 項次, 拆單單號, ReasonCode, 備註);
        }

        /// <summary>新增&修改序號的QA RMA ReasonCode</summary>
        public static int ModifySerialReasonCodeQA(string 公司別, string 單別, string 單號, string 項次, string 品號, string 序號, string ReasonCodeQA, string 備註)
        {
            項次 = 項次.ToString().PadLeft(4, '0');
            return DAL_ERP.ModifySerialReasonCodeQA(公司別, 單別, 單號, 項次, 品號, 序號, ReasonCodeQA, 備註);
        }

        /// <summary>取得最後的銷貨單號</summary>
        public static string GetLastSellingFormNumber(string 公司別, string 序號)
        {
            return DAL_ERP.GetLastSellingFormNumber(公司別, 序號);
        }

        /// <summary>取得ReasonCode清單資料</summary>
        public static DataTable GetReasonCodeList()
        {
            return DAL_ERP.GetReasonCodeList();
        }

        /// <summary>取得RMA Form資料(借入單)</summary>
        public static DataSet GetRMAFormData(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetRMAFormData(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["RMA單頭"];
            DataTable dtBody = ds.Tables["RMA單身"];
            DataTable dtSerial = DAL_ERP.GetSerialData(公司別, null, null, _單別, _單號, null, null);

            DataTable dtBody1 = dtBody.Clone();

            if (dtHead.Rows.Count > 0)
            {
                int iInWarranty = 0;
                foreach (DataRow rowBody in ds.Tables["RMA單身"].Rows)
                {
                    DataRow[] rowsSerial = dtSerial.Select("項次='" + rowBody["項次"].ToString() + "'");
                    if (rowsSerial.Length > 0)
                    {
                        foreach (DataRow rowSerial in rowsSerial)
                        {
                            rowBody["產品序號"] = rowSerial["序號"].ToString();
                            rowBody["ReasonCode名稱"] = rowSerial["Reason"].ToString();
                            rowBody["ReasonCode代號"] = rowSerial["ReasonCode"].ToString();
                            dtBody1.Rows.Add(rowBody.ItemArray);

                            iInWarranty++;
                        }
                    }
                    else
                    {
                        dtBody1.Rows.Add(rowBody.ItemArray);
                    }
                }

                //替換RMA單身表
                ds.Tables.Remove("RMA單身");
                ds.Tables.Add(dtBody1);

                dtHead.Rows[0]["ToReplace"] = iInWarranty;
                dtHead.Rows[0]["InWarranty"] = iInWarranty;
            }

            return ds;
        }

        /// <summary>取得RMA Form資料(銷退單)</summary>
        public static DataSet GetRMAFormCOPTI(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetRMAFormCOPTI(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["RMA單頭"];
            DataTable dtBody = ds.Tables["RMA單身"];
            DataTable dtSerial = DAL_ERP.GetSerialData(公司別, null, null, _單別, _單號, null, null);

            DataTable dtBody1 = dtBody.Clone();

            if (dtHead.Rows.Count > 0)
            {
                int iInWarranty = 0;
                foreach (DataRow rowBody in ds.Tables["RMA單身"].Rows)
                {
                    DataRow[] rowsSerial = dtSerial.Select("項次='" + rowBody["項次"].ToString() + "'");
                    if (rowsSerial.Length > 0)
                    {
                        foreach (DataRow rowSerial in rowsSerial)
                        {
                            rowBody["產品序號"] = rowSerial["序號"].ToString();
                            rowBody["ReasonCode名稱"] = rowSerial["Reason"].ToString();
                            rowBody["ReasonCode代號"] = rowSerial["ReasonCode"].ToString();
                            dtBody1.Rows.Add(rowBody.ItemArray);

                            iInWarranty++;
                        }
                    }
                    else
                    {
                        dtBody1.Rows.Add(rowBody.ItemArray);
                    }
                }

                //替換RMA單身表
                ds.Tables.Remove("RMA單身");
                ds.Tables.Add(dtBody1);

                dtHead.Rows[0]["InWarranty"] = iInWarranty;
            }

            return ds;
        }

        /// <summary>取得受訂單的資料</summary>
        public static DataSet GetSoFormData(string 公司別, string _單別, string _單號)
        {
            DataSet ds = DAL_ERP.GetSoFormData(公司別, _單別, _單號);
            DataTable dtHead = ds.Tables["受訂單頭"];
            DataTable dtBody = ds.Tables["受訂單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             group r by r.Field<string>("報價單號") into t
                             select new
                             {
                                 報價單號 = t.Key,
                                 總訂單數 = t.Sum(a => a.Field<decimal>("訂單數量")),
                                 總贈品數 = t.Sum(a => a.Field<decimal>("贈備品數量"))
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["總訂單數量"] = item.總訂單數;
                    dtHead.Rows[0]["總贈備品數量"] = item.總贈品數;
                    dtHead.Rows[0]["總數量"] = item.總訂單數 + item.總贈品數;
                    dtHead.Rows[0]["報價單號"] = item.報價單號;
                }
            }

            return ds;
        }

        /// <summary>取得Invoice的資料</summary>
        public static DataSet GetInvoiceFormData(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetInvoiceFormData(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["Invoice單頭"];
            DataTable dtBody = ds.Tables["Invoice單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             where r.Field<string>("品號") != "9999" //濾掉品號為99999
                             group r by r.Field<string>("銷貨單號") into t
                             select new
                             {
                                 TotalQty = t.Sum(a => a.Field<decimal>("數量")), //累加數量
                                 Amount = t.Sum(a => a.Field<decimal>("數量") * a.Field<decimal>("單價")), //累加稅前、折扣前的金額
                                 TotalDiscount = (from r in t
                                                  where r.Field<decimal>("折扣率") != 1
                                                  select (r.Field<decimal>("數量") * r.Field<decimal>("單價")) - r.Field<decimal>("金額")).Sum() //若有Discount，則累加Discount金額
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["TotalQty"] = item.TotalQty;
                    dtHead.Rows[0]["Amount"] = item.Amount;
                    dtHead.Rows[0]["TotalDiscount"] = item.TotalDiscount;
                }
            }

            return ds;
        }

        /// <summary>取得Invoice RMA的資料</summary>
        public static DataSet GetInvoiceFormRMA(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetInvoiceFormRMA(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["Invoice單頭"];
            DataTable dtBody = ds.Tables["Invoice單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             group r by r.Field<string>("銷貨單號") into t
                             select new
                             {
                                 TotalQty = t.Sum(a => a.Field<decimal>("數量")), //累加數量
                                 TotalAmount = t.Sum(a => a.Field<decimal>("數量") * a.Field<int>("單價")) //累加稅前、折扣前的金額
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["TotalQty"] = item.TotalQty;
                    dtHead.Rows[0]["TotalAmount"] = item.TotalAmount;
                }
            }

            return ds;
        }

        /// <summary>取得Invoice的資料(從借出入歸還單)</summary>
        public static DataSet GetInvoiceFromINVTH(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetInvoiceFromINVTH(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["Invoice單頭"];
            DataTable dtBody = ds.Tables["Invoice單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             group r by r.Field<string>("銷貨單號") into t
                             select new
                             {
                                 TotalQty = t.Sum(a => a.Field<decimal>("數量")), //累加數量
                                 TotalAmount = t.Sum(a => a.Field<decimal>("數量") * a.Field<int>("單價")) //累加稅前、折扣前的金額
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["TotalQty"] = item.TotalQty;
                    dtHead.Rows[0]["TotalAmount"] = item.TotalAmount;
                }
            }

            return ds;
        }

        /// <summary>取得Invoice的資料(從暫出入單)</summary>
        public static DataSet GetInvoiceFromINVTF(string 公司別, string _單別, string _單號, string _確認碼)
        {
            DataSet ds = DAL_ERP.GetInvoiceFromINVTF(公司別, _單別, _單號, _確認碼);
            DataTable dtHead = ds.Tables["Invoice單頭"];
            DataTable dtBody = ds.Tables["Invoice單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             where r.Field<string>("品號") != "9999" //濾掉品號為99999
                             group r by r.Field<string>("銷貨單號") into t
                             select new
                             {
                                 TotalQty = t.Sum(a => a.Field<decimal>("數量")), //累加數量
                                 Amount = t.Sum(a => a.Field<decimal>("數量") * a.Field<decimal>("單價")), //累加稅前、折扣前的金額
                                 TotalDiscount = (from r in t
                                                  where r.Field<decimal>("折扣率") != 1
                                                  select (r.Field<decimal>("數量") * r.Field<decimal>("單價")) - r.Field<decimal>("金額")).Sum() //若有Discount，則累加Discount金額
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["TotalQty"] = item.TotalQty;
                    dtHead.Rows[0]["Amount"] = item.Amount;
                    dtHead.Rows[0]["TotalDiscount"] = item.TotalDiscount;
                }
            }

            return ds;
        }

        /// <summary>取得Invoice的資料(從銷退單)</summary>
        public static DataSet GetInvoiceFormCOPTI(string 公司別, string 單別, string 單號, string 確認碼)
        {
            return DAL_ERP.GetInvoiceFormCOPTI(公司別, 單別, 單號, 確認碼);
        }

        /// <summary>取得ERP009的資料</summary>
        public static DataSet GetERP009(string 公司別, object 單別, object 單號, string 確認碼)
        {
            DataSet ds = DAL_ERP.GetERP009(公司別, 單別, 單號, 確認碼);
            DataTable dtHead = ds.Tables["CREDIT單頭"];
            DataTable dtBody = ds.Tables["CREDIT單身"];

            if (dtHead.Rows.Count > 0)
            {
                var result = from r in dtBody.AsEnumerable()
                             group r by new { FormClass = r.Field<string>("FormClass"), FormNumber = r.Field<string>("FormNumber") } into t
                             select new
                             {
                                 TotalQty = t.Sum(a => a.Field<decimal>("Qty")),
                                 Amount = t.Sum(a => a.Field<decimal>("SubTotal"))
                             };

                foreach (var item in result)
                {
                    dtHead.Rows[0]["TotalQty"] = item.TotalQty;
                    dtHead.Rows[0]["Amount"] = item.Amount;
                    dtHead.Rows[0]["TotalAmount"] = item.Amount;
                }
            }

            return ds;
        }

        /// <summary>匯出銷貨單的單據與序號資料</summary>
        public static DataTable ExportSellingData(string 公司別, string 單別, string 單號)
        {
            DataTable dtSellingForm = DAL_ERP.ExportSellingData(公司別, 單別, 單號);
            DataTable dtSerialNo = DAL_ERP.GetSerialData(公司別, null, null, 單別, 單號, null, null); //序號資料

            //複製並清除資料
            DataTable dtNew = dtSellingForm.Clone();

            //循序讀取單據單身資料
            foreach (DataRow row in dtSellingForm.Rows)
            {
                DataRow[] rowsSerial = dtSerialNo.Select("項次='" + row["Item"].ToString() + "'");
                if (rowsSerial.Length > 0)
                {
                    foreach (DataRow rowSerial in rowsSerial)
                    {
                        row["Serial Number"] = rowSerial["序號"].ToString();
                        dtNew.Rows.Add(row.ItemArray);
                    }
                }
                else
                {
                    dtNew.Rows.Add(row.ItemArray);
                }
            }

            return dtNew;
        }

        /// <summary>匯出借入單的單據與序號資料</summary>
        public static DataTable ExportBorrowData(string 公司別, string 單別, string 單號)
        {
            DataTable dtBorrowForm = DAL_ERP.ExportBorrowData(公司別, 單別, 單號);
            DataTable dtSerialNo = DAL_ERP.GetSerialData(公司別, null, null, 單別, 單號, null, null); //序號資料

            //複製並清除資料
            DataTable dtNew = dtBorrowForm.Clone();

            //循序讀取單據單身資料
            foreach (DataRow row in dtBorrowForm.Rows)
            {
                DataRow[] rowsSerial = dtSerialNo.Select("項次='" + row["項次"].ToString() + "'");
                if (rowsSerial.Length > 0)
                {
                    foreach (DataRow rowSerial in rowsSerial)
                    {
                        row["序號"] = rowSerial["序號"].ToString();
                        row["ReasonCode"] = rowSerial["ReasonCode"].ToString();
                        row["Reason"] = rowSerial["Reason"].ToString();
                        row["ReasonCodeQA"] = rowSerial["ReasonCodeQA"].ToString();
                        row["ReasonQA"] = rowSerial["ReasonQA"].ToString();
                        row["最後銷貨單號"] = BLL_ERP.GetLastSellingFormNumber(公司別, rowSerial["序號"].ToString());
                        row["備註"] = rowSerial["備註"].ToString();
                        dtNew.Rows.Add(row.ItemArray);
                    }
                }
                else
                {
                    dtNew.Rows.Add(row.ItemArray);
                }
            }

            return dtNew;
        }

        /// <summary>匯出銷退單的單據與序號資料</summary>
        public static DataTable ExportReturnGoodsData(string 公司別, string 單別, string 單號)
        {
            DataTable dtReturnGoodsForm = DAL_ERP.ExportReturnGoodsData(公司別, 單別, 單號);
            DataTable dtSerialNo = DAL_ERP.GetSerialData(公司別, null, null, 單別, 單號, null, null); //序號資料

            //複製並清除資料
            DataTable dtNew = dtReturnGoodsForm.Clone();

            //循序讀取單據單身資料
            foreach (DataRow row in dtReturnGoodsForm.Rows)
            {
                DataRow[] rowsSerial = dtSerialNo.Select("項次='" + row["項次"].ToString() + "'");
                if (rowsSerial.Length > 0)
                {
                    foreach (DataRow rowSerial in rowsSerial)
                    {
                        row["序號"] = rowSerial["序號"].ToString();
                        row["最後銷貨單號"] = BLL_ERP.GetLastSellingFormNumber(公司別, rowSerial["序號"].ToString());
                        row["ReasonCodeQA"] = rowSerial["ReasonCodeQA"].ToString();
                        row["ReasonQA"] = rowSerial["ReasonQA"].ToString();
                        row["備註"] = rowSerial["備註"].ToString();
                        dtNew.Rows.Add(row.ItemArray);
                    }
                }
                else
                {
                    dtNew.Rows.Add(row.ItemArray);
                }
            }

            return dtNew;
        }

        /// <summary>匯出借入歸還單的單據與序號資料</summary>
        public static DataTable ExportReturnBorrowData(string 公司別, string 單別, string 單號)
        {
            DataTable dtReturnBorrowForm = DAL_ERP.ExportReturnBorrowData(公司別, 單別, 單號);
            DataTable dtSerialNo = DAL_ERP.GetSerialData(公司別, null, null, 單別, 單號, null, null); //序號資料

            //複製並清除資料
            DataTable dtNew = dtReturnBorrowForm.Clone();

            //循序讀取單據單身資料
            foreach (DataRow row in dtReturnBorrowForm.Rows)
            {
                DataRow[] rowsSerial = dtSerialNo.Select("項次='" + row["Item"].ToString() + "'");
                if (rowsSerial.Length > 0)
                {
                    foreach (DataRow rowSerial in rowsSerial)
                    {
                        row["Serial Number"] = rowSerial["序號"].ToString();
                        dtNew.Rows.Add(row.ItemArray);
                    }
                }
                else
                {
                    dtNew.Rows.Add(row.ItemArray);
                }
            }

            return dtNew;
        }

        /// <summary>匯出訂單的單據與序號資料</summary>
        public static DataTable ExportOrderData(string 公司別, string 單別, string 單號)
        {
            DataTable dtOrderForm = DAL_ERP.ExportOrderData(公司別, 單別, 單號);
            DataTable dtSerialNo = DAL_ERP.GetSerialData(公司別, null, null, 單別, 單號, null, null); //序號資料

            //複製並清除資料
            DataTable dtNew = dtOrderForm.Clone();

            //循序讀取單據單身資料
            foreach (DataRow row in dtOrderForm.Rows)
            {
                DataRow[] rowsSerial = dtSerialNo.Select("項次='" + row["Item"].ToString() + "'");
                if (rowsSerial.Length > 0)
                {
                    foreach (DataRow rowSerial in rowsSerial)
                    {
                        row["Serial Number"] = rowSerial["序號"].ToString();
                        dtNew.Rows.Add(row.ItemArray);
                    }
                }
                else
                {
                    dtNew.Rows.Add(row.ItemArray);
                }
            }

            return dtNew;
        }

        /// <summary>取得品號</summary>
        public static DataRow GetINVMB(string 品號)
        {
            return DAL_ERP.GetINVMB(品號);
        }

        /// <summary>取得報價單的單頭列表</summary>
        public static DataTable GetQuotationHeadList(string 公司別, string 單別, string 單號, string 確認碼, string 客戶代碼, string 員工代碼, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_ERP.GetQuotationHeadList(公司別, 單別, 單號, 確認碼, 客戶代碼, 員工代碼, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得報價單的單身列表</summary>
        public static DataTable GetQuotationBodyList(string 公司別, string _單別, string _單號)
        {
            return DAL_ERP.GetQuotationBodyList(公司別, _單別, _單號);
        }

        /// <summary>更新報價單的單身備註</summary>
        public static void EditQuotationBodyRemark(string 公司別, string 單別, string 單號, string 項次, string 備註)
        {
            DAL_ERP.EditQuotationBodyRemark(公司別, 單別, 單號, 項次, 備註);
        }

        /// <summary>新增或修改報價單資料</summary>
        public static void ModifyQuotationFormData(string 公司別, string _單別, string _單號, DataTable dtBody, bool b單價, ref bool Result, ref string Message)
        {
            foreach (DataRow row in dtBody.Rows)
            {
                string strProduct = Convert.ToString(row["品號"]);
                string strDate = Convert.ToString(row["生效日"]);

                DateTime t;
                if (!DateTime.TryParse(strDate, out t))
                {
                    Message = "日期格式錯誤，範例：yyyy/MM/dd";
                }
            }

            if (Message == "")
            {
                DAL_ERP.ModifyQuotationFormData(公司別, _單別, _單號, dtBody, b單價, ref Result, ref Message);
            }
        }

        /// <summary>由三角貿易帶入報價單資料</summary>
        public static void TriangleTradeToQuotation(string 來源公司別, string 來源採購單別, string 來源採購單號, string 目的公司別, string 目的報價單別, string 目的報價單號, ref bool Result, ref string Message)
        {
            DAL_ERP.TriangleTradeToQuotation(來源公司別, 來源採購單別, 來源採購單號, 目的公司別, 目的報價單別, 目的報價單號, ref Result, ref Message);
        }

        /// <summary>取得ERP使用者清單</summary>
        public static DataTable GetUserList(string 工號, string 中文姓名, string 部門名稱, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_ERP.GetUserList(工號, 中文姓名, 部門名稱, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得ERP客戶清單</summary>
        public static DataTable GetCustomerList(string 公司別, string 客戶代號, string 客戶名稱, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_ERP.GetCustomerList(公司別, 客戶代號, 客戶名稱, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得銷售預測資料-依品號</summary>
        public static DataTable GetSellingDivinationByProduct(string 期間, string 業務員)
        {
            return DAL_ERP.GetSellingDivinationByProduct(期間, 業務員);
        }

        /// <summary>取得銷售預測資料-依類別</summary>
        public static DataTable GetSellingDivinationByClass(string 期間, string 業務員)
        {
            return DAL_ERP.GetSellingDivinationByClass(期間, 業務員);
        }

        /// <summary>匯入銷售預測資料-依品號</summary>
        public static void ImportSellingDivinationToProduct(string 日期, DataTable dt, ref bool Result, ref string Message)
        {
            DAL_ERP.ImportSellingDivinationToProduct(日期, dt, ref  Result, ref  Message);
        }

        /// <summary>匯入銷售預測資料-依類別</summary>
        public static void ImportSellingDivinationToClass(string 日期, DataTable dt, ref bool Result, ref string Message)
        {
            DAL_ERP.ImportSellingDivinationToClass(日期, dt, ref  Result, ref  Message);
        }

        /// <summary>匯出RMA分析資料</summary>
        public static DataSet ExportRMARateData(string S製造期間, string E製造期間, string S出貨期間, string E出貨期間, string S借入期間, string E借入期間, string 品號, string 版次, string 客戶代號)
        {
            //取得來源資料
            DataSet ds = DAL_ERP.ExportRMARateData(S製造期間, E製造期間, S出貨期間, E出貨期間, S借入期間, E借入期間, 品號, 版次, 客戶代號);
            DataTable dtRMA = ds.Tables["RMA"];
            DataTable dtSell = ds.Tables["Sell"];

            //建立Summary Table
            DataTable dtSummary = new DataTable("Summary");
            dtSummary.Columns.Add("品號", Type.GetType("System.String"));
            dtSummary.Columns.Add("出貨數", Type.GetType("System.Int32"));
            dtSummary.Columns.Add("RMA數", Type.GetType("System.Int32"));

            //取出品號清單
            DataTable dtPartNo = Util.Tool.GetDataTableFilter(dtSell, "", "", false, "品號");
            DataTable dtPartNo1 = Util.Tool.GetDataTableFilter(dtRMA, "", "", false, "品號");

            dtPartNo.Merge(dtPartNo1); //資料合併
            DataTable dtNewPartNo = Util.Tool.GetDataTableFilter(dtPartNo, "", "品號 ASC", true, "品號"); //去除重複的品號

            //循序讀取品號清單
            int totalSell = 0, totalRma = 0;
            foreach (DataRow rowPartNo in dtNewPartNo.Rows)
            {
                //變數值
                string strPartNo = rowPartNo["品號"].ToString();
                object objSellQty = dtSell.Compute("Sum(Qty)", "品號='" + strPartNo + "'");
                object objRmaQty = dtRMA.Compute("Sum(Qty)", "品號='" + strPartNo + "'");

                objSellQty = (objSellQty == DBNull.Value ? 0 : objSellQty);
                objRmaQty = (objRmaQty == DBNull.Value ? 0 : objRmaQty);

                //增加ROW
                dtSummary.Rows.Add(strPartNo, objSellQty, objRmaQty);
            }

            //附件Summary Table
            ds.Tables.Add(dtSummary);

            return ds;
        }

        /// <summary>匯出各月RMA統計表</summary>
        public static DataTable ExportMonthRMARateData(string S製造期間, string E製造期間, string S出貨期間, string E出貨期間, string 品號)
        {
            return DAL_ERP.ExportMonthRMARateData(S製造期間, E製造期間, S出貨期間, E出貨期間, 品號);
        }

        /// <summary>取得借入單的單頭列表</summary>
        public static DataTable GetBorrowHeadList(string 公司別, string 單別, string 單號, string 確認碼, string 客戶代碼, string 員工代碼, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_ERP.GetBorrowHeadList(公司別, 單別, 單號, 確認碼, 客戶代碼, 員工代碼, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>刪除借入單的單身資料</summary>
        public static bool DeleteBorrowData(string 公司別, string 單別, string 單號)
        {
            return DAL_ERP.DeleteBorrowData(公司別, 單別, 單號);
        }

        /// <summary>新增借入單的單身資料</summary>
        public static bool InsertBorrowData(string 公司別, string 單別, string 單號, string 項次, string 品號, int 數量, string 預計歸還日, string 備註)
        {
            return DAL_ERP.InsertBorrowData(公司別, 單別, 單號, 項次, 品號, 數量, 預計歸還日, 備註);
        }

        /// <summary>重計借入單的單頭小計</summary>
        public static void SubtotalBorrowQty(string 公司別, string 單別, string 單號)
        {
            DAL_ERP.SubtotalBorrowQty(公司別, 單別, 單號);
        }

        /// <summary>取得製令單資料</summary>
        public static DataTable GetManufactureForm(string 單別, string 單號)
        {
            return DAL_ERP.GetManufactureForm(單別, 單號);
        }

        /// <summary>取得ERP帳號資料</summary>
        public static DataTable GetEmployee(string 工號)
        {
            return DAL_ERP.GetEmployee(工號);
        }
    }
}