﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR.Util;
using System.Linq;

namespace UHR
{
    public class BLL_Shipping
    {
        public BLL_Shipping()
        {

        }

        #region 出貨通知單
        /// <summary>取得出貨通知單列表</summary>
        public static DataTable GetShippingAdviseList(string 公司別, string 單號, string 客戶代號, string 狀態碼, string _sort, int _pageindex, int _pagesize, out int _recordcount)
        {
            _sort = (string.IsNullOrEmpty(_sort) ? "FormNo ASC" : _sort); //設定排序

            return DAL_Shipping.GetShippingAdviseList(公司別, 單號, 客戶代號, 狀態碼, _sort, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>修改出貨通知單</summary>
        public static void ModifyShippingAdvise(string 公司別, string 單號, string 客戶代號, string 客戶名稱, DateTime 預計出貨日, string 狀態碼)
        {
            DAL_Shipping.ModifyShippingAdvise(公司別, 單號, 客戶代號, 客戶名稱, 預計出貨日, 狀態碼);
        }

        /// <summary>更新出口單號</summary>
        public static void ModifyShippingSellingNumber(string 公司別, string 單號, string 出口單號)
        {
            DAL_Shipping.ModifyShippingSellingNumber(公司別,單號, 出口單號);
        }

        /// <summary>取得新的出貨通知單號</summary>
        public static string GetNewShippingAdviseNo(string 公司別)
        {
            return DAL_Shipping.GetNewShippingAdviseNo(公司別);
        }
        #endregion

        #region 出貨通知單明細
        /// <summary>取得出貨通知單明細列表</summary>
        public static DataTable GetShippingAdviseItemList(string 公司別, string 單號, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_Shipping.GetShippingAdviseItemList(公司別,單號, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得出貨通知單的可選未結案清單</summary>
        public static DataTable GetShippingAdviseBaseItemList(string 公司別, string 出貨通知單號, string 單別, string 單號, string 客戶代號, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_Shipping.GetShippingAdviseBaseItemList(公司別, 出貨通知單號, 單別, 單號, 客戶代號, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>刪除出貨通知單的明細資料</summary>
        public static bool DeleteShippingAdviseItem(string 公司別, string 出貨通知單號, string 單別, string 單號, string 項次, string 品號)
        {
            return DAL_Shipping.DeleteShippingAdviseItem(公司別, 出貨通知單號, 單別, 單號, 項次, 品號);
        }

        /// <summary>新增出貨通知單的明細資料</summary>
        public static bool InsertShippingAdviseItem(string 公司別, string 出貨通知單號, string 客戶代號, string 來源單別, string 來源單號, string 來源項次, int 數量)
        {
            return DAL_Shipping.InsertShippingAdviseItem(公司別,出貨通知單號, 客戶代號, 來源單別, 來源單號, 來源項次, 數量);
        }

        /// <summary>匯出出貨通知單</summary>
        public static DataTable ExportShippingAdvise(string 公司別, string 單號)
        {
            return DAL_Shipping.ExportShippingAdvise(公司別, 單號);
        }

        /// <summary>修改出貨原因備註</summary>
        public static void ModifyRemark(string 公司別, string 單別, string 單號, string 項次, string 備註)
        {
            DAL_Shipping.ModifyRemark(公司別,單別, 單號, 項次, 備註);
        }
        #endregion

        #region 箱號
        /// <summary>取得對應單號的箱號資料</summary>
        public static DataTable GetCartonItem(string 公司別, string 單號, string 箱號, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_Shipping.GetCartonItem(公司別, 單號, 箱號, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>新增箱號資料</summary>
        public static int InsertCartonItem(string 公司別, string 單號,string 棧板號, string 箱號, string WM, string GW, string NW)
        {
            return DAL_Shipping.InsertCartonItem(公司別, 單號, 棧板號, 箱號, WM, GW, NW);
        }

        /// <summary>修改箱號資料</summary>
        public static void EditCartonItem(string 公司別, string 單號, string 棧板號, string 箱號, string WM, string GW, string NW)
        {

            DAL_Shipping.EditCartonItem(公司別, 單號, 棧板號, 箱號, WM, GW, NW);
        }

        /// <summary>刪除對應單號的箱號資料</summary>
        public static void DelCartonItem(string 公司別, string 單號, string 箱號)
        {
            DAL_Shipping.DelCartonItem(公司別, 單號, 箱號);
        }

        /// <summary>複製箱號資料</summary>
        public static void CopyCatonItem(string 公司別, string 單號, string 箱號)
        {
            DAL_Shipping.CopyCatonItem(公司別, 單號, 箱號);
        }
        #endregion

        #region PackingList
        /// <summary>取得Packing List包裝來源</summary>
        public static DataTable GetPackingSource(string 公司別, string 單號, string 箱號, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_Shipping.GetPackingSource(公司別, 單號, 箱號, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得Packing List項目</summary>
        public static DataTable GetPackingItems(string 公司別, string 單號, string 箱號)
        {
            return DAL_Shipping.GetPackingItems(公司別, 單號, 箱號);
        }

        /// <summary>新增Packing的明細資料</summary>
        public static bool InsertPackingItem(string 公司別, string 單號, string 類型, string 箱號, string 來源單別, string 來源單號, string 來源項次, string 品號, string 數量)
        {
            return DAL_Shipping.InsertPackingItem(公司別, 單號, 類型, 箱號, 來源單別, 來源單號, 來源項次, 品號, 數量);
        }

        /// <summary>刪除Packing的明細資料</summary>
        public static bool DeletePackingItem(string 主鍵, string 公司別, string 單號, string 箱號)
        {
            return DAL_Shipping.DeletePackingItem(主鍵, 公司別, 單號, 箱號);
        }

        /// <summary>取得PackingList的報表資料</summary>
        public static DataSet GetPackingListFormData(string 公司別, string 單號, string 替代公司別, string 替代客戶代號)
        {
            DataSet ds = DAL_Shipping.GetPackingListFormData(公司別, 單號, 替代公司別, 替代客戶代號);
            DataTable dtHead = ds.Tables["單頭"];
            DataTable dtBody = ds.Tables["單身"];

            if (dtHead.Rows.Count > 0)
            {
                DataRow row = dtHead.Rows[0];

                row["TotalQty"] = (from r in dtBody.AsEnumerable() select r.Field<int?>("Qty")).Sum();

                //過濾重覆的箱資料
                var result = (from r in dtBody.AsEnumerable()
                              select new { CartonNo = r.Field<int>("CartonNo"), GW = r.Field<double>("G.W"), NW = r.Field<double>("N.W") }).Distinct();

                row["TotalCarton"] = (from r in result select r.CartonNo).Count();
                row["TotalGW"] = (from r in result select r.GW).Sum().ToString("0.0");
                row["TotalNW"] = (from r in result select r.NW).Sum().ToString("0.0");
            }

            return ds;
        }
        #endregion

        /// <summary>取得指定的ERP來源單據資料</summary>
        public static DataTable GetSellingFormData(string 公司別, string 單別單號)
        {
            return DAL_Shipping.GetSellingFormData(公司別,單別單號);
        }
    }
}