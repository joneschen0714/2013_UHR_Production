﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace UHR
{
    public class BLL_UHRWeb
    {
        public BLL_UHRWeb()
        {

        }

        #region Brand

        /// <summary>取得所有Brand內容(分頁)</summary>
        public static DataTable GetAllBrand(string OEMLampModule, string OEMMarking, int _pageindex, int _pagesize, out int _recordcount)
        {
            if (OEMLampModule != null)
                OEMLampModule = OEMLampModule.Replace("-", "").Replace(" ", "");

            return DAL_UHRWeb.GetAllBrand(OEMLampModule, OEMMarking, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得指定的Brand內容</summary>
        public static DataRow GetBrandData(object _id)
        {
            return DAL_UHRWeb.GetBrandData(_id);
        }

        /// <summary>新增&修改Brand內容</summary>
        public static void ModifyBrand(object ID, object Brand, object ImgSrc)
        {
            DAL_UHRWeb.ModifyBrand(ID, Brand, ImgSrc);
        }
        #endregion

        #region UHR Lamp Module

        /// <summary>取得所有LampModule資料(分頁)</summary>
        public static DataTable GetLampModuleList(string ID, string LampModule, string LM_Status, string BareLamp, string BL_Status, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetLampModuleList(ID, LampModule, LM_Status, BareLamp, BL_Status, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得對應的UHR_LMID</summary>
        public static string GetUhrLMID(string LampModule)
        {
            return DAL_UHRWeb.GetUhrLMID(LampModule);
        }

        /// <summary>取得圖片附件資料</summary>
        public static DataTable GetAttachment(string UHR_LMID, string LampModule, string Status)
        {
            return DAL_UHRWeb.GetAttachment(UHR_LMID, LampModule, Status);
        }

        /// <summary>刪除指定的UHRLampModule</summary>
        public static void DeleteUHRLampModule(string ID, ref bool Result, ref string Message)
        {
            DAL_UHRWeb.DeleteUHRLampModule(ID, ref Result, ref Message);
        }

        #endregion

        #region Projector

        /// <summary>取得所有Projector資料(分頁)</summary>
        public static DataTable GetProjectorList(string ID, string BrandID, string Projector, string UHR_LM, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetProjectorList(ID, BrandID, Projector, UHR_LM, _pageindex, _pagesize, out _recordcount);
        }

        #endregion

        #region Product

        /// <summary>新增或修改OEM Product資料</summary>
        public static void ModifyOEMProductList(DataTable dt, out bool Result, out string Message)
        {
            DAL_UHRWeb.ModifyOEMProductList(dt, out Result, out Message);
        }

        /// <summary>新增或修改UHR Product資料</summary>
        public static void ModifyUHRProductList(DataTable dt, out bool Result, out string Message)
        {
            DAL_UHRWeb.ModifyUHRProductList(dt, out Result, out Message);
        }

        /// <summary>新增或修改UHR Attachment資料</summary>
        public static void ModifyUHRAttachment(DataTable dt, out bool Result, out string Message)
        {
            DAL_UHRWeb.ModifyUHRAttachment(dt, out Result, out Message);
        }

        /// <summary>取得相關OEM Lamp Module</summary>
        public static DataTable GetRelatedOEMLampModule(string UHR_LMID)
        {
            return DAL_UHRWeb.GetRelatedOEMLampModule(UHR_LMID);
        }

        #endregion

        #region OEM Lamp Module

        /// <summary>取得所有OEM Lamp Module資料(分頁)</summary>
        public static DataTable GetOEMLampModuleList(string ID, string BrandID, string OEMLampModule, string Marking, int _pageindex, int _pagesize, out int _recordcount)
        {
            if (OEMLampModule != null)
                OEMLampModule = OEMLampModule.Replace("-", "").Replace(" ", "");

            return DAL_UHRWeb.GetOEMLampModuleList(ID, BrandID, OEMLampModule, Marking, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>新增或修改OEM Lamp Module</summary>
        public static bool ModifyOEMLampModule(string ID, string Brand, string OEMLampModule, string Marking, ref string Message)
        {
            //驗証
            if (OEMLampModule.Trim() == "")
            {
                Message = "原廠燈模組不可空白!";
                return false;
            }

            bool bResult = DAL_UHRWeb.ModifyOEMLampModule(ID, Brand, OEMLampModule, Marking, ref Message);

            if (!bResult)
                Message = string.Format("值：{0} 作業錯誤!", OEMLampModule);

            return bResult;
        }

        #endregion

        #region News

        /// <summary>取得所有News資料(分頁)</summary>
        public static DataTable GetNewsList(string strLang, string strType, string strTitle, string strEffectiveDate, string strExpiryDate, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetNewsList(strLang, strType, strTitle, strEffectiveDate, strExpiryDate, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得News內容</summary>
        public static DataRow GetNewsDetail(string ID)
        {
            return DAL_UHRWeb.GetNewsDetail(ID);
        }

        /// <summary>新增或修改News內容</summary>
        public static void ModifyNews(string ID, string Lang, string Type, string Title, string Description, string Content, string SlideContent, string TimeSpan, string EffectiveDate, string ExpiryDate)
        {
            DAL_UHRWeb.ModifyNews(ID, Lang, Type, Title, Description, Content, SlideContent, TimeSpan, EffectiveDate, ExpiryDate);
        }

        #endregion

        #region StaticPage

        /// <summary>取得所有靜態頁面資料</summary>
        public static DataTable GetStaticPageList(string Lang, string Type)
        {
            return DAL_UHRWeb.GetStaticPageList(Lang, Type);
        }

        /// <summary>修改靜態頁面內容</summary>
        public static void ModifyStaticPage(string Lang, string Type, string Content)
        {
            DAL_UHRWeb.ModifyStaticPage(Lang, Type, Content);
        }

        #endregion

        #region Catalog
        /// <summary>取得所有Catalog清單</summary>
        public static DataTable GetCatalogList(int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetCatalogList(_pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得指定的Catalog資料</summary>
        public static DataRow GetCatalogData(string _id)
        {
            return DAL_UHRWeb.GetCatalogData(_id);
        }

        /// <summary>新增 & 修改Catalog資料</summary>
        public static bool ModifyCatalog(string _id, string _name, string _effectivedate, string _expirydate, string _showinlist, string _description, out string Message)
        {
            return DAL_UHRWeb.ModifyCatalog(_id, _name, _effectivedate, _expirydate, _showinlist, _description, out Message);
        }

        /// <summary>取得指定Catalog的Item資料</summary>
        public static DataTable GetCatalogItem(string _catalogid)
        {
            return DAL_UHRWeb.GetCatalogItem(_catalogid);
        }

        /// <summary>批次修改Catalog下的Item</summary>
        public static void ModifyCatalogItem(string _catalogid, DataTable _dt)
        {
            DAL_UHRWeb.ModifyCatalogItem(_catalogid, _dt);
        }

        /// <summary>更新New Product的Item</summary>
        public static void UpdateNewProduct(string UHR_LM)
        {
            DAL_UHRWeb.UpdateNewProduct(UHR_LM);
        }
        #endregion

        #region FAQ

        /// <summary>取得所有FAQ資料(分頁)</summary>
        public static DataTable GetFAQList(string Type, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetFAQList(Type, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得指定的FAQ內容</summary>
        public static DataTable GetFAQDetail(string ID)
        {
            return DAL_UHRWeb.GetFAQDetail(ID);
        }

        /// <summary>回覆FAQ問題</summary>
        public static void ReplyFAQ(string c_ID, string MemberID, string Subject, string ReplyContent)
        {
            DAL_UHRWeb.ReplyFAQ(c_ID, MemberID, Subject, ReplyContent);
        }

        #endregion

        #region Member

        /// <summary>取得Member資料</summary>
        public static DataTable GetMemberInfo(string ID, string Name, string Email, string Company, string Country, string ERPCompany, string ERPCustomCode, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetMemberInfo(ID, Name, Email, Company, Country, ERPCompany, ERPCustomCode, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>修改Member資料</summary>
        public static void ModifyMemberInfo(string ID, string Level, string ContactSalesMail, string Currency, string ERP_Company, string ERP_CustomCode, string Enabled)
        {
            DAL_UHRWeb.ModifyMemberInfo(ID, Level, ContactSalesMail, Currency, ERP_Company, ERP_CustomCode, Enabled);
        }

        /// <summary>取得Country資料</summary>
        public static DataTable GetCountry(string Code)
        {
            return DAL_UHRWeb.GetCountry(Code);
        }

        #endregion

        #region MailLog

        /// <summary>取得所有廣告信發送記錄</summary>
        public static DataTable GetMailLogList(string Subject, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetMailLogList(Subject, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得指定的廣告信發送對象記錄</summary>
        public static DataTable GetMailLogItem(string ID)
        {
            return DAL_UHRWeb.GetMailLogItem(ID);
        }

        /// <summary>取得指定的廣告信資料</summary>
        public static DataRow GetMailLogData(string ID)
        {
            return DAL_UHRWeb.GetMailLogData(ID);
        }

        /// <summary>新增或修改廣告信資料</summary>
        public static void ModifyMailLog(string ID, string Subject, string Content, string EmailList, out bool Result, out string Message)
        {
            DAL_UHRWeb.ModifyMailLog(ID, Subject, Content, EmailList, out Result, out Message);
        }
        #endregion

        #region Price

        /// <summary>新增會員的價格定義表</summary>
        public static void InsertMemberPriceTitle(string MemberID, string Title, string Description, string OrderType, string StartQty, string EndQty, string Sort, ref bool Result, ref string Message)
        {
            DAL_UHRWeb.InsertMemberPriceTitle(MemberID, Title, Description, OrderType, StartQty, EndQty, Sort, ref Result, ref Message);
            if (Result) Message = "作業成功!";
        }

        /// <summary>修改會員的價格定義表</summary>
        public static void UpdateMemberPriceTitle(string ID, string MemberID, string Description, string OrderType, string StartQty, string EndQty, string Sort, ref bool Result, ref string Message)
        {
            DAL_UHRWeb.UpdateMemberPriceTitle(ID, MemberID, Description, OrderType, StartQty, EndQty, Sort, ref Result, ref Message);
            if (Result) Message = "作業成功!";
        }

        /// <summary>刪除會員的價格定義表</summary>
        public static void DeleteMemberPriceTitle(string MemberID, string Title, ref bool Result, ref string Message)
        {
            DAL_UHRWeb.DeleteMemberPriceTitle(MemberID, Title, ref Result, ref Message);
        }

        /// <summary>匯出會員的價格定義表</summary>
        public static DataTable GetMemberPriceTable(string ID, string MemberID, string Title)
        {
            return DAL_UHRWeb.GetMemberPriceTable(ID, MemberID, Title);
        }

        /// <summary>匯出會員的價格表</summary>
        public static DataTable GetMemberPriceList(string MemberID)
        {
            //取得價格定義表
            DataTable dtPriceTable = DAL_UHRWeb.GetMemberPriceTable(null, MemberID, null);

            //建立橫向定義表
            DataTable dtPriceTable1 = new DataTable();
            dtPriceTable1.Columns.Add("ProductName");
            foreach (DataRow row in dtPriceTable.Rows)
            {
                dtPriceTable1.Columns.Add(row["Title"].ToString());
            }

            //取得價格表
            DataTable dtPriceList = DAL_UHRWeb.GetMemberPriceList(MemberID);
            foreach (DataRow row in dtPriceList.Rows)
            {
                //建立新資料列
                DataRow rowPrice = dtPriceTable1.NewRow();
                rowPrice["ProductName"] = row["ProductName"].ToString();

                //是否有XML項目
                string strXml = row["PriceXml"].ToString();
                if (!string.IsNullOrEmpty(strXml))
                {
                    //建立Xml物件
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(strXml);
                    XmlNodeList nodeList = xmlDoc.SelectNodes("//Item");

                    //依序讀取節點值
                    foreach (XmlNode node in nodeList)
                    {
                        string strTitle = node.Attributes["Title"].Value;
                        string strPrice = node.InnerText;

                        rowPrice[strTitle] = strPrice; //找尋對應的欄位名稱，更新價格
                    }
                }

                dtPriceTable1.Rows.Add(rowPrice); //增加資料列
            }

            return dtPriceTable1;
        }

        /// <summary>匯入會員的價格表</summary>
        public static void ImportMemberPriceList(string MemberID, DataTable dt, ref bool Result, ref string Message)
        {
            //檢查Title是否存在
            DataTable dtColumnTable = GetMemberPriceTable(null, MemberID, null);
            foreach (DataColumn col in dt.Columns)
                if (col.ColumnName != "ProductName")
                    if (!dt.Columns.Contains(col.ColumnName))
                    {
                        Result = false;
                        Message = string.Format("欄位名稱 {0} 錯誤，作業中斷!", col.ColumnName);
                        break;
                    }

            if (Result)
                DAL_UHRWeb.ImportMemberPriceList(MemberID, dt, ref Result, ref Message);
        }

        /// <summary>複製會員的價格表</summary>
        public static void CopyMemberPrice(string MainID, string EditIDList, ref bool Result, ref string Message)
        {
            MainID = MainID.Remove(MainID.IndexOf(" "));
            string[] EditIDArray = EditIDList.Replace(Environment.NewLine, ";").Split(';');

            string IDList = "";
            foreach (string EditID in EditIDArray)
            {
                if (EditID != "")
                {
                    string ID = EditID.Remove(EditID.IndexOf(" "));
                    if (ID != MainID)
                    {
                        IDList += ID + ";";
                    }
                }
            }

            DAL_UHRWeb.CopyMemberPrice(MainID, IDList.Trim(';'), ref Result, ref Message);
        }

        #endregion

        #region Log

        /// <summary>匯出瀏覽記錄Log</summary>
        public static DataTable GetLog(string Type, string StartDate, string EndDate)
        {
            return DAL_UHRWeb.GetLog(Type, StartDate, EndDate);
        }

        #endregion

        #region 訂單

        /// <summary>取得訂單記錄</summary>
        public static DataTable GetOrderHistory(string ID, string OrderNo, string Email, string ERPCompany, string ERPCustomCode, string StartDate, string EndDate, string Company, string Name, string DataType, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL_UHRWeb.GetOrderHistory(ID, OrderNo, Email, ERPCompany, ERPCustomCode, StartDate, EndDate, Company, Name, DataType, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得訂單單身項目歷史記錄</summary>
        public static DataTable GetOrderItemList(string OrderID)
        {
            return DAL_UHRWeb.GetOrderItemList(OrderID);
        }

        /// <summary>取得OrderNumber對應ERP的報價單號</summary>
        public static DataTable GetInquiryNumberInERP(string OrderNumber)
        {
            return DAL_UHRWeb.GetInquiryNumberInERP(OrderNumber);
        }

        /// <summary>取消訂單</summary>
        public static void CancelOrder(string OrderNumber)
        {
            DAL_UHRWeb.CancelOrder(OrderNumber);
        }

        /// <summary>取得訂單匯出明細</summary>
        public static DataTable GetOrderExportDetail(string OrderType, string StartDate, string EndDate)
        {
            return DAL_UHRWeb.GetOrderExportDetail(OrderType, StartDate, EndDate);
        }

        #endregion

        /// <summary>取得Config定義表的資料</summary>
        public static DataTable GetConfigData(string Type)
        {
            return DAL_UHRWeb.GetConfigData(Type);
        }
    }
}