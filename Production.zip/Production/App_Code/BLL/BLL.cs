﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class BLL
    {
        public BLL()
        {

        }

        /// <summary>取得使用者相關資料</summary>
        public static DataRow GetUserInfo(string _id, string _account, string _email)
        {
            return DAL.GetUserInfo(_id, _account, _email);
        }

        /// <summary>取得使用者群組相關資料</summary>
        public static DataRow GetGroupInfo(string _groupnum)
        {
            return DAL.GetGroupInfo(_groupnum);
        }

        /// <summary>取得選單相關資料</summary>
        public static DataTable GetMenuList(string ParentNo, string Enabled)
        {
            return DAL.GetMenuList(ParentNo, Enabled);
        }

        /// <summary>取得單一選單相關資料</summary>
        public static DataRow GetMenuInfo(string _menuno, string _menulink, string _type)
        {
            return DAL.GetMenuInfo(_menuno, _menulink, _type);
        }

        /// <summary>取得TabMenu選單資料</summary>
        public static DataTable GetTabMenuInfo(string _groupname)
        {
            return DAL.GetTabMenuInfo(_groupname);
        }
    }
}