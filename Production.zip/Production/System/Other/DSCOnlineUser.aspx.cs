﻿using System;
using System.IO;
using System.Collections;
using System.Data;
using System.Linq;
using UHR;
using UHR.DataBase;
using UHR.Util;

public partial class DSCOnlineUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        GetOnlineEFUser();
        GetOnlineERPUser();
    }

    private void GetOnlineEFUser()
    {
        //物件初始化
        using (DataBase db = new DataBase("server=10.1.0.64;	database=EFNETSYS;	uid=erp;	pwd=manager1;"))
        {
            db.StrSQL = "SELECT CASE MA002 WHEN NULL THEN ZZ001 ELSE MA002 END [UserName], ZZ002 [OnlineTime] " +
                        "FROM CRMZZ " +
                        "LEFT OUTER JOIN DSCMA ON MA001=ZZ001 " +
                        "ORDER BY ZZ002";
            DataTable dt = db.ExecuteDataTable();

            Label1.Text = dt.Rows.Count.ToString();

            //循序顯示人員名單
            foreach (DataRow row in dt.Rows)
            {
                liItemEF.Text += string.Format("<tr><td>{0}</td><td>{1}</td></tr>", DateTime.Parse(row["OnlineTime"].ToString()).ToString("HH:mm:ss"), row["UserName"]);
            }
        }
    }

    private void GetOnlineERPUser()
    {
        //路徑及檔名
        string strToday = DateTime.Now.ToString("yyyyMMdd");
        string strFilePath = @"\\Erp\Conductor\Log\SysLog_" + strToday + ".Log";

        //判斷檔案是否存在
        FileInfo fi = new FileInfo(strFilePath);
        if (fi.Exists)
        {
            ArrayList al = new ArrayList();

            #region 循序寫入陣列
            using (FileStream fs = File.Open(strFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (StreamReader sr = new StreamReader(fs, System.Text.Encoding.Default))
                {
                    while (!sr.EndOfStream)
                    {
                        al.Add(sr.ReadLine());
                    }
                }
            }
            #endregion

            #region 循序讀取最後20筆資料
            ArrayList userlist = new ArrayList();
            int i = 1, j = 0;
            while (true)
            {
                if (j <= 19 && i <= al.Count)
                {
                    string[] strItem = al[al.Count - i].ToString().Split('\t'); //切割字串
                    string strStatus = strItem[0]; //狀態
                    string strTime = strItem[3]; //登入時間
                    string strUserCode = strItem[5]; //工號

                    if (strStatus == "登入")
                    {
                        //判斷工號是否已存在
                        var result = from string[] r in userlist where r[1] == strUserCode select r;
                        if (result.Count() == 0)
                        {
                            //取得員工資料
                            DataTable dtUser = BLL_ERP.GetEmployee(strUserCode);
                            DataRow row = dtUser.Rows[0];

                            userlist.Add(new string[] { DateTime.Parse(strTime).ToString("HH:mm:ss"), strUserCode, row["姓名"].ToString() }); //增加人員名單
                            j++; //累加j
                        }
                    }
                    i++; //累加i
                }
                else
                {
                    break; //跳出迴圈
                }
            }
            #endregion

            //循序顯示userlist人員名單 (依時間排序)
            foreach (string[] user in (from string[] r in userlist orderby r[0] select r))
            {
                liItemERP.Text += string.Format("<tr><td>{0}</td><td>{1}</td></tr>", user[0], user[2]);
            }
        }
    }
}
