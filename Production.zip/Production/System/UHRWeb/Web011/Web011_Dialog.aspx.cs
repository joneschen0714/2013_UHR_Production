﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using UHR;
using UHR.Util;

public partial class Web011_Dialog : UHR.BasePage.BasePage
{
    //全域變數
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入ERP公司別
        ddlERPCompany.DataSource = new CompanyCollection();
        ddlERPCompany.DataBind();

        //取得資料來源
        int recordCount;
        DataTable dt = BLL_UHRWeb.GetMemberInfo(M_ID, null, null, null, null, null, null, 1, 1, out recordCount);
        DataRow row = dt.Rows[0];

        //設定值
        lblName.Text = row["Name"].ToString();
        lblSex.Text = (row["Sex"].ToString() == "M" ? "Male" : "Female");
        lblEmail.Text = row["Email"].ToString();
        lblTel.Text = row["Tel"].ToString();
        lblCountry.Text = row["CountryName"].ToString();
        lblAddress.Text = row["Address"].ToString();
        lblCompany.Text = row["Company"].ToString();
        rblLevel.SelectedValue = row["Level"].ToString();
        txtContactSaleMail.Text = row["ContactSalesMail"].ToString();
        txtCurrency.Text = row["Currency"].ToString();
        ddlERPCompany.SelectedValue = row["ERP_Company"].ToString();
        txtERPCustomCode.Text = row["ERP_CustomCode"].ToString();
        rblEnabled.SelectedValue = row["Enabled"].ToString();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //變數
            string strLevel = rblLevel.SelectedValue;
            string strContactMail = txtContactSaleMail.Text.Trim();
            string strCurrency = txtCurrency.Text.Trim();
            string strERP_Company = ddlERPCompany.SelectedValue;
            string strERP_CustomCode = txtERPCustomCode.Text.Trim();
            string strEnabled = rblEnabled.SelectedValue;

            //修改會員資料
            BLL_UHRWeb.ModifyMemberInfo(M_ID, strLevel, strContactMail, strCurrency, strERP_Company, strERP_CustomCode, strEnabled);

            //顯示訊息
            liScript.Text = "<script type='text/javascript'>" +
                                "$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();" +
                            "</script>";
        }
    }
}