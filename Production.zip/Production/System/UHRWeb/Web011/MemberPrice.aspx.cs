﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Xml;
using UHR;
using UHR.Util;

public partial class MemberPrice : UHR.BasePage.BasePage
{
    //全域變數
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id");

        if (!IsPostBack)
        {
            gv_GridDataBind(sender, e);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得資料來源
        DataTable dtList = BLL_UHRWeb.GetMemberPriceTable(null, M_ID, null);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("標題", "Title", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("類別", "Type", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("開始數量", "StartQty", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("結束數量", "EndQty", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("排序", "Sort", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = dtList.Rows.Count;
        gv.GridView.DataSource = dtList;
        gv.DataBind();

        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<img src='{0}' title='Add' style='cursor:pointer' align='absmiddle' onclick=\"ModifyTitle('')\" />　",
                                        ResolveClientUrl("~/images/ToolBar/add.png"));
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = rowView["ID"].ToString();
            string strTitle = rowView["Title"].ToString();

            //管理
            cellManage.Text = "<image src='../../../images/ToolBar/Edit.gif' title='編輯' style='cursor:pointer' onclick=\"ModifyTitle('" + strID + "')\" /> " +
                              "<image src='../../../images/ToolBar/Del.png' title='刪除' style='cursor:pointer' onclick=\"DeleteTitle('" + strTitle + "')\" />";
        }
    }

    protected void btnModify_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 1;

        ddlOrderType.DataSource = BLL_UHRWeb.GetConfigData("OrderType");
        ddlOrderType.DataBind();
        ddlOrderType.Items.Insert(0, new ListItem("--請選擇Type--", ""));

        //判斷新增或修改
        string strID = hiddenVal.Value;
        if (string.IsNullOrEmpty(strID))
        {
            txtTitle.Text = "";
            txtDescription.Text = "";
            ddlOrderType.SelectedValue = "";
            txtStartQty.Text = "";
            txtEndQty.Text = "";
            txtSort.Text = "";
            txtTitle.Enabled = true;
        }
        else
        {
            DataTable dtTitle = BLL_UHRWeb.GetMemberPriceTable(strID, null, null);
            DataRow rowTitle = dtTitle.Rows[0];

            txtTitle.Text = rowTitle["Title"].ToString();
            txtDescription.Text = rowTitle["Description"].ToString();
            ddlOrderType.SelectedValue = rowTitle["Type"].ToString();
            txtStartQty.Text = rowTitle["StartQty"].ToString();
            txtEndQty.Text = rowTitle["EndQty"].ToString();
            txtSort.Text = rowTitle["Sort"].ToString();
            txtTitle.Enabled = false;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //變數
            string strID = hiddenVal.Value;
            string strTitle = txtTitle.Text.Trim();
            string strDesc = txtDescription.Text.Trim();
            string strOrderType = ddlOrderType.SelectedValue;
            string strStartQty = txtStartQty.Text.Trim();
            string strEndQty = txtEndQty.Text.Trim();
            string strSort = txtSort.Text.Trim();

            bool Result = false;
            string Message = "";

            //呼叫邏輯層
            if (strID == "")
                BLL_UHRWeb.InsertMemberPriceTitle(M_ID, strTitle, strDesc, strOrderType, strStartQty, strEndQty, strSort, ref Result, ref Message);
            else
                BLL_UHRWeb.UpdateMemberPriceTitle(strID, M_ID, strDesc, strOrderType, strStartQty, strEndQty, strSort, ref Result, ref Message);

            if (Result)
            {
                mv.ActiveViewIndex = 0;
                gv_GridDataBind(sender, e);
            }
            else
                MessageInfo.ShowMessage(Result, Message);
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 0;
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string strTitle = hiddenVal.Value;
        bool Result = false;
        string Message = "";

        BLL_UHRWeb.DeleteMemberPriceTitle(M_ID, strTitle, ref Result, ref Message);

        if (Result)
        {
            gv_GridDataBind(sender, e);
        }
        else
            MessageInfo.ShowMessage(Result, Message);
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        DataTable dtPrice = BLL_UHRWeb.GetMemberPriceList(M_ID);

        Tool.DataTableToCSV(dtPrice, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (!file.HasFile) { MessageInfo.ShowMessage(false, "請選擇匯入之檔案!"); return; }

        //上傳檔案
        string strFileName = "MemberPriceList.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        //取得上傳檔案內容
        DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName);

        //呼叫邏輯層
        string Message = ""; bool Result = true;
        BLL_UHRWeb.ImportMemberPriceList(M_ID, dtCSV, ref Result, ref Message);

        //結果處理
        MessageInfo.ShowMessage(Result, Message);
    }
}