﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web011 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入國家清單
        DataTable dtCountry = BLL_UHRWeb.GetCountry(null);
        ddlCountry.DataSource = dtCountry;
        ddlCountry.DataBind();
        ddlCountry.Items.Insert(0, new ListItem("-- 請選擇國家 --", ""));

        //載入ERP公司別
        ddlERPCompany.DataSource = new CompanyCollection();
        ddlERPCompany.DataBind();

        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢參數
        string strName = txtName.Text.Trim();
        string strCompany = txtCompany.Text.Trim();
        string strCountry = ddlCountry.SelectedValue;
        string strEmail = txtEmail.Text.Trim();
        string strERPCompany = ddlERPCompany.SelectedValue;
        string strERPCustomCode = txtERPCustomCode.Text.Trim().ToUpper();

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetMemberInfo(null, strName, strEmail, strCompany, strCountry, strERPCompany, strERPCustomCode, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("姓名", "Name", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("性別", "Sex", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("國家", "CountryName", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("公司", "Company", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("等級", "Level", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("啟用碼", "Enabled", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtList;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
            TableCell cellSex = gv.GetTableCell(e.Row, "性別", false);
            TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = rowView["ID"].ToString();
            string strSex = rowView["Sex"].ToString();

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //性別
            cellSex.Text = (strSex == "M" ? "Male" : "Female");

            //管理
            cellManage.Text = "<input type='button' value='編輯' class='buttonStyle01s' onclick=\"Modify('" + strID + "')\" />" +
                              "<input type='button' value='價格表' class='buttonStyle01s' onclick=\"ModifyPrice('" + strID + "')\" />";
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //查詢參數
        string strName = txtName.Text.Trim();
        string strCompany = txtCompany.Text.Trim();
        string strCountry = ddlCountry.SelectedValue;
        string strERPCompany = ddlERPCompany.SelectedValue;
        string strERPCustomCode = txtERPCustomCode.Text.Trim().ToUpper();

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetMemberInfo(null, strName, null, strCompany, strCountry, strERPCompany, strERPCustomCode, 1, int.MaxValue, out recordCount);

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "Web011.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}