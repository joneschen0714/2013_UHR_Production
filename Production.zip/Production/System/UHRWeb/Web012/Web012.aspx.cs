﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web012 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入Type選單
        ddlType.DataSource = BLL_UHRWeb.GetConfigData("Log");
        ddlType.DataBind();
        ddlType.Items.Insert(0, new ListItem("--請選擇類別--", ""));
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //變數
            string strType = ddlType.SelectedValue;
            string strStartDate = txtStartDate.Text.Trim();
            string strEndDate = txtEndDate.Text.Trim();

            //驗証
            if (strStartDate == "" && strEndDate == "") { MessageInfo.ShowMessage(false, "日期區間不可空白"); return; }

            //取得資料來源
            DataTable dtList = BLL_UHRWeb.GetLog(strType, strStartDate, strEndDate); ;

            //檔案路徑設定
            string strPath = "/Temp/";
            string strFile = "ExportData.csv";
            string strFilePath = Server.MapPath("~" + strPath + strFile);

            Tool.DataTableToCSV(dtList, strFilePath);
            Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
        }
    }
}