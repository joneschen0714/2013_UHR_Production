﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web016 : UHR.BasePage.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        ddlOrderType.DataSource = BLL_UHRWeb.GetConfigData("OrderType");
        ddlOrderType.DataBind();
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //查詢參數
        string strOrderType = ddlOrderType.SelectedValue;
        string strStartDate = txtStartDate.Text.Trim();
        string strEndDate = txtEndDate.Text.Trim();

        DataTable dtList = BLL_UHRWeb.GetOrderExportDetail(strOrderType, strStartDate, strEndDate);

        //替代欄位名稱
        dtList.Columns["ERP_Company"].ColumnName = "ERP公司別";
        dtList.Columns["ERP_CustomCode"].ColumnName = "ERP客戶代號";
        dtList.Columns["Company"].ColumnName = "公司名";
        dtList.Columns["OrderNum"].ColumnName = "備註";
        dtList.Columns["Date"].ColumnName = "時間";
        dtList.Columns["ProductNo"].ColumnName = "品號";
        dtList.Columns["Quantity"].ColumnName = "數量";
        dtList.Columns["UnitPrice"].ColumnName = "單價";
        dtList.Columns["CustomPN"].ColumnName = "客戶品號";
        dtList.Columns["CustomDESC"].ColumnName = "客戶商品描述";

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}