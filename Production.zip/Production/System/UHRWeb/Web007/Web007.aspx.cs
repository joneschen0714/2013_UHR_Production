﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web007 : UHR.BasePage.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //設定上傳圖片路徑
        ftbContent.ImageGalleryUrl = ResolveClientUrl("~/aspnet_client/FreeTextBox/ftb.imagegallery.aspx?rif={0}&cif={0}");
        ftbContent.ImageGalleryPath = ConfigurationManager.AppSettings["OtherImgPath"];

        if (!IsPostBack)
        {
            ddlType.DataSource = BLL_UHRWeb.GetStaticPageList(null, null);
            ddlType.DataBind();
        }
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        string strLang = ddlLang.SelectedValue;
        string strType = ddlType.SelectedValue;

        DataTable dt = BLL_UHRWeb.GetStaticPageList(strLang, strType);
        if (dt.Rows.Count > 0)
        {
            palContent.Visible = true;

            DataRow row = dt.Rows[0];
            ftbContent.Text = row["Content"].ToString().Trim();
        }
        else
        {
            palContent.Visible = false;
            MessageInfo.ShowMessage(false, "無資料列!");
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string strLang = ddlLang.SelectedValue;
        string strType = ddlType.SelectedValue;
        string strContent = ftbContent.Text.Trim();

        BLL_UHRWeb.ModifyStaticPage(strLang, strType, strContent);

        MessageInfo.ShowMessage(true, "作業成功!");
    }
}