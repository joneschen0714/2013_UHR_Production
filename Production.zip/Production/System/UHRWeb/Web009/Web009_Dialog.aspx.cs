﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web009_Dialog : UHR.BasePage.BasePage
{
    private string M_ID, M_ReplyCount;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id"); //ID
        M_ReplyCount = Tool.CheckQueryString("replycount"); //ReplyCount

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        if (!string.IsNullOrEmpty(M_ID))
        {
            //取得FAQ內容
            DataTable dt = BLL_UHRWeb.GetFAQDetail(M_ID);
            DataRow rowMain = dt.Select("ID=" + M_ID)[0];

            //設定控制項值
            lblType.Text = rowMain["Type"].ToString();
            lblSubject.Text = rowMain["Subject"].ToString();
            lblContent.Text = rowMain["Contents"].ToString();

            //若有回覆則顯示
            if (M_ReplyCount != "0")
            {
                DataRow rowChild = dt.Select("c_ID=" + M_ID)[0];
                txtReplyContent.Text = rowChild["Contents"].ToString().Replace("<br />", System.Environment.NewLine);
                btnSubmit.Visible = false;
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //變數
        string strReplyContent = txtReplyContent.Text.Replace(System.Environment.NewLine, "<br />");
        string strSubject = "FW : " + lblSubject.Text.Trim();
        string strEmail = UHR.Authority.UserInfo.SessionState.Email;

        int recordCount;
        DataTable dtMember = BLL_UHRWeb.GetMemberInfo(null, null, strEmail, null, null, null, null, 1, 1, out recordCount); //取得會員資料
        if (dtMember.Rows.Count > 0)
        {
            DataRow rowMember = dtMember.Rows[0];
            string MemberID = rowMember["ID"].ToString(); //會員ID

            //呼叫邏輯層
            BLL_UHRWeb.ReplyFAQ(M_ID, MemberID, strSubject, strReplyContent);

            //關閉視窗，重整List
            SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(false, "網站不存在" + strEmail + "的會員資料，請先至網站註冊會員資料!");
        }
    }
}