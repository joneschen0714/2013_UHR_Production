﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web009 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        ddlType.DataSource = BLL_UHRWeb.GetConfigData("Q&A Type");
        ddlType.DataBind();
        ddlType.Items.Insert(0, new ListItem("--select type--", ""));

        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strType = ddlType.SelectedValue;

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetFAQList(strType, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("Item", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Country", "Country", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Company", "Company", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Name", "Name", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Type", "Type", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Subject", "Subject", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Reply", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("Manage", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataKeyNames = new string[] { "ID" }; //設定主鍵
        gv.GridView.DataSource = dtList;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellItem = gv.GetTableCell(e.Row, "Item", false);
            TableCell cellCountry = gv.GetTableCell(e.Row, "Country", false);
            TableCell cellCompany = gv.GetTableCell(e.Row, "Company", false);
            TableCell cellName = gv.GetTableCell(e.Row, "Name", false);
            TableCell cellType = gv.GetTableCell(e.Row, "Type", false);
            TableCell cellSubject = gv.GetTableCell(e.Row, "Subject", false);
            TableCell cellReply = gv.GetTableCell(e.Row, "Reply", false);
            TableCell cellManage = gv.GetTableCell(e.Row, "Manage", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = rowView["ID"].ToString();
            int iReplyCount = Convert.ToInt32(rowView["ReplyCount"]);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //是否回覆
            cellReply.Text = (iReplyCount > 0 ? "<img src='../../../images/select.png' />" : "&nbsp;");

            //管理區
            cellManage.Text = "<input type='button' value='Edit' class='buttonStyle01s' onclick=\"ModifyAction(" + strID + "," + iReplyCount + ")\" />";
        }
    }
}