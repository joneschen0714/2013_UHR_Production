﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web013 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Image1.Attributes.Add("onclick", "OpenWebMember('N', '" + txtKeyUser.ClientID + "')");
        Image2.Attributes.Add("onclick", "OpenWebMember('Y', '" + txtEditUser.ClientID + "')");
    }

    protected void btnCopy_Click(object sender, EventArgs e)
    {
        //變數
        string strID = txtKeyUser.Text;
        string strEditArray = txtEditUser.Text;

        //呼叫邏輯層
        bool Result = false; string Message = "";
        BLL_UHRWeb.CopyMemberPrice(strID, strEditArray, ref Result, ref Message);

        MessageInfo.ShowMessage(Result, Message);
    }
}