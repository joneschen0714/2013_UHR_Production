﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web015 : UHR.BasePage.BasePage
{
    private DataTable dtHead;

    protected void Page_Init(object sender, EventArgs e)
    {
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //變數
        string 公司別 = ddlCompany.SelectedValue;
        string 單別 = txtFormType.Text.Trim();
        string 單號 = txtFormNumber.Text.Trim();

        if (公司別 != "" && 單別 != "" && 單號 != "")
        {
            //取得資料來源
            int record;
            dtHead = BLL_ERP.GetQuotationHeadList(公司別, 單別, 單號, null, null, null, 1, 1, out record);

            if (dtHead.Rows.Count > 0)
            {
                //載入Repeater
                repList.DataSource = BLL_ERP.GetQuotationBodyList(公司別, 單別, 單號);
                repList.DataBind();
            }
        }
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Header)
        {
            //取得控制項
            Label lblCustom = (Label)e.Item.FindControl("lblCustom");

            //設定值
            lblCustom.Text = dtHead.Rows[0]["客戶全名"].ToString();
        }
        else if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源

            //取得控制項
            Label lblItemNo = (Label)e.Item.FindControl("lblItemNo");
            Label lblProductNo = (Label)e.Item.FindControl("lblProductNo");
            Label lblDescription = (Label)e.Item.FindControl("lblDescription");
            Label lblQty = (Label)e.Item.FindControl("lblQty");
            TextBox txtRemark = (TextBox)e.Item.FindControl("txtRemark");

            //設定值
            lblItemNo.Text = Convert.ToString(rowView["項次"]);
            lblProductNo.Text = Convert.ToString(rowView["品號"]);
            lblDescription.Text = Convert.ToString(rowView["客戶商品描述"]);
            lblQty.Text = Convert.ToInt32(rowView["數量"]).ToString();
            txtRemark.Text = Convert.ToString(rowView["備註"]);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //變數
        string 公司別 = ddlCompany.SelectedValue;
        string 單別 = txtFormType.Text.Trim();
        string 單號 = txtFormNumber.Text.Trim();

        foreach (RepeaterItem i in repList.Items)
        {
            Label no = (Label)i.FindControl("lblItemNo");
            TextBox remark = (TextBox)i.FindControl("txtRemark");

            BLL_ERP.EditQuotationBodyRemark(公司別, 單別, 單號, no.Text, remark.Text);
        }

        MessageInfo.ShowMessage(true, "作業成功!");
    }
}