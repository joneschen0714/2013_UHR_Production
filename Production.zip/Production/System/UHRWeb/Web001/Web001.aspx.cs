﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web001 : UHR.BasePage.BasePage
{
    //全域變數
    private string BrandImgPath = ConfigurationManager.AppSettings["BrandImgPath"];

    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gv_GridDataBind(sender, e);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //變數
        string strOEMLampModule = txtOEM_LM.Text;
        string strOEMMarking = txtMarking.Text;

        //取得資料來源
        int recordCount;
        DataTable dtBrandList = BLL_UHRWeb.GetAllBrand(strOEMLampModule, strOEMMarking, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("廠牌", "Brand", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("管理", "", false, 200, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtBrandList;
        gv.DataBind();

        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<img src='{0}' title='Add' style='cursor:pointer' align='absmiddle' onclick=\"ModifyAction('')\" />　",
                                        ResolveClientUrl("~/images/ToolBar/add.png"));
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            cellManage.Text = "<input type='button' value='編輯' class='buttonStyle01s' onclick=\"ModifyAction('" + strID + "')\" />" +
                              "<input type='button' value='模組' class='buttonStyle01s' onclick=\"ModifyLampModule('" + strID + "','" + txtOEM_LM.Text + "','" + txtMarking.Text + "')\" />";
        }
    }

    protected void btnModify_Click(object sender, EventArgs e)
    {
        //切換區域
        palModify.Visible = true;
        palList.Visible = false;

        //取得ID
        string strID = txtValue.Text;
        if (strID != "")
        {
            DataRow row = BLL_UHRWeb.GetBrandData(strID); //取得欲編輯的資料來源

            txtBrand.Text = Convert.ToString(row["Brand"]); //廠牌

            //設定現有圖片連結
            string ImgSrc = Convert.ToString(row["ImgSrc"]).Trim();
            if (ImgSrc != "")
            {
                linkImage.Text = ImgSrc;
                linkImage.NavigateUrl = (BrandImgPath + ImgSrc);
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //刪除原有圖檔
            if (linkImage.NavigateUrl != "")
            {
                File.Delete(Server.MapPath(linkImage.NavigateUrl));
            }

            //變數
            string strID = txtValue.Text;
            string strBrand = txtBrand.Text.Trim();
            string strImgName = fileImage.FileName;
            string strImgPath = BrandImgPath + strImgName;

            fileImage.SaveAs(Server.MapPath(strImgPath)); //儲存圖檔

            BLL_UHRWeb.ModifyBrand(strID, strBrand, strImgName); //呼叫邏輯層

            btnCancel_Click(sender, e); //切換區域
            gv_GridDataBind(sender, e); //List重整

            MessageInfo.ShowMessage(true, "Process Finish.");
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //清空控制項
        txtBrand.Text = "";
        linkImage.Text = "";
        linkImage.NavigateUrl = "";

        //切換區域
        palModify.Visible = false;
        palList.Visible = true;
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (file.HasFile)
        {
            //上傳檔案
            string strFileName = "Web001.csv";
            string strPath = Server.MapPath("~/Temp/");
            file.SaveAs(strPath + strFileName);

            DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName); //取得上傳檔案內容

            //逐筆寫入與更新
            string strMessageList = "";
            foreach (DataRow row in dtCSV.Rows)
            {
                //變數
                string strID = row["ID"].ToString();
                string strBrand = row["Brand"].ToString();
                string strOEMLampModule = row["OEMLampModule"].ToString();
                string strMarking = row["Marking"].ToString();

                //呼叫邏輯層
                string strMessage = "";
                bool bResult = BLL_UHRWeb.ModifyOEMLampModule(strID, strBrand, strOEMLampModule, strMarking, ref strMessage);

                if (!bResult) strMessageList += strMessage + "<br/>"; //累加錯誤訊息
            }

            //處理結果
            if (strMessageList == "")
            {
                MessageInfo.ShowMessage(true, "作業成功!");
                gv_GridDataBind(sender, e); //載入清單
            }
            else
                MessageInfo.ShowMessage(false, strMessageList);
        }
        else
        {
            MessageInfo.ShowMessage(false, "請選擇欲匯入的檔案!");
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetOEMLampModuleList(null, null, txtOEM_LM.Text, txtMarking.Text, 1, int.MaxValue, out recordCount);

        //移除不必要欄位
        dtList.Columns.Remove("RowNum");
        dtList.Columns["OEM_LM"].ColumnName = "OEMLampModule";

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}