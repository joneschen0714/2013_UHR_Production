﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class OEMLampModule_Dialog : UHR.BasePage.BasePage
{
    private string M_BrandID, M_OEMLampModule, M_OEMMarking;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_BrandID = Tool.CheckQueryString("BrandID");
        M_OEMLampModule = Tool.CheckQueryString("OEMLampModule");
        M_OEMMarking = Tool.CheckQueryString("OEMMarking");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //設定廠牌
        DataRow rowBrand = BLL_UHRWeb.GetBrandData(M_BrandID);
        lblBrand.Text = Convert.ToString(rowBrand["Brand"]);

        //帶入母視窗OEMLampModule
        txtOEM_LM.Text = M_OEMLampModule;
        txtMarking.Text = M_OEMMarking;

        //載入清單
        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得資料來源
        int recordCount;
        DataTable dtBrandList = BLL_UHRWeb.GetOEMLampModuleList(null, M_BrandID, txtOEM_LM.Text, txtMarking.Text, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("原廠燈模組", "OEM_LM", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("原廠燈Marking", "Marking", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtBrandList;
        gv.DataBind();

        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<img src='{0}' title='Add' style='cursor:pointer' align='absmiddle' onclick=\"ModifyAction('')\" />　",
                                        ResolveClientUrl("~/images/ToolBar/add.png"));
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strOEM_LM_ID = Convert.ToString(rowView["ID"]);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //管理區
            cellManage.Text = "<input type='button' value='編輯' class='buttonStyle01s' onclick=\"ModifyAction('" + strOEM_LM_ID + "')\" />";
        }
    }

    protected void btnModify_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 1;

        //設定廠牌
        DataRow rowBrand = BLL_UHRWeb.GetBrandData(M_BrandID);
        lblBrand1.Text = Convert.ToString(rowBrand["Brand"]);

        //判斷新增或修改
        string strOEM_LM_ID = hiddenVal.Value;
        if (string.IsNullOrEmpty(strOEM_LM_ID))
        {
            txtOEM_LM1.Text = "";
            txtMarking1.Text = "";
        }
        else
        {
            //設定OEM Lamp Module
            int recordCount;
            DataTable dtOEMLM = BLL_UHRWeb.GetOEMLampModuleList(strOEM_LM_ID, null, null, null, 1, 1, out recordCount);
            DataRow rowOEMLM = dtOEMLM.Rows[0];

            txtOEM_LM1.Text = Convert.ToString(rowOEMLM["OEM_LM"]);
            txtMarking1.Text = Convert.ToString(rowOEMLM["Marking"]);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //變數
            string strBrand = lblBrand.Text;
            string strOEM_LM_ID = hiddenVal.Value;
            string strOEM_LM = txtOEM_LM1.Text.Trim();
            string strMarking = txtMarking1.Text.Trim();
            string strMessage = "";

            //呼叫邏輯層
            bool bResult = BLL_UHRWeb.ModifyOEMLampModule(strOEM_LM_ID, strBrand, strOEM_LM, strMarking, ref strMessage);
            if (bResult)
            {
                mv.ActiveViewIndex = 0;
                gv_GridDataBind(sender, e); //載入清單
            }
            else
            {
                MessageInfo.ShowMessage(false, strMessage);
            }
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 0;
    }
}