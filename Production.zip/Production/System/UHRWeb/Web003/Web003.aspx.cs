﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web003 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        q_ddlStatus.DataSource = BLL_UHRWeb.GetConfigData("ProductStatus");
        q_ddlStatus.DataBind();
        q_ddlStatus.Items.Insert(0, new ListItem("--select status--", ""));

        q_ddlBLStatus.DataSource = BLL_UHRWeb.GetConfigData("ProductStatus");
        q_ddlBLStatus.DataBind();
        q_ddlBLStatus.Items.Insert(0, new ListItem("--select status--", ""));

        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strLampModule = q_txtLampModule.Text.Trim();
        string strStatus = q_ddlStatus.SelectedValue;
        string strBareLamp = q_txtBareLamp.Text.Trim();
        string strBLStatus = q_ddlBLStatus.SelectedValue;

        //取得資料來源
        int recordCount;
        DataTable dtLampModuleList = BLL_UHRWeb.GetLampModuleList(null, strLampModule, strStatus, strBareLamp, strBLStatus, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("Item", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Lamp Module", "UHR_LM", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Class", "Class", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Type", "Type", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("LM Status", "LM_Status", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Bare Lamp", "UHR_BL", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("BL Status", "BL_Status", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Manage", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtLampModuleList;
        gv.DataBind();

        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<img src='{0}' title='Add' style='cursor:pointer' align='absmiddle' onclick=\"ModifyAction('')\" />　",
                                        ResolveClientUrl("~/images/ToolBar/add.png"));
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "Item", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "Manage", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strUHRLM = Convert.ToString(rowView["UHR_LM"]);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            cellManage.Text = "<image src='../../../images/ToolBar/Edit.gif' title='編輯' style='cursor:pointer' onclick=\"ModifyAction('" + strID + "')\" /> " +
                              "<image src='../../../images/ToolBar/Del.png' title='刪除' style='cursor:pointer' onclick=\"DeleteAction('" + strID + "','" + strUHRLM + "')\" />";
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (!file.HasFile) { MessageInfo.ShowMessage(false, "請選擇匯入之檔案!"); return; }
        if (Tool.GetSubString(file.FileName, ".", false, false, "Lower") != "csv") { MessageInfo.ShowMessage(false, "匯入的格式需為CSV格式!"); return; }

        //上傳檔案
        string strFileName = "UHR_ProductList.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        //取得上傳檔案內容
        DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName);

        if (dtCSV.Rows.Count > 100) { MessageInfo.ShowMessage(false, "匯入的資料筆數不可大於100筆!"); return; }

        //呼叫邏輯層
        string Message; bool Result;
        BLL_UHRWeb.ModifyUHRProductList(dtCSV, out Result, out Message);

        //結果處理
        MessageInfo.ShowMessage(Result, Message);
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strLampModule = q_txtLampModule.Text.Trim();
        string strStatus = q_ddlStatus.SelectedValue;
        string strBareLamp = q_txtBareLamp.Text.Trim();
        string strBLStatus = q_ddlBLStatus.SelectedValue;

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "UHR_ProductList.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetLampModuleList(null, strLampModule, strStatus, strBareLamp, strBLStatus, 1, int.MaxValue, out recordCount);

        dtList.Columns.Remove("RowNum"); //移除欄位

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        string strID = hiddenVal.Text;
        bool Result = true;
        string Message = "";

        BLL_UHRWeb.DeleteUHRLampModule(strID, ref Result, ref Message);

        if (Result)
        {
            gv_GridDataBind(sender, e);
        }
        else
            MessageInfo.ShowMessage(Result, Message);
    }
}