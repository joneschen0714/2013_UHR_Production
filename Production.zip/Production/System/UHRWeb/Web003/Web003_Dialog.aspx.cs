﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web003_Dialog : UHR.BasePage.BasePage
{
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id"); //ID

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        ddlClass.DataSource = BLL_UHRWeb.GetConfigData("ProductClass");
        ddlClass.DataBind();
        ddlClass.Items.Insert(0, new ListItem("--select class--", ""));

        ddlType.DataSource = BLL_UHRWeb.GetConfigData("LampType");
        ddlType.DataBind();
        ddlType.Items.Insert(0, new ListItem("--select type--", ""));

        ddlStatus.DataSource = BLL_UHRWeb.GetConfigData("ProductStatus");
        ddlStatus.DataBind();
        ddlStatus.Items.Insert(0, new ListItem("--select status--", ""));

        ddlBLStatus.DataSource = BLL_UHRWeb.GetConfigData("ProductStatus");
        ddlBLStatus.DataBind();
        ddlBLStatus.Items.Insert(0, new ListItem("--select status--", ""));

        if (!string.IsNullOrEmpty(M_ID))
        {
            int recordCount;
            DataRow row = BLL_UHRWeb.GetLampModuleList(M_ID, null, null, null, null, 1, 1, out recordCount).Rows[0]; //取得UHR LampModule內容

            //設定控制項值
            txtLampModule.Text = Convert.ToString(row["UHR_LM"]);
            txtLampModule.Enabled = false;
            ddlClass.SelectedValue = Convert.ToString(row["Class"]);
            ddlType.SelectedValue = Convert.ToString(row["Type"]);
            ddlStatus.SelectedValue = Convert.ToString(row["LM_Status"]);
            txtLMPrice.Text = Convert.ToString(row["LM_Price"]);
            txtDescription.Text = Convert.ToString(row["Description"]);
            txtBareLamp.Text = Convert.ToString(row["UHR_BL"]);
            ddlBLStatus.SelectedValue = Convert.ToString(row["BL_Status"]);
            txtBLPrice.Text = Convert.ToString(row["BL_Price"]);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //取得變數
        string UHRLampModule = txtLampModule.Text.Trim();
        string Class = ddlClass.SelectedValue;
        string Type = ddlType.SelectedValue;
        string Status = ddlStatus.SelectedValue;
        string LM_Price = txtLMPrice.Text.Trim();
        string Description = txtDescription.Text.Trim();
        string UHRBareLamp = txtBareLamp.Text.Trim();
        string BL_Status = ddlBLStatus.SelectedValue;
        string BL_Price = txtBLPrice.Text.Trim();

        //取得Table Schema
        int recordCount;
        DataTable dt = BLL_UHRWeb.GetLampModuleList("0", null, null, null, null, 1, 1, out recordCount);

        //設定參數
        DataRow row = dt.NewRow();
        row["ID"] = Tool.GetDBNullString(M_ID);
        row["Class"] = Class;
        row["UHR_LM"] = UHRLampModule;
        row["Type"] = Type;
        row["LM_Status"] = Status;
        row["LM_Price"] = Tool.GetDBNullString(LM_Price);
        row["Description"] = Description;
        row["UHR_BL"] = UHRBareLamp;
        row["BL_Status"] = BL_Status;
        row["BL_Price"] = Tool.GetDBNullString(BL_Price);
        dt.Rows.Add(row);

        //呼叫邏輯層
        string Message; bool Result;
        BLL_UHRWeb.ModifyUHRProductList(dt, out Result, out Message);

        //結果處理
        if (Result)
        {
            //關閉視窗，重整List
            SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(Result, Message);
        }
    }
}