﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using UHR;
using UHR.Util;

public partial class Web014_Dialog : UHR.BasePage.BasePage
{
    //全域變數
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //取得資料來源
        int recordCount;
        DataTable dt = BLL_UHRWeb.GetOrderHistory(M_ID, null, null, null, null, null, null, null, null, null, 1, 1, out recordCount);
        DataRow row = dt.Rows[0];

        DataTable dtM = BLL_UHRWeb.GetMemberInfo(row["Member_ID"].ToString(), null, null, null, null, null, null, 1, 1, out recordCount);
        DataRow rowM = dtM.Rows[0];

        //設定值
        lblERPCustomCode.Text = string.Format("{0} - {1}",rowM["ERP_Company"],rowM["ERP_CustomCode"]);
        lblEmail.Text = rowM["Email"].ToString();
        lblName.Text = rowM["Name"].ToString();
        lblCompany.Text = rowM["Company"].ToString();

        lblOrderNo.Text = row["OrderNum"].ToString();
        lblAttn.Text = row["Attn"].ToString();
        lblPO.Text = row["PO"].ToString();
        lblTel.Text = row["Tel"].ToString();
        lblShippingAddr.Text = row["ShippingAddress"].ToString();
        lblBillingAddr.Text = row["BillingAddress"].ToString();
        lblComment.Text = row["Comment"].ToString();

        //循序讀取OrderNumber對應ERP的報價單號
        DataTable dtERPNumber = BLL_UHRWeb.GetInquiryNumberInERP(lblOrderNo.Text);
        foreach (DataRow tRow in dtERPNumber.Rows)
        {
            lblERPConnectNumber.Text += string.Format("{0} {1}-{2} <br/>", tRow["COMPANY"], tRow["TB001"], tRow["TB002"]);
        }

        //若無報價單號
        if (lblERPConnectNumber.Text == "")
        {
            //若已刪單則隱藏刪單按鈕
            if (row["Cancel"].ToString() == "Y")
            {
                btnCancel.Visible = false;
            }
        }
        else
        {
            //若有報價單號，則隱藏刪單按鈕
            btnCancel.Visible = false;
        }

        //載入項目
        rpProductList.ItemDataBound += new RepeaterItemEventHandler(rpProductList_ItemDataBound);
        rpProductList.DataSource = DAL_UHRWeb.GetOrderItemList(M_ID);
        rpProductList.DataBind();
    }

    protected void rpProductList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            //取得當筆資料來源
            DataRowView row = (DataRowView)e.Item.DataItem;

            //取得產品資訊
            int record;
            DataTable dtProjector = BLL_UHRWeb.GetProjectorList(row["P_ID"].ToString(), null, null, null, 1, 1, out record);
            DataRow pRow = dtProjector.Rows[0];

            //取得控制項
            Label lblItem = (Label)e.Item.FindControl("lblItem");
            Label lblType = (Label)e.Item.FindControl("lblType");
            Label lblPN = (Label)e.Item.FindControl("lblPN");
            Label lblProjector = (Label)e.Item.FindControl("lblProjector");
            Label lblOEMLM = (Label)e.Item.FindControl("lblOEMLM");
            Label lblCustomPN = (Label)e.Item.FindControl("lblCustomPN");
            Label lblCustomDESC = (Label)e.Item.FindControl("lblCustomDESC");
            Label lblQty = (Label)e.Item.FindControl("lblQty");

            //設定值
            lblItem.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblType.Text = (row["Type"].ToString() == "LM" ? "LampModule" : "Bulb");
            lblPN.Text = row["ProductNo"].ToString();
            lblProjector.Text = string.Format("{0} {1}", pRow["Brand"], pRow["ProjectorModel"].ToString().TrimStart('!'));
            lblOEMLM.Text = pRow["OEMLampModule"].ToString().TrimStart('!');
            lblCustomPN.Text = row["CustomPN"].ToString();
            lblCustomDESC.Text = row["CustomDESC"].ToString();
            lblQty.Text = row["Quantity"].ToString();
        }
    }

    protected void btnCalcel_Click(object sender, EventArgs e)
    {
        BLL_UHRWeb.CancelOrder(lblOrderNo.Text);
        MessageInfo.ShowMessage(true, "作業成功!");
    }
}