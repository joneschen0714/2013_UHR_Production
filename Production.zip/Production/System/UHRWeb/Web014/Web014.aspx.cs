﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class Web014 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入ERP公司別
        ddlERPCompany.DataSource = new CompanyCollection();
        ddlERPCompany.DataBind();

        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢參數
        string strOrderNo = txtOrderNo.Text.Trim().ToUpper();
        string strERPCompany = ddlERPCompany.SelectedValue;
        string strERPCustomCode = txtERPCustomCode.Text.Trim().ToUpper();
        string strEmail = txtEmail.Text.Trim();
        string strStartDate = txtStartDate.Text.Trim();
        string strEndDate = txtEndDate.Text.Trim();
        string strCompany = txtCompany.Text.Trim();
        string strName = txtName.Text.Trim();
        string strDataType = ddlDataType.SelectedValue;

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetOrderHistory(null, strOrderNo, strEmail, strERPCompany, strERPCustomCode, strStartDate, strEndDate, strCompany, strName, strDataType, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("日期", "Date", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("訂單號碼", "OrderNum", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("訂單類型", "Type", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("會員Email", "Email", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("ERP公司別", "ERP_Company", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客戶代號", "ERP_CustomCode", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("刪單", "Cancel", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtList;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellCancel = gv.GetTableCell(e.Row, "Cancel", true);
            TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strCancel = Convert.ToString(rowView["Cancel"]);

            //若刪單則顯示圖示
            if (strCancel == "Y")
            {
                Image img = new Image();
                img.ImageUrl = "~/images/del.png";
                cellCancel.Controls.Add(img);
            }

            //管理
            cellManage.Text = "<input type='button' value='編輯' class='buttonStyle01s' onclick=\"Modify('" + strID + "')\" />";
        }
    }
}