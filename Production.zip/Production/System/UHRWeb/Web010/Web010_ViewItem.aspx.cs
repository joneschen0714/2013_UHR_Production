﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web010_ViewItem : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        repItem.ItemDataBound += new RepeaterItemEventHandler(repItem_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        DataTable dt = BLL_UHRWeb.GetMailLogItem(ID);

        repItem.DataSource = dt;
        repItem.DataBind();
    }

    protected void repItem_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            Label lblEmail =  (Label)e.Item.FindControl("lblEmail");
            Label lblCreateDate = (Label)e.Item.FindControl("lblCreateDate");

            lblEmail.Text = rowView["Email"].ToString();
            lblCreateDate.Text = Convert.ToDateTime(rowView["CreateDate"]).ToString();
        }
    }


    private string ID
    {
        get { return Tool.CheckQueryString("id"); }
    }
}