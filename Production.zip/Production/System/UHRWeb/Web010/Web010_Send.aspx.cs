﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Net.Mail;
using System.IO;
using UHR;
using UHR.Util;

public partial class Web010_Send : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //設定上傳圖片路徑
        ftbContent.ImageGalleryUrl = ResolveClientUrl("~/aspnet_client/FreeTextBox/ftb.imagegallery.aspx?rif={0}&cif={0}");
        ftbContent.ImageGalleryPath = "~/System/UHRWeb/Source/Picture/Other";

        if (!IsPostBack)
        {
            DataBind();
        }

        btnSend.Attributes.Add("onclick", "return confirm('是否確定發送?')");
    }

    public override void DataBind()
    {
        if (ID == "")
        {
            ddlType_SelectedIndexChanged(new object(), new EventArgs());
        }
        else
        {
            //顯示 & 隱藏區域
            txtSubject.Enabled = false;
            btnPreview.Visible = false;
            trType.Visible = false;
            trTemplate.Visible = false;
            trUHRLM.Visible = false;
            palPreView.Visible = true;

            //帶入值
            DataRow row = BLL_UHRWeb.GetMailLogData(ID);
            txtSubject.Text = row["Subject"].ToString();
            divHtmlContent.InnerHtml = row["Content"].ToString();
        }
    }

    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strType = ddlType.SelectedValue;

        if (strType == "Template")
        {
            trTemplate.Visible = true;
            trUHRLM.Visible = true;
            palEditArea.Visible = false;
            palPreView.Visible = false;
        }
        else if (strType == "Custom")
        {
            trTemplate.Visible = false;
            trUHRLM.Visible = false;
            palEditArea.Visible = true;
            palPreView.Visible = false;
        }
    }

    //預覽
    protected void btnPreview_Click(object sender, EventArgs e)
    {
        palPreView.Visible = true;

        divHtmlContent.InnerHtml = TemplateContent;
    }

    //發送
    protected void btnSend_Click(object sender, EventArgs e)
    {
        //變數
        string strType = ddlType.SelectedValue;
        string strTemplate = ddlTemplate.SelectedValue;
        string strEmailList = txtEmailList.Text.Replace(System.Environment.NewLine, ",").Trim(' ', ','); //分割為字串陣列
        string strSubject = txtSubject.Text.Trim(); //信件主旨
        string strContent = ""; //信件內容

        #region 驗証控制項
        if (strEmailList == "") { MessageInfo.ShowMessage(false, "發送對象不可空白!"); return; }
        if (strSubject == "") { MessageInfo.ShowMessage(false, "主旨不可空白!"); return; }
        #endregion

        //設定信件內容
        if (ID == "")
            strContent = TemplateContent;
        else
            strContent = BLL_UHRWeb.GetMailLogData(ID)["Content"].ToString();

        //呼叫邏輯層
        bool bResult; string strMessage;
        BLL_UHRWeb.ModifyMailLog(ID, strSubject, strContent, strEmailList, out bResult, out strMessage);

        if (bResult)
        {
            #region 更新New product的項目
            if (strType == "Template")
                if (strTemplate == "0" || strTemplate == "1" || strTemplate == "2")
                    if (txtUHR_LM.Text.Trim() != "")
                        DAL_UHRWeb.UpdateNewProduct(txtUHR_LM.Text.Trim());
            #endregion

            #region Mail相關設定
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
            _mail.Bcc.Add(strEmailList);
            _mail.Subject = strSubject;
            _mail.Body = strContent;
            _mail.IsBodyHtml = true;
            _mail.SendMail();
            _mail.Dispose();
            #endregion

            base.SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(bResult, strMessage);
        }
    }

    private string ID
    {
        get { return Tool.CheckQueryString("id"); }
    }

    //取得信件內容
    private string TemplateContent
    {
        get
        {
            string strReturn = "";
            string strRemark = "";
            string strType = ddlType.SelectedValue;
            string strTemplate = ddlTemplate.SelectedValue;

            //判斷類型
            if (strType == "Template")
            {
                //若為New Product
                if (strTemplate == "0" || strTemplate == "1" || strTemplate == "2")
                {
                    string strUHR_LM = txtUHR_LM.Text.Trim(); //取得UHR Lamp Module
                    string strUHR_LMID = BLL_UHRWeb.GetUhrLMID(strUHR_LM); //取得UHR Lamp Module ID

                    DataTable dt = BLL_UHRWeb.GetRelatedOEMLampModule(strUHR_LMID); //來源資料
                    DataTable dtResult = dt.DefaultView.ToTable(true, "Brand", "LM_Status", "BL_Status"); //取出相異資料

                    //依模版更換Remark字
                    if (strTemplate == "0" || strTemplate == "1")
                        strRemark = "100% OEQ Lamp Inside";
                    else if (strTemplate == "2")
                        strRemark = "100% OEM Lamp Inside";

                    //循序讀取相異資料
                    string strHtml = "";
                    foreach (DataRow row in dtResult.Rows)
                    {
                        //變數
                        string strBrand = row["Brand"].ToString();
                        string strOEM_LM = "";
                        string strLM_Status = row["LM_Status"].ToString();
                        string strBL_Status = row["BL_Status"].ToString();

                        string strTmpHtml = "<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td></tr>";

                        //循序讀取OEM LampModule
                        DataRow[] rowsOEM_LM = dt.Select("Brand='" + strBrand + "' AND LM_Status='" + strLM_Status + "' AND BL_Status='" + strBL_Status + "'");
                        foreach (DataRow row1 in rowsOEM_LM)
                        {
                            strOEM_LM += (strOEM_LM == "" ? "" : "<br/>") + row1["OEM_LM"].ToString(); //累加OEM LampModule
                        }

                        //轉換顯示狀態
                        strLM_Status = strLM_Status == "I" ? "In Stock" : "";
                        strBL_Status = strBL_Status == "I" ? "In Stock" : "";

                        strTmpHtml = string.Format(strTmpHtml, strBrand, strUHR_LM, strOEM_LM, strLM_Status, strBL_Status, strRemark); //取代內容
                        strHtml += strTmpHtml; //累加Html內容
                    }

                    //轉換模版檔名
                    string strFileName = "";
                    if (strTemplate == "0" || strTemplate == "2") strFileName = "NewProduct_en.htm";
                    if (strTemplate == "1") strFileName = "NewProduct_de.htm";

                    #region Mail內容參數
                    TemplateMail _template = new TemplateMail("~/configuration/Template/UHRWeb/" + strFileName);
                    _template["{UHRLampModule}"] = "<a href='http://www.uhrlamps.com/Page/Product/ProductList.aspx?uhrlm=" + strUHR_LMID + "'>" + strUHR_LM + "</a>";
                    _template["{Items}"] = strHtml;

                    //依模版更換內文字
                    if (strTemplate == "0")
                    {
                        _template["{Logo}"] = "UHR";
                        _template["{Slogon}"] = "100% OEQ Lamp Inside / OEQ Family(OEM Qualified)";
                    }
                    else if (strTemplate == "2")
                    {
                        _template["{Logo}"] = "UHRG";
                        _template["{Slogon}"] = "100% OEM Lamp Inside / OEQ Family(OEM Qualified)";
                    }
                    #endregion

                    strReturn = _template.ToString();
                }
            }
            else if (strType == "Custom")
            {
                strReturn = ftbContent.Text;
            }

            return strReturn;
        }
    }
}