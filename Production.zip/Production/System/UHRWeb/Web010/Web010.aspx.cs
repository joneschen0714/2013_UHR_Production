﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class Web010 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件
        string strSubject = txtSubject.Text.Trim();

        //取得資料來源
        int recordCount;
        DataTable dtMailLog = BLL_UHRWeb.GetMailLogList(strSubject, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, 50, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("主旨", "Subject", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("發送對象數", "Count", false, 100, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("建立日期", "CreateDate", false, 100, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("管理區", "", false, 200, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtMailLog;
        gv.DataBind();
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
            TableCell cellSubject = gv.GetTableCell(e.Row, "Subject", true);
            TableCell cellCreateDate = gv.GetTableCell(e.Row, "CreateDate", true);
            TableCell cellManage = gv.GetTableCell(e.Row, "管理區", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strCreateDate = Convert.ToDateTime(rowView["CreateDate"]).ToString("yyyy/MM/dd");

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            cellCreateDate.Text = strCreateDate;

            cellManage.Text = "<input type='button' value='檢視記錄' class='buttonStyle01m' onclick=\"ViewItem('" + strID + "')\" /> " +
                              "<input type='button' value='補    寄' class='buttonStyle01m' onclick=\"SendMail('" + strID + "')\" />";
        }
    }
}