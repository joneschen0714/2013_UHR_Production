﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web008_Dialog : UHR.BasePage.BasePage
{
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        M_ID = Tool.CheckQueryString("id");

        //設定上傳圖片路徑
        ftbDescription.ImageGalleryUrl = ResolveClientUrl("~/aspnet_client/FreeTextBox/ftb.imagegallery.aspx?rif={0}&cif={0}");
        ftbDescription.ImageGalleryPath = ConfigurationManager.AppSettings["OtherImgPath"];

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        if (!string.IsNullOrEmpty(M_ID))
        {
            //回填控制項
            DataRow row = BLL_UHRWeb.GetCatalogData(M_ID);
            txtName.Text = row["Name"].ToString().Trim();
            txtEffectiveDate.Text = Convert.ToDateTime(row["EffectiveDate"]).ToString("yyyy/MM/dd");
            txtExpiryDate.Text = Convert.ToDateTime(row["ExpiryDate"]).ToString("yyyy/MM/dd");
            ddlShowInList.SelectedValue = row["ShowInList"].ToString();
            ftbDescription.Text = row["Description"].ToString().Trim();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //資料參數
        string strName = txtName.Text.Trim();
        string strEffectiveDate = txtEffectiveDate.Text;
        string strExpiryDate = txtExpiryDate.Text + " 23:59:00";
        string strShowInList = ddlShowInList.SelectedValue;
        string strDescription = ftbDescription.Text.Trim();

        //呼叫邏輯層
        string Message;
        bool bResult = BLL_UHRWeb.ModifyCatalog(M_ID, strName, strEffectiveDate, strExpiryDate, strShowInList, strDescription, out Message);

        if (bResult)
        {
            //關閉視窗，重整List
            SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(bResult, Message);
        }
    }
}