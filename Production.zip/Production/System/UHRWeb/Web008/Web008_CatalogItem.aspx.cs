﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web008_CatalogItem : UHR.BasePage.BasePage
{
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        M_ID = Tool.CheckQueryString("id");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        if (!string.IsNullOrEmpty(M_ID))
        {
            lblCatalogName.Text = DAL_UHRWeb.GetCatalogData(M_ID)["Name"].ToString();
            CatalogItemTable = DAL_UHRWeb.GetCatalogItem(M_ID);
            CatalogItemReload();
        }
    }

    private void CatalogItemReload()
    {
        // 建立資料列表
        int index = 1;
        liCatalogItem.Text = string.Empty;
        foreach (DataRow row in CatalogItemTable.Rows)
        {
            string strChecked = Convert.ToBoolean(row["Enabled"]) ? "checked" : "";
            liCatalogItem.Text += string.Format("<tr><td>{0}</td><td>{1}</td><td><input name='cbItemEnabled{0}' type='checkbox' {2} /></td><td><input name='cbItemDel{0}' type='checkbox' onclick='SelectRemoveItem(this)' /></td></tr>", index, row["LM"], strChecked);
            index++;
        }
    }

    private void UpdateFormData()
    {
        int iCount = CatalogItemTable.Rows.Count;

        for (int i = 1; i <= iCount; i++)
        {
            string strEnabled = Request.Form["cbItemEnabled" + i.ToString()];
            CatalogItemTable.Rows[i - 1]["Enabled"] = (strEnabled == "on" ? "True" : "False");
        }
    }

    protected void btnItemAdd_Click(object sender, EventArgs e)
    {
        UpdateFormData();

        #region 循序讀取欲增加的UHR Lamp Module
        string strItemsText = txtLampModule.Text;
        if (strItemsText != "")
        {
            foreach (string strLM in strItemsText.Split(','))
            {
                string strUHR_LMID = BLL_UHRWeb.GetUhrLMID(strLM); //取得對應的UHR_LMID
                bool bExists = (CatalogItemTable.Select("LM='" + strLM + "'").Length > 0); //是否存在暫存資料裡

                if ((strUHR_LMID != null) && !bExists) { CatalogItemTable.Rows.Add(strUHR_LMID, strLM, "True"); } //增加資料列至暫存表
            }
        }
        txtLampModule.Text = string.Empty; //清空LM文字方塊
        #endregion

        CatalogItemReload();
    }

    protected void btnDeleteCatalogItem_Click(object sender, ImageClickEventArgs e)
    {
        UpdateCatalogItemEnabled();

        int iCount = CatalogItemTable.Rows.Count;
        for (int i = iCount; i >= 1; i--)
        {
            string strDel = Request.Form["cbItemDel" + i.ToString()];
            if (strDel == "on")
            {
                DataRow row = CatalogItemTable.Rows[i - 1];
                CatalogItemTable.Rows.Remove(row);
            }
        }

        CatalogItemReload();
    }

    private void UpdateCatalogItemEnabled()
    {
        int iCount = CatalogItemTable.Rows.Count;
        for (int i = iCount; i >= 1; i--)
        {
            string strEnabled = Request.Form["cbItemEnabled" + i.ToString()];
            CatalogItemTable.Rows[i - 1]["Enabled"] = (strEnabled == "on");
        }
    }

    protected void btnItemSave_Click(object sender, EventArgs e)
    {
        UpdateCatalogItemEnabled();
        DAL_UHRWeb.ModifyCatalogItem(M_ID, CatalogItemTable); //整批修改

        CatalogItemTable.Clear(); //清空暫存表
        CatalogItemTable.Dispose(); //釋放資源

        //關閉視窗，重整List
        SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
    }

    #region
    private DataTable CatalogItemTable
    {
        set { Session.Add("CatalogItemTable", value); }
        get { return (DataTable)Session["CatalogItemTable"]; }
    }
    #endregion
}