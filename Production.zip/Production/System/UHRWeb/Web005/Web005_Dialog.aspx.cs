﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web005_Dialog : UHR.BasePage.BasePage
{
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id"); //ID

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入Brand清單
        int iResult;
        ddlBrand.DataSource = BLL_UHRWeb.GetAllBrand(null, null, 1, int.MaxValue, out iResult);
        ddlBrand.DataBind();
        ddlBrand.Items.Insert(0, new ListItem("-- select --", ""));

        if (!string.IsNullOrEmpty(M_ID))
        {
            int recordCount;
            DataRow row = BLL_UHRWeb.GetProjectorList(M_ID, null, null, null, 1, 1, out recordCount).Rows[0]; //取得Projector內容

            //設定值
            ddlBrand.SelectedValue = Convert.ToString(row["Brand"]);
            ddlBrand.Enabled = false;
            txtProjectorModel.Text = Convert.ToString(row["ProjectorModel"]).Trim('!');
            txtProjectorModel.Enabled = false;
            txtOEMLampModule.Text = Convert.ToString(row["OEMLampModule"]).Trim('!');
            txtLampType.Text = Convert.ToString(row["OEM_LT"]);
            txtProduceDate.Text = Convert.ToString(row["LifePeriod"]);
            txtUHRLampModule.Text = Convert.ToString(row["UHR_LM"]);
            ddlEnabled.SelectedValue = Convert.ToString(row["Enabled"]);
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //取得變數
        string Brand = ddlBrand.SelectedValue;
        string ProjectorModel = txtProjectorModel.Text.Trim();
        string OEMLampModules = txtOEMLampModule.Text.Trim();
        string LampType = txtLampType.Text.Trim();
        string LifePeriod = txtProduceDate.Text.Trim();
        string UHRLampModule = txtUHRLampModule.Text.Trim();
        string Enabled = ddlEnabled.SelectedValue;

        //取得Table Schema
        int recordCount;
        DataTable dt = BLL_UHRWeb.GetProjectorList("0", null, null, null, 1, 1, out recordCount);

        //設定參數
        DataRow row = dt.NewRow();
        row["ID"] = Tool.GetDBNullString(M_ID);
        row["Brand"] = Brand;
        row["ProjectorModel"] = ProjectorModel;
        row["OEM_LT"] = LampType;
        row["UHR_LM"] = UHRLampModule;
        row["LifePeriod"] = LifePeriod;
        row["Enabled"] = Enabled;
        row["OEMLampModule"] = OEMLampModules;
        dt.Rows.Add(row);

        //呼叫邏輯層
        string Message; bool Result;
        BLL_UHRWeb.ModifyOEMProductList(dt, out Result, out Message);

        //結果處理
        if (Result)
        {
            //關閉視窗，重整List
            SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(Result, Message);
        }
    }
}