﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class Web005 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        int iResult;
        ddlBrand.DataSource = BLL_UHRWeb.GetAllBrand(null, null, 1, int.MaxValue, out iResult);
        ddlBrand.DataBind();
        ddlBrand.Items.Insert(0, new ListItem("All", ""));

        gv_GridDataBind(new object(), new EventArgs());
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strBrandID = ddlBrand.SelectedValue;
        string strProjector = txtProjectorModel.Text.Trim();
        string strUHR_LM = txtUHR_LM.Text.Trim();

        //取得資料來源
        int recordCount;
        DataTable dtProjectorList = BLL_UHRWeb.GetProjectorList(null, strBrandID, strProjector, strUHR_LM, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("Item", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Brand", "Brand", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Projector Model", "ProjectorModel", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("OEM_LT", "OEM_LT", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("UHR LM", "UHR_LM", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Enabled", "Enabled", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("Manage", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtProjectorList;
        gv.DataBind();

        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<img src='{0}' title='Add' style='cursor:pointer' align='absmiddle' onclick=\"ModifyAction('')\" />　",
                                        ResolveClientUrl("~/images/ToolBar/add.png"));
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellItem = gv.GetTableCell(e.Row, "Item", false);
            TableCell cellProjectorModel = gv.GetTableCell(e.Row, "ProjectorModel", true);
            TableCell cellManage = gv.GetTableCell(e.Row, "Manage", false);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);

            cellProjectorModel.Text = cellProjectorModel.Text.Trim('!');

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            cellManage.Text = "<input type='button' value='Edit' class='buttonStyle01s' onclick=\"ModifyAction('" + strID + "')\" />";
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (!file.HasFile) { MessageInfo.ShowMessage(false, "請選擇匯入之檔案!"); return; }

        //上傳檔案
        string strFileName = "OEM_ProductList.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        //取得上傳檔案內容
        DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName);

        if (dtCSV.Rows.Count > 100) { MessageInfo.ShowMessage(false, "匯入的資料筆數不可大於100筆!"); return; }

        //呼叫邏輯層
        string Message; bool Result;
        BLL_UHRWeb.ModifyOEMProductList(dtCSV, out Result, out Message);

        //結果處理
        MessageInfo.ShowMessage(Result, Message);
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strBrandID = ddlBrand.SelectedValue;
        string strProjector = txtProjectorModel.Text.Trim();
        string strUHR_LM = txtUHR_LM.Text.Trim();

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "OEM_ProductList.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        int recordCount;
        DataTable dtList = BLL_UHRWeb.GetProjectorList(null, strBrandID, strProjector, strUHR_LM, 1, int.MaxValue, out recordCount);

        dtList.Columns.Remove("RowNum"); //移除欄位

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}