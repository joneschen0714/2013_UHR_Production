﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class Web006_Dialog : UHR.BasePage.BasePage
{
    private string M_ID;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //設定上傳圖片路徑
        ftbContent.ImageGalleryUrl = ResolveClientUrl("~/aspnet_client/FreeTextBox/ftb.imagegallery.aspx?rif={0}&cif={0}");
        ftbSlideContent.ImageGalleryUrl = ResolveClientUrl("~/aspnet_client/FreeTextBox/ftb.imagegallery.aspx?rif={0}&cif={0}");
        ftbContent.ImageGalleryPath = ConfigurationManager.AppSettings["OtherImgPath"];
        ftbSlideContent.ImageGalleryPath = ConfigurationManager.AppSettings["OtherImgPath"];

        //網址參數
        M_ID = Tool.CheckQueryString("id"); //ID

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        if (!string.IsNullOrEmpty(M_ID))
        {
            DataRow row = BLL_UHRWeb.GetNewsDetail(M_ID); //取得News內容

            //設定值
            ddlLang.SelectedValue = Convert.ToString(row["Lang"]);
            ddlType.SelectedValue = Convert.ToString(row["Type"]);
            txtTitle.Text = Convert.ToString(row["Title"]);
            ftbContent.Text = Convert.ToString(row["Content"]);
            ftbSlideContent.Text = Convert.ToString(row["SlideContent"]);
            txtTimeSpan.Text = Convert.ToString(row["SlideTimeSpan"]);
            txtEffectiveDate.Text = Convert.ToDateTime(row["EffectiveDate"]).ToString("yyyy/MM/dd");
            txtExpiryDate.Text = Convert.ToDateTime(row["ExpiryDate"]).ToString("yyyy/MM/dd");
        }

        ddlType_SelectedIndexChanged(new object(), new EventArgs()); //依Type切換顯示區域
    }

    protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        //依Type切換顯示區域
        string strType = ddlType.SelectedValue;
        if (strType == "News")
        {
            trContent.Visible = true;
            trSlideContent.Visible = false;
            trTimeSpan.Visible = false;
        }
        else if (strType == "Slide")
        {
            trContent.Visible = false;
            trSlideContent.Visible = true;
            trTimeSpan.Visible = true;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //設定變數
        string strLang = ddlLang.SelectedValue;
        string strType = ddlType.SelectedValue;
        string strTitle = txtTitle.Text.Trim();
        string strContent = ftbContent.Text.Trim();
        string strSlideContent = ftbSlideContent.Text.Trim();
        string strTimeSpan = txtTimeSpan.Text.Trim();
        string strEffectiveDate = txtEffectiveDate.Text.Trim();
        string strExpiryDate = txtExpiryDate.Text.Trim();

        //控制項驗証
        string strMessage = ""; DateTime dResult; int iResult;
        if (string.IsNullOrEmpty(strTitle)) { strMessage += "Title must be Required<br />"; }
        if (!DateTime.TryParse(strEffectiveDate, out dResult)) { strMessage += "Effective Date format error<br />"; }
        if (!DateTime.TryParse(strExpiryDate, out dResult)) { strMessage += "Expiry Date format error<br />"; }
        if (txtTimeSpan.Visible && !int.TryParse(txtTimeSpan.Text, out iResult)) { strMessage += "TimeSpan is int"; }

        //是否通過驗証
        if (strMessage == "")
        {
            //依Type設定空值
            if (strType == "News")
            {
                txtTimeSpan.Text = "";
                ftbSlideContent.Text = "";
            }
            else if (strType == "Slide")
            {
                ftbContent.Text = "";
            }

            //呼叫邏輯層修改或寫入
            BLL_UHRWeb.ModifyNews(M_ID, strLang, strType, strTitle, null, strContent, strSlideContent, strTimeSpan, strEffectiveDate, strExpiryDate);

            //關閉視窗，重整List
            SetPageLoadScript("$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(false, strMessage); //顯示錯誤訊息
        }
    }
}