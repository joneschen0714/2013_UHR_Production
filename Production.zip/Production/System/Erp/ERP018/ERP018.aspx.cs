﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class ERP018 : UHR.BasePage.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        imgUser_E.Attributes.Add("onclick", "fn_openThisWindowDialog('" + ResolveUrl("~/Modules/ERP_User.aspx?ctrl=" + txtUser_E.ClientID) + "', 470, 420)");
        btnImport.Attributes.Add("onclick", "if(Page_ClientValidate()) { return confirm('注意，若匯入年月有已存在的客戶預測記錄，會先將原單據刪除，請確定是否要執行?'); }");
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //控制項值
        string strType = rblType_E.SelectedValue;
        string strDate = txtYear_E.Text.Trim() + ddlMonth_E.SelectedValue;
        string strUser = txtUser_E.Text.ToUpper().Trim();

        //驗証
        if (strType == "") { MessageInfo.ShowMessage(false, "種類不可空白!"); return; }
        if (strUser == "") { MessageInfo.ShowMessage(false, "業務員不可空白!"); return; }
        if (txtYear_E.Text.Trim() == "") { MessageInfo.ShowMessage(false, "年份不可空白!"); return; }

        DataTable dt = null;
        if (strType == "Product")
        {
            dt = BLL_ERP.GetSellingDivinationByProduct(strDate, strUser);
        }
        else if (strType == "Class")
        {
            dt = BLL_ERP.GetSellingDivinationByClass(strDate, strUser);
        }

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        Tool.DataTableToCSV(dt, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        //控制項值
        string strType = rblType_E.SelectedValue;
        string strDate = txtYear_I.Text.Trim() + ddlMonth_I.SelectedValue;

        //驗証
        if (strType == "") { MessageInfo.ShowMessage(false, "種類不可空白!"); return; }
        if (txtYear_I.Text.Trim() == "") { MessageInfo.ShowMessage(false, "年份不可空白!"); return; }

        //判斷有無檔案
        if (file.HasFile)
        {
            //上傳檔案
            string strFileName = "ERP018.csv";
            string strPath = Server.MapPath("~/Temp/");
            file.SaveAs(strPath + strFileName);

            //取得上傳檔案內容
            DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName);

            bool bResult = false;
            string strMessage = "";

            if (strType == "Product")
            {
                BLL_ERP.ImportSellingDivinationToProduct(strDate, dtCSV, ref bResult, ref strMessage);
            }
            else if (strType == "Class")
            {
                BLL_ERP.ImportSellingDivinationToClass(strDate, dtCSV, ref bResult, ref strMessage);
            }

            //處理結果顯示
            MessageInfo.ShowMessage(bResult, strMessage);
        }
        else
        {
            MessageInfo.ShowMessage(false, "匯入的檔案不可空白!");
        }
    }
}