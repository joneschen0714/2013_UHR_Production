﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;
using UHR.Util;
using System.Linq;

public partial class ERP015 : UHR.BasePage.BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //取得製令單別資料
        DataTable dtClass = BLL_ERP.GetManufactureForm(null, null);
        var result = (from r in dtClass.AsEnumerable() select r.Field<string>("製令單別")).Distinct();
        foreach (var item in result)
        {
            ddlFormClass.Items.Add(item.ToString());
        }
        ddlFormClass.Items.Insert(0, new ListItem("--請選擇單別--", ""));
    }

    protected void ddlFormClass_SelectedIndexChanged(object sender, EventArgs e)
    {
        string strClass = ddlFormClass.SelectedValue;

        if (!string.IsNullOrEmpty(strClass))
        {
            //取得製令單資料
            ddlFormNumber.DataSource = BLL_ERP.GetManufactureForm(ddlFormClass.SelectedValue, null);
            ddlFormNumber.DataBind();
            ddlFormNumber.Items.Insert(0, new ListItem("--請選擇單號--", ""));
        }
        else
        {
            //清空
            ddlFormNumber.Items.Clear();
            txtProductNo.Text = string.Empty;
        }
    }

    protected void ddlFormNumber_SelectedIndexChanged(object sender, EventArgs e)
    {
        //取得製令單資料
        DataTable dt = BLL_ERP.GetManufactureForm(ddlFormClass.SelectedValue, ddlFormNumber.SelectedValue);
        DataRow row = dt.Rows[0];

        txtProductNo.Text = row["品號"].ToString();
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        liSerialNoItem.Text = ""; //清空記錄

        string strProductNo = txtProductNo.Text.Trim(); //品號
        bool bIsOK = true;
        int iIndex = 1;

        //檢查品號存不存在
        if (BLL_ERP.GetINVMB(strProductNo) != null)
        {
            //循序讀取序號
            foreach (string strSerialNo in GetSerialNoArray)
            {
                //驗証是否存在序號
                string strExists = "";
                bool bResult = BLL_ERP.ExistsSerialNo(strSerialNo);
                if (bResult) { strExists = "<span style='color:red;'>已存在!</span>"; bIsOK = false; }

                //串接項目內容
                string strItem = "<tr>" +
                                    "<td>" + iIndex.ToString() + "</td>" +
                                    "<td>" + strSerialNo + "</td>" +
                                    "<td>" + strExists + "</td>" +
                                    "<td><a style='cursor:pointer;' onclick=\"OpenItemDialog('" + strSerialNo + "')\">View</a></td>" +
                                    "<td><input name='checkItem' type='checkbox' /></td>" +
                                 "</tr>";

                liSerialNoItem.Text += strItem; //累加項目
                iIndex++; //累加項次
            }

            if (bIsOK)
            {
                ddlFormNumber.Enabled = false;
                txtSerialNoFront.Enabled = false;
                txtStartSerial.Enabled = false;
                txtQty.Enabled = false;
                btnView.Enabled = false;
                btnDelete.Enabled = false;

                trCreate.Visible = true;
            }
        }
        else
        {
            MessageInfo.ShowMessage(false, "品號不存在，請確認!");
        }
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        string snList = txtSerialNoList.Text.Trim(); //序號清單

        //循序刪除序號
        string strMessage = "";
        foreach (string sn in snList.Split(','))
        {
            DataTable dtSerialNo = BLL_ERP.GetSerialData(null, null, sn, null, null, null, null);
            if (dtSerialNo.Rows.Count > 0)
            {
                strMessage += sn + " 已有單據資料，不可刪除!<br />";
            }
        }

        if (strMessage == "")
        {
            foreach (string sn in snList.Split(','))
                BLL_ERP.DeleteSerialNoHead(sn);

            MessageInfo.ShowMessage(true, "作業成功!");
        }
        else
        {
            MessageInfo.ShowMessage(false, strMessage);
        }
    }

    protected void btnCreate_Click(object sender, EventArgs e)
    {
        string strFormClass = ddlFormClass.SelectedValue.Trim(); //製令單別
        string strFormNumber = ddlFormNumber.SelectedValue.Trim(); //製令單號
        string strProductNo = txtProductNo.Text.Trim(); //品號

        foreach (string strSerialNo in GetSerialNoArray)
        {
            BLL_ERP.ModifySerialNo("Arclite", strProductNo, strSerialNo, strFormClass, strFormNumber, null, null, null, null, null, null, null);
        }

        btnCancel_Click(sender, e);
        MessageInfo.ShowMessage(true, "作業成功!");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ddlFormNumber.Enabled = true;
        txtSerialNoFront.Enabled = true;
        txtStartSerial.Enabled = true;
        txtQty.Enabled = true;
        btnView.Enabled = true;
        btnDelete.Enabled = true;

        trCreate.Visible = false;
        liSerialNoItem.Text = "";
    }

    private string[] GetSerialNoArray
    {
        get
        {
            string strSerialNoFront = txtSerialNoFront.Text.Trim(); //序號前置碼
            string strStartSerial = txtStartSerial.Text.Trim(); //起始流水號
            int iQty = Convert.ToInt32(txtQty.Text.Trim()); //數量
            string[] strArray = new string[iQty]; //陣列數量

            for (int i = 0; i < iQty; i++)
            {
                string strSerialNo = strSerialNoFront + Tool.GetPadLeftString(strStartSerial, i);
                strArray[i] = strSerialNo;
            }
            return strArray;
        }
    }
}