﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class ERP010 : UHR.BasePage.BasePage
{
    private DataTable dtSerialNo = null;

    protected void Page_Init(object sender, EventArgs e)
    {
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
    }

    //檢查單號是否存在
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //資料變數
            string strCompany = ddlCompany.SelectedValue; //公司別
            string strFormType = txtFormType.Text.Trim(); //單別
            string strFormNumber = txtFormNumber.Text.Trim(); //單號

            //資料清單繫結
            dtSerialNo = BLL_ERP.GetSerialData(strCompany, null, null, strFormType, strFormNumber, null, null); //序號資料
            DataTable dt = BLL_ERP.GetOrderList(strCompany, strFormType, strFormNumber);
            repList.DataSource = dt;
            repList.DataBind();

            if (dt.Rows.Count > 0)
            {
                palList.Visible = true;
                lblCustomName.Text = dt.Rows[0]["客戶名稱"].ToString();
            }
            else
            {
                MessageInfo.ShowMessage(false, "此單據不存在或未確認!"); return;
            }
        }
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源

            //取得控制項
            Label lblItemNo = (Label)e.Item.FindControl("lblItemNo");
            HyperLink linkProductNo = (HyperLink)e.Item.FindControl("linkProductNo");
            Label lblDescription = (Label)e.Item.FindControl("lblDescription");
            Label lblQty = (Label)e.Item.FindControl("lblQty");
            Label lblSerialQty = (Label)e.Item.FindControl("lblSerialQty");

            //設定值
            lblItemNo.Text = Convert.ToString(rowView["項次"]);
            linkProductNo.Text = Convert.ToString(rowView["品號"]);
            linkProductNo.Attributes.Add("onclick", string.Format("OpenItemDialog('{0}','{1}',this)", rowView["項次"], Convert.ToInt32(rowView["數量"])));
            lblDescription.Text = Convert.ToString(rowView["客戶商品描述"]);
            lblQty.Text = Convert.ToInt32(rowView["數量"]).ToString();
            lblSerialQty.Text = dtSerialNo.Select("項次='" + Convert.ToString(rowView["項次"]) + "'").Length.ToString();

            //若數量不相等，用紅色註記
            if (lblQty.Text.Trim() != lblSerialQty.Text.Trim()) { lblSerialQty.Text += "　<img align='absmiddle' src='../../../images/error.png' />"; }
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //資料變數
        string strCompany = ddlCompany.SelectedValue; //公司別
        string strFormType = txtFormType.Text.Trim(); //單別
        string strFormNumber = txtFormNumber.Text.Trim(); //單號
        string strP_Number = txtP_Number.Text.Trim(); //子單號

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        DataTable dtList = BLL_ERP.GetSerialData(strCompany, null, null, strFormType, strFormNumber, null, strP_Number);

        dtList.Columns.Remove("項次");
        dtList.Columns.Remove("狀態");
        dtList.Columns.Remove("單別");
        dtList.Columns.Remove("單號");
        dtList.Columns.Remove("Reason");

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }

    protected void btnExport1_Click(object sender, EventArgs e)
    {
        //資料變數
        string strCompany = ddlCompany.SelectedValue; //公司別
        string strFormType = txtFormType.Text.Trim(); //單別
        string strFormNumber = txtFormNumber.Text.Trim(); //單號

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        DataTable dtList = BLL_ERP.ExportOrderData(strCompany, strFormType, strFormNumber);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}