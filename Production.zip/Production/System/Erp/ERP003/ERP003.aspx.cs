﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using UHR;
using UHR.Util;

public partial class ERP003 : UHR.BasePage.BasePage
{
    ReportDocument rep = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            DataBind();
        else
            btnQuery_Click(sender, e);
    }

    public override void DataBind()
    {
        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();

        txtType.Text = "Parts and accessories of image projectors";
    }

    //查詢動作
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //變數
        string 公司別 = ddlCompany.SelectedValue;
        string 單別 = txtFormType.Text.Trim();
        string 單號 = txtFormNumber.Text.Trim();
        string 確認碼 = ddlAudit.SelectedValue.Trim();
        string strNote = txtNote.Text.Trim();
        string strType = txtType.Text.Trim();

        if (公司別 != "")
        {
            //取得與設定來源
            DataSet ds = null;
            string strSource = rblSource.SelectedValue.Trim();
            if (strSource == "銷貨單" || strSource == "借入歸還單" || strSource == "暫出單")
            {
                //取得單據來源
                if (rblSource.SelectedValue == "銷貨單")
                {
                    if (單別 == "2320")
                    {
                        ds = BLL_ERP.GetInvoiceFormRMA(公司別, 單別, 單號, 確認碼);
                        strNote = "Sample of no commercial value, value for customs purpose only.\r\n" + strNote; //加上前置字段
                    }
                    else
                    {
                        ds = BLL_ERP.GetInvoiceFormData(公司別, 單別, 單號, 確認碼);
                    }

                    rep.Load(Tool.GetPhysicalPath + 公司別 + "_0.rpt"); //設定報表路徑
                }
                else if (rblSource.SelectedValue == "借入歸還單")
                {
                    ds = BLL_ERP.GetInvoiceFromINVTH(公司別, 單別, 單號, 確認碼);

                    strNote = "Sample of no commercial value, value for customs purpose only.\r\n" + strNote; //加上前置字段

                    rep.Load(Tool.GetPhysicalPath + 公司別 + "_0.rpt"); //設定報表路徑
                }
                else if (rblSource.SelectedValue == "暫出單")
                {
                    if (公司別 == "Arclite")
                    {
                        ds = BLL_ERP.GetInvoiceFromINVTF(公司別, 單別, 單號, 確認碼);
                        rep.Load(Tool.GetPhysicalPath + 公司別 + "_0.rpt"); //設定報表路徑
                    }
                    else if (公司別 == "UHRlamps")
                    {
                        ds = BLL_ERP.GetInvoiceFromINVTF(公司別, 單別, 單號, 確認碼);
                        rep.Load(Tool.GetPhysicalPath + 公司別 + "_暫出單.rpt"); //設定報表路徑
                    }
                }
            }
            else if (strSource == "銷退單")
            {
                ds = BLL_ERP.GetInvoiceFormCOPTI(公司別, 單別, 單號, 確認碼);

                rep.Load(Tool.GetPhysicalPath + "ERP003_1.rpt"); //設定報表路徑
            }

            //判斷有無資料
            if (ds.Tables["Invoice單頭"].Rows.Count == 0)
            {
                MessageInfo.ShowMessage(false, "無此單據，請重新確認!");
                crViewer.Visible = false;
            }
            else
            {
                //報表相關
                crViewer.Visible = true;
                crViewer.HasExportButton = true;
                rep.SetDataSource(ds);
                rep.SetParameterValue("Note", strNote); //設定參數
                rep.SetParameterValue("Type", strType); //設定參數
                crViewer.ReportSource = rep;
            }
        }
    }

    //匯出動作
    protected void btnExport_Click(object sender, EventArgs e)
    {
        //匯出Excel檔
        rep.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.Excel, Response, false, "Invoice");
    }

    protected void Page_Unload(object sender, EventArgs e)
    {
        //釋放報表資源
        rep.Close();
        rep.Dispose();
    }
}