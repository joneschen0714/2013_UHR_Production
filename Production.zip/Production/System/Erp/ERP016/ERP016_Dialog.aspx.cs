﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class ERP016_Dialog : UHR.BasePage.BasePage
{
    private string M_SerialNo;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/json2.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_SerialNo = Tool.CheckQueryString("sn"); //序號

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        lbl序號.Text = M_SerialNo; //顯示序號

        DataTable dtRecord = BLL_ERP.GetSerialData(null, null, M_SerialNo, null, null, null, null);

        //循序讀取序號相關記錄
        int iIndex = 1;
        foreach (DataRow row in dtRecord.Rows)
        {
            string 公司別, 狀態, 單別, 單號, 項次;
            公司別 = row["公司別"].ToString();
            狀態 = row["狀態"].ToString();
            單別 = row["單別"].ToString();
            單號 = row["單號"].ToString();
            項次 = row["項次"].ToString();

            liItems.Text += "<tr>" +
                                "<td>" + iIndex.ToString() + "</td>" +
                                "<td>" + 公司別 + "</td>" +
                                "<td>" + 狀態 + "</td>" +
                                "<td>" + 單別 + "</td>" +
                                "<td>" + 單號 + "</td>" +
                                "<td>" + 項次 + "</td>" +
                            "</tr>";

            iIndex++; //累加項目
        }
    }
}