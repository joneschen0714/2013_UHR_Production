﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Xml;
using UHR;
using UHR.Util;
using System.Linq;

public partial class ERP016 : UHR.BasePage.BasePage
{
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strFormClass = txtFormClass.Text.Trim(); //製令單別
        string strFormNumber = txtFormNumber.Text.Trim(); //製令單號
        string strSerialNoList = txtSerialNoList.Text.Trim(); //序號清單

        //驗証
        bool bCheck = false;
        if (strFormClass != "" && strFormNumber != "") { bCheck = true; }
        if (strSerialNoList != "") { bCheck = true; }
        if (bCheck == false) { MessageInfo.ShowMessage(false, "請輸入搜尋條件"); return; }

        //取得資料來源
        DataTable dtSerialNoList = BLL_ERP.GetSerialHead(null, strSerialNoList, strFormClass, strFormNumber);

        //判斷有無資料列
        if (dtSerialNoList.Rows.Count > 0)
        {
            //循序讀取序號
            int iIndex = 1;
            StringBuilder sb = new StringBuilder();
            foreach (DataRow rowSerialNo in dtSerialNoList.Rows)
            {
                //變數
                string strProductNo = rowSerialNo["品號"].ToString();
                string strSerialNo = rowSerialNo["序號"].ToString();
                int iCount = Convert.ToInt32(rowSerialNo["單據數"]);

                //若有單據記錄，則顯示按鈕
                string strViewHtml = "";
                if (iCount > 0)
                    strViewHtml = "<a style='cursor:pointer;' onclick=\"OpenItemDialog('" + strSerialNo + "')\">View</a>";

                //串接項目內容
                string strItem = "<tr>" +
                                    "<td>" + iIndex.ToString() + "</td>" +
                                    "<td>" + strProductNo + "</td>" +
                                    "<td>" + strSerialNo + "</td>" +
                                    "<td>" + strViewHtml + "</td>" +
                                 "</tr>";

                sb.Append(strItem); //累加項目
                iIndex++; //累加項次
            }

            liSerialNoItem.Text = sb.ToString(); //顯示內容
        }
        else
        {
            MessageInfo.ShowMessage(false, "查無序號資料!");
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strFormClass = txtFormClass.Text.Trim(); //製令單別
        string strFormNumber = txtFormNumber.Text.Trim(); //製令單號
        string strSerialNoList = txtSerialNoList.Text.Trim(); //序號清單

        //驗証
        bool bCheck = false;
        if (strFormClass != "" && strFormNumber != "") { bCheck = true; }
        if (strSerialNoList != "") { bCheck = true; }
        if (bCheck == false) { MessageInfo.ShowMessage(false, "請輸入搜尋條件"); return; }

        DataTable dtList = BLL_ERP.ExportSerialNoHistory(strSerialNoList, strFormClass, strFormNumber); //資料來源

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "SerialNoHistory.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}