﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using UHR;
using UHR.Util;

public partial class PackingItem : UHR.BasePage.BasePage
{
    //全域變數
    public string M_公司別, M_單號, M_Carton;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/JSLINQ.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/json2.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_公司別 = Tool.CheckQueryString("company");
        M_單號 = Tool.CheckQueryString("no");
        M_Carton = Tool.CheckQueryString("carton");

        if (!IsPostBack)
        {
            lblCarton.Text = M_Carton;

            DataBind();
            gv_GridDataBind(sender, e);
        }
    }

    public override void DataBind()
    {
        //取得資料來源
        DataTable dt = BLL_Shipping.GetPackingItems(M_公司別, M_單號, M_Carton);

        //轉換JSON格式
        JObject jo = new JObject();
        JArray ja = new JArray();
        foreach (DataRow row in dt.Rows)
        {
            JObject j = new JObject();
            j.Add("Type", Convert.ToString(row["Type"]));
            j.Add("ERPClass", Convert.ToString(row["BaseClass"]));
            j.Add("ERPNumber", Convert.ToString(row["BaseNumber"]));
            j.Add("ERPItemNo", Convert.ToString(row["BaseItemNo"]));
            j.Add("ProductNo", Convert.ToString(row["ProductNo"]));
            j.Add("Qty", Convert.ToInt32(row["Qty"]));

            ja.Add(j);
        }
        jo.Add("items", ja);

        //儲存至Hidden
        hiddenJSON.Value = JsonConvert.SerializeObject(jo);
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_Shipping.GetPackingSource(M_公司別, M_單號, M_Carton, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("來源單號", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("品號", "ProductNo", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客號品號", "CustomerPN", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("數量", "Qty", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("已包裝量", "sQty", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("包裝量", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtList;
        gv.DataBind();

        //驗証
        if (recordCount == 0) { MessageInfo.ShowMessage(false, "無符合資料，請確認條件後再試一次!"); }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
        TableCell cellERPNum = gv.GetTableCell(e.Row, "來源單號", false);
        TableCell cellPackingQty = gv.GetTableCell(e.Row, "包裝量", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strERPClass = Convert.ToString(rowView["BaseClass"]);
            string strERPNumber = Convert.ToString(rowView["BaseNumber"]);
            string strERPItemNo = Convert.ToString(rowView["BaseItemNo"]);
            string strProductNo = Convert.ToString(rowView["ProductNo"]);

            //增加標記值至Row
            e.Row.Attributes.Add("ERPClass", strERPClass);
            e.Row.Attributes.Add("ERPNumber", strERPNumber);
            e.Row.Attributes.Add("ERPItemNo", strERPItemNo);
            e.Row.Attributes.Add("ProductNo", strProductNo);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //來源單號
            cellERPNum.Text = strERPClass + "-" + strERPNumber;

            //包裝量
            cellPackingQty.Text = "<input name='PackingQty' type='text' size='4' />";
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //刪除箱號下的所有項目
        BLL_Shipping.DeletePackingItem(null, M_公司別, M_單號, M_Carton);

        //把JSON記錄轉成物件
        JObject objJSON = JObject.Parse(hiddenJSON.Value);
        var result = from r in objJSON["items"].Children() select r;

        foreach (var r in result)
        {
            string Type = r["Type"].ToString().Trim('"');
            string ERPClass = r["ERPClass"].ToString().Trim('"');
            string ERPNumber = r["ERPNumber"].ToString().Trim('"');
            string ERPItemNo = r["ERPItemNo"].ToString().Trim('"');
            string ProductNo = r["ProductNo"].ToString().Trim('"');
            string Qty = r["Qty"].ToString().Trim('"');

            //驗証數量格式是否正確
            int iQty;
            int.TryParse(Qty, out iQty);
            if (iQty > 0)
            {
                BLL_Shipping.InsertPackingItem(M_公司別, M_單號, Type, M_Carton, ERPClass, ERPNumber, ERPItemNo, ProductNo, Qty);
            }
        }

        liScript.Text = "<script type='text/javascript'>" +
                            "alert('作業成功!'); $(parent.window.dialogArguments.window.document).find('#btnReload')[0].click(); WindowClose();" +
                        "</script>";
    }
}