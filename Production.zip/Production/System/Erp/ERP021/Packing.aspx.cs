﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using UHR;
using UHR.Util;

public partial class Packing : UHR.BasePage.BasePage
{
    //全域變數
    private string M_公司別, M_單號, M_結案碼;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.AddAt(0, new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.AddAt(1, new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        hiddenCompany.Value = M_公司別 = Tool.CheckQueryString("company");
        M_單號 = Tool.CheckQueryString("no");
        M_結案碼 = Tool.CheckQueryString("status");

        if (!IsPostBack)
        {
            mv.ActiveViewIndex = 0;
            lblFormNum.Text = M_單號;

            //包裝中才可編輯，預設不可編輯
            switch (M_結案碼)
            {
                case "1":
                    btnAddItem.Visible = true;
                    btnDel.Visible = true;
                    btnCopy.Visible = true;
                    break;

                default:
                    btnAddItem.Visible = false;
                    btnDel.Visible = false;
                    btnCopy.Visible = false;
                    break;
            }

            CreateList(new object(), new EventArgs());
        }
    }

    protected void CreateList(object sender, EventArgs e)
    {
        CheckPackingData();

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_Shipping.GetCartonItem(M_公司別, M_單號, null, 1, int.MaxValue, out recordCount);

        // 建立資料列表
        int index = 1;
        string strItem = "";
        foreach (DataRow row in dtList.Rows)
        {
            //包裝中
            string strManageBtn = "";
            if (M_結案碼 == "1")
            {
                strManageBtn += "<img src='../../../images/ToolBar/Edit.gif' align='absmiddle' style='cursor:pointer' title='編輯' onclick=\"ModifyCarton('" + row["CartonNo"].ToString() + "')\" /> " +
                                "<img src='../../../images/ToolBar/item.png' align='absmiddle' style='cursor:pointer' title='子項目' onclick='ModifyItem(this)' /> ";
            }

            strItem += string.Format("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td></tr>",
                                    index,
                                    row["PalletNo"],
                                    row["CartonNo"],
                                    row["G.W"],
                                    row["N.W"],
                                    row["W/M"],
                                    row["Qty"],
                                    strManageBtn,
                                    "<input name='checkItem' type='checkbox' onclick='SelectRemoveItem(this)' />");
            index++; //累加項次
        }

        liItem.Text = strItem;
    }

    protected void CheckPackingData()
    {
        string IdArray = "", html = "";

        //取得Packing項目
        DataTable dtPackingItem = BLL_Shipping.GetPackingItems(M_公司別, M_單號, null);

        //依各單據的品號項次做數量加總
        var result = from r in dtPackingItem.AsEnumerable()
                     where r.Field<string>("Type") == "General"
                     group r by new { BaseClass = r.Field<string>("BaseClass"), BaseNumber = r.Field<string>("BaseNumber"), BaseItemNo = r.Field<string>("BaseItemNo"), ProductNo = r.Field<string>("ProductNo") } into t
                     select new { BaseClass = t.Key.BaseClass, BaseNumber = t.Key.BaseNumber, BaseItemNo = t.Key.BaseItemNo, ProductNo = t.Key.ProductNo, SubQty = t.Sum(a => a.Field<int>("Qty")) };

        //取得出貨通知單項目
        int recordCount;
        DataTable dtShippingItem = BLL_Shipping.GetShippingAdviseItemList(M_公司別, M_單號, 1, int.MaxValue, out recordCount);

        //循序讀取Packing資料列
        foreach (var item in result)
        {
            //檢查Packing項目是否存在於出貨項目
            string strFilter = string.Format("BaseClass='{0}' AND BaseNumber='{1}' AND BaseItemNo='{2}' AND ProductNo='{3}'", item.BaseClass, item.BaseNumber, item.BaseItemNo, item.ProductNo);
            DataRow[] rowShippingItem = dtShippingItem.Select(strFilter);

            //檢查包裝項目是否存在
            if (rowShippingItem.Length > 0)
            {
                //檢查已包裝量是否大於出貨數量
                DataRow row = rowShippingItem[0];
                if (item.SubQty > Convert.ToInt32(row["Qty"]))
                {
                    html += string.Format("<nobr><b>數量不符:</b> 品號:{0}, 單別:{1}; 單號:{2}, 項次:{3}, 出貨數量:{4}, 包裝數量:{5}</nobr><br/>", item.ProductNo, item.BaseClass, item.BaseNumber, item.BaseItemNo, Convert.ToInt32(row["Qty"]), item.SubQty);
                }
            }
            else
            {
                //不存在卻已包裝的項目
                DataRow[] rows = dtPackingItem.Select(strFilter);
                foreach (DataRow row in rows)
                {
                    IdArray += "," + row["Id"].ToString();
                    html += string.Format("<nobr><b>項目不存在:</b> 品號:{0}, 箱號:{1}, 數量:{2}, 單別:{3}, 單號:{4}, 項次:{5}</nobr><br/>", row["ProductNo"], row["CartonNo"], row["Qty"], row["BaseClass"], row["BaseNumber"], row["BaseItemNo"]);
                }
            }
        }

        //顯示訊息區域
        if (html != "")
        {
            lblPackingMsg.Text = html;
            hiddenPackingMsg.Value = IdArray.Trim(',');
        }

        palPackingMsg.Visible = (html != "");
    }

    protected void btnClearErrPacking_Click(object sender, EventArgs e)
    {
        //循序刪除不存在的Packing項目
        string IdList = hiddenPackingMsg.Value;

        if (IdList != "")
            foreach (string Id in IdList.Split(','))
            {
                BLL_Shipping.DeletePackingItem(Id, null, null, null);
            }

        CreateList(sender, e);
    }





    protected void btnModifyCarton_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 1;

        string strCartonNo = hiddenValue.Value.Trim(); //箱號

        if (string.IsNullOrEmpty(strCartonNo))
        {
            //設定值
            txtPallet.Text = "";
            txtCarton.Text = "";
            txtWM.Text = "";
            txtGW.Text = "";
        }
        else
        {
            //取得資料來源
            int recordCount;
            DataTable dtList = BLL_Shipping.GetCartonItem(M_公司別, M_單號, strCartonNo, 1, int.MaxValue, out recordCount);
            DataRow row = dtList.Rows[0];

            //設定值
            txtPallet.Text = row["PalletNo"].ToString();
            txtCarton.Text = row["CartonNo"].ToString();
            txtWM.Text = row["W/M"].ToString();
            txtGW.Text = row["G.W"].ToString();
        }

        //設定啟用
        txtCarton.Enabled = string.IsNullOrEmpty(strCartonNo);
    }

    protected void btnCartonOK_Click(object sender, EventArgs e)
    {
        string strCartonNo = hiddenValue.Value.Trim(); //箱號

        //取得值
        string strPallet = txtPallet.Text;
        string strCarton = txtCarton.Text;
        string strWM = txtWM.Text;
        string strGW = txtGW.Text;

        //換算NW
        double dNW = (double.Parse(strGW) / 2) + 1.5;
        dNW = Math.Round(dNW, 1, MidpointRounding.AwayFromZero);

        if (string.IsNullOrEmpty(strCartonNo))
        {
            int i = BLL_Shipping.InsertCartonItem(M_公司別, M_單號, strPallet, strCarton, strWM, strGW, dNW.ToString());

            if (i <= 0)
            {
                MessageInfo.ShowMessage(false, "寫入失敗，請檢查箱號是否已存在!");
                return;
            }
        }
        else
        {
            BLL_Shipping.EditCartonItem(M_公司別, M_單號, strPallet, strCarton, strWM, strGW, dNW.ToString());
        }

        //重新整理列表
        CreateList(new object(), new EventArgs());
        mv.ActiveViewIndex = 0;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        mv.ActiveViewIndex = 0;
        CreateList(new object(), new EventArgs());
    }
}