﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using UHR;
using UHR.Util;

public partial class ERP021 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            gv.PageIndex = 1;
            gv_GridDataBind(sender, e);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //查詢條件 (變數)
        string strCompany = ddlCompany.SelectedValue; //公司別
        string strCustomCode = txtCustomCode.Text.Trim().ToUpper();
        string strAudit = ddlAudit.SelectedValue;

        if (gv.SortExpression == "") { gv.SortExpression = "FormNo"; } //預設排序

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_Shipping.GetShippingAdviseList(strCompany, null, strCustomCode, strAudit, gv.SortingCondition, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "RowNum", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("單號", "FormNo", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("預計出貨日", "ShippingDate", true, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客戶代號", "CustomCode", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("客戶名稱", "CustomName", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("總出貨數", "TotalQty", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("已包裝數", "PackingQty", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("狀態碼", "Status", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtList;
        gv.DataBind();

        //驗証
        if (recordCount == 0) { MessageInfo.ShowMessage(false, "無符合資料，請確認條件後再試一次!"); }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellDate = gv.GetTableCell(e.Row, "預計出貨日", false);
        TableCell cellAudit = gv.GetTableCell(e.Row, "狀態碼", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string FormNum = Convert.ToString(rowView["FormNo"]);
            string CustomCode = Convert.ToString(rowView["CustomCode"]);
            int TotalQty = Convert.ToInt32(rowView["TotalQty"]);
            DateTime dtDate = Convert.ToDateTime(rowView["ShippingDate"]);
            string strAudit = Convert.ToString(rowView["Status"]);
            string strCompany = Convert.ToString(ddlCompany.SelectedValue); //公司別

            //預計出貨日
            cellDate.Text = dtDate.ToString("yyyy/MM/dd");

            //狀態碼
            if (strAudit == "0")
            {
                cellAudit.Text = "備貨中";

                //管理區
                cellManage.Text = "<img src='" + ResolveUrl("~/images/ToolBar/Edit.gif") + "' align='absmiddle' style='cursor:pointer' title='編輯' onclick=\"Modify('edit','" + FormNum + "','" + CustomCode + "', 500)\" /> " +
                                  "<img src='" + ResolveUrl("~/images/ToolBar/item.png") + "' align='absmiddle' style='cursor:pointer' title='子項目' onclick=\"Modify('list','" + FormNum + "','" + CustomCode + "', 800)\" /> ";
            }
            else if (strAudit == "1")
            {
                cellAudit.Text = "包裝中";

                //管理區
                cellManage.Text = "<img src='" + ResolveUrl("~/images/ToolBar/Edit.gif") + "' align='absmiddle' style='cursor:pointer' title='編輯' onclick=\"Modify('edit','" + FormNum + "','" + CustomCode + "', 500)\" /> " +
                                  "<img src='" + ResolveUrl("~/images/ToolBar/package.png") + "' align='absmiddle' style='cursor:pointer' title='包裝' onclick=\"Packing('" + FormNum + "','" + strAudit + "')\" /> " +
                                  "<img src='" + ResolveUrl("~/images/ToolBar/Audit.png") + "' align='absmiddle' style='cursor:pointer' title='檢查' onclick=\"Modify('sellform','" + FormNum + "','" + CustomCode + "', 500)\" /> ";
            }
            else if (strAudit == "2")
            {
                cellAudit.Text = "包裝完成";

                //管理區
                cellManage.Text = "<img src='" + ResolveUrl("~/images/ToolBar/Edit.gif") + "' align='absmiddle' style='cursor:pointer' title='編輯' onclick=\"Modify('edit','" + FormNum + "','" + CustomCode + "', 500)\" /> " +
                                  "<img src='" + ResolveUrl("~/images/ToolBar/package.png") + "' align='absmiddle' style='cursor:pointer' title='包裝' onclick=\"Packing('" + FormNum + "','" + strAudit + "')\" /> " +
                                  "<img src='" + ResolveUrl("~/images/ToolBar/Audit.png") + "' align='absmiddle' style='cursor:pointer' title='檢查' onclick=\"Modify('sellform','" + FormNum + "','" + CustomCode + "', 500)\" /> ";
            }
            else if (strAudit == "Y")
            {
                cellAudit.Text = "結案";

                //管理區
                cellManage.Text = "<img src='" + ResolveUrl("~/images/ToolBar/package.png") + "' align='absmiddle' style='cursor:pointer' title='包裝' onclick=\"Packing('" + FormNum + "','" + strAudit + "')\" /> ";
            }
            else if (strAudit == "V") cellAudit.Text = "作廢";
        }
    }
}