﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using UHR;
using UHR.Util;

public partial class ShippingAdvise : UHR.BasePage.BasePage
{
    //全域變數
    private string M_狀態, M_公司別, M_單號, M_客戶代號;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_狀態 = Tool.CheckQueryString("type");
        hiddenCompany.Value = M_公司別 = Tool.CheckQueryString("company");
        M_單號 = Tool.CheckQueryString("no");
        M_客戶代號 = Tool.CheckQueryString("c");

        //設定圖示開窗
        string strResponse = string.Format("{0}={1};{2}={3}",
                        txtCustomCode.ClientID, Server.UrlEncode("客戶代號"),
                        txtCustomName.ClientID, Server.UrlEncode("客戶全名"));
        imgCustomCode.Attributes.Add("onclick", "fn_openWindowDialog('../../../controls/ModalDialog.htm','../Modules/ERP_Customer.aspx?company=" + M_公司別 + "&v=" + strResponse + "','出貨通知單明細',600, null)");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //若有單號，則讀取原記錄
        if (M_狀態 == "add")
        {
            #region 預設值
            mv.ActiveViewIndex = 0; //顯示區域

            lblFormNumber.Text = BLL_Shipping.GetNewShippingAdviseNo(M_公司別);
            txtShippingDate.Text = DateTime.Today.ToString("yyyy/MM/dd");
            ddlStatus.SelectedValue = "N";
            ddlStatus.Enabled = false;
            hiddenOldStatus.Value = ddlStatus.SelectedValue; //記錄目前的狀態碼
            #endregion
        }
        else if (M_狀態 == "edit")
        {
            #region 設定單頭資料
            mv.ActiveViewIndex = 0; //顯示區域

            //取得資料來源
            int recordCount;
            DataTable dt = BLL_Shipping.GetShippingAdviseList(M_公司別, M_單號, null, null, null, 1, 1, out recordCount);
            DataRow row = dt.Rows[0];

            //設定值
            lblFormNumber.Text = Convert.ToString(row["FormNo"]);
            txtCustomCode.Text = Convert.ToString(row["CustomCode"]);
            txtCustomCode.Enabled = false;
            imgCustomCode.Visible = false;
            txtCustomName.Text = Convert.ToString(row["CustomName"]);
            txtCustomName.Enabled = false;
            txtShippingDate.Text = Convert.ToDateTime(row["ShippingDate"]).ToShortDateString();
            ddlStatus.SelectedValue = Convert.ToString(row["Status"]);
            hiddenOldStatus.Value = ddlStatus.SelectedValue; //記錄目前的狀態碼
            #endregion
        }
        else if (M_狀態 == "list")
        {
            mv.ActiveViewIndex = 1; //顯示區域
            lblFormNum.Text = M_單號;
            btnAddItem.Attributes.Add("onclick", "SelectItem('" + M_公司別 + "','" + M_單號 + "','" + M_客戶代號 + "')");
            CreateList(new object(), new EventArgs());
        }
        else if (M_狀態 == "sellform")
        {
            mv.ActiveViewIndex = 2; //顯示區域

            //取得資料來源
            int recordCount;
            DataTable dt = BLL_Shipping.GetShippingAdviseList(M_公司別, M_單號, null, null, null, 1, 1, out recordCount);
            DataRow row = dt.Rows[0];

            //取回出口單號
            txtSellingNumber.Text = row["outFormNum"].ToString().Replace(",", System.Environment.NewLine);
            btnCheck_Click(new object(), new EventArgs());
        }
    }

    protected void CreateList(object sender, EventArgs e)
    {
        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_Shipping.GetShippingAdviseItemList(M_公司別, M_單號, 1, int.MaxValue, out recordCount);

        // 建立資料列表
        int index = 0;
        string strItem = "";
        foreach (DataRow row in dtList.Rows)
        {
            index++;
            strItem += string.Format("<tr BaseClass='{0}' BaseNumber='{1}' BaseItemNo='{2}'><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td></tr>",
                                    row["BaseClass"],
                                    row["BaseNumber"],
                                    row["BaseItemNo"],
                                    index,
                                    Convert.ToString(row["BaseClass"]) + "-" + Convert.ToString(row["BaseNumber"]),
                                    row["ProductNo"],
                                    row["CustomerPN"],
                                    row["CustomerDESC"],
                                    row["Qty"],
                                    "<input name='checkItem' type='checkbox' onclick='SelectRemoveItem(this)' />");
        }

        liItem.Text = strItem;
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        string 單號 = lblFormNum.Text;
        string strPath = "/Temp/";

        #region 本次出貨項目
        DataTable dt = BLL_Shipping.ExportShippingAdvise(M_公司別, 單號);

        //RMA-檔案路徑設定
        string strFile = "ShippingAdvise.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);
        Tool.DataTableToCSV(dt, strFilePath);
        #endregion

        #region 未出貨項目
        //取得未結案的ERP項目
        int recordCount;
        DataTable dtItem = BLL_Shipping.GetShippingAdviseBaseItemList(M_公司別, "", "", "", M_客戶代號, 1, int.MaxValue, out recordCount);

        //轉成CSV檔
        string strFile1 = "BackOrder.csv";
        string strFilePath1 = Server.MapPath("~" + strPath + strFile1);
        Tool.DataTableToCSV(dtItem, strFilePath1);
        #endregion

        #region 壓縮檔案
        //壓縮檔案
        List<string> fileList = new List<string>();
        fileList.Add(strFilePath);
        fileList.Add(strFilePath1);
        Tool.Zip(fileList, Server.MapPath("~/Temp/ShippingAdvise.zip"), 5, 5);
        #endregion

        //刪除暫存檔
        System.IO.File.Delete(strFilePath);
        System.IO.File.Delete(strFilePath1);

        //下載壓縮檔
        Response.Redirect("~/Temp/ShippingAdvise.zip");
    }

    protected void btnCheck_Click(object sender, EventArgs e)
    {
        //更新出口單號
        string text = txtSellingNumber.Text.Replace(System.Environment.NewLine, ",");
        BLL_Shipping.ModifyShippingSellingNumber(M_公司別, M_單號, text);

        //取得ERP單據來源
        text = Tool.SetSplitSingleMark(text, "'", ',');
        DataTable dtSource = BLL_Shipping.GetSellingFormData(M_公司別, text);

        //取得出貨通知單單身
        int recordCount;
        DataTable dtList = BLL_Shipping.GetShippingAdviseItemList(M_公司別, M_單號, 1, int.MaxValue, out recordCount);

        #region 更新出貨通知單出貨數於dtSource，若不存在新增
        foreach (DataRow row in dtList.Rows)
        {
            string strFilter = string.Format("來源單別='{0}' AND 來源單號='{1}' AND 來源項次='{2}' AND 品號='{3}'", row["BaseClass"], row["BaseNumber"], row["BaseItemNo"], row["ProductNo"]);
            DataRow[] rowsResult = dtSource.Select(strFilter);

            if (rowsResult.Length > 0)
            {
                rowsResult[0]["數量1"] = Convert.ToInt32(row["Qty"]);
            }
            else
            {
                dtSource.Rows.Add(row["BaseClass"], row["BaseNumber"], row["BaseItemNo"], row["ProductNo"], DBNull.Value, row["Qty"]);
            }
        }
        #endregion

        //顯示資料列
        string strItem = "";
        foreach (DataRow row in dtSource.Rows)
        {
            string 數量 = row["數量"].ToString();
            string 數量1 = row["數量1"].ToString();

            string img = "";
            if (數量 != 數量1) { img = "<img align='absmiddle' src='../../../images/error.png' />"; }

            strItem += string.Format("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td></tr>", row["來源單別"], row["來源單號"], row["來源項次"], row["品號"], 數量, 數量1, img);
        }

        liSell.Text = strItem;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        #region 寫入單頭
        //變數
        string 單號 = lblFormNumber.Text;
        string 客戶代號 = txtCustomCode.Text.ToUpper().Trim();
        string 客戶名稱 = txtCustomName.Text;
        DateTime 預計出貨日 = Convert.ToDateTime(txtShippingDate.Text);
        string 狀態碼 = ddlStatus.SelectedValue;

        //呼叫邏輯層
        BLL_Shipping.ModifyShippingAdvise(M_公司別, 單號, 客戶代號, 客戶名稱, 預計出貨日, 狀態碼);
        #endregion

        //顯示訊息
        liScript.Text = "<script type='text/javascript'>" +
                            "alert('作業成功!'); $(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();" +
                        "</script>";
    }
}