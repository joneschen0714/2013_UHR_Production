﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using UHR;
using UHR.Util;

public partial class ShippingAdviseItem : UHR.BasePage.BasePage
{
    //全域變數
    private string M_公司別, M_單號, M_客戶代號;
    private DataTable dtItemList;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/JSLINQ.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/json2.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_公司別 = Tool.CheckQueryString("company");
        M_單號 = Tool.CheckQueryString("no");
        M_客戶代號 = Tool.CheckQueryString("c");

        if (!IsPostBack)
        {
            DataBind();
            gv_GridDataBind(sender, e);
        }
    }

    public override void DataBind()
    {
        //取得資料來源
        int recordCount;
        dtItemList = BLL_Shipping.GetShippingAdviseItemList(M_公司別, M_單號, 1, int.MaxValue, out recordCount);

        //轉換JSON格式
        JObject jo = new JObject();
        JArray ja = new JArray();
        foreach (DataRow row in dtItemList.Rows)
        {
            JObject j = new JObject();
            j.Add("BaseClass", Convert.ToString(row["BaseClass"]));
            j.Add("BaseNumber", Convert.ToString(row["BaseNumber"]));
            j.Add("BaseItemNo", Convert.ToString(row["BaseItemNo"]));
            j.Add("Qty", Convert.ToInt32(row["Qty"]));

            ja.Add(j);
        }
        jo.Add("items", ja);

        //儲存至Hidden
        hiddenJSON.Value = JsonConvert.SerializeObject(jo);

        hiddenRemark.Value = "{\"items\":[]}"; //初始化Json
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        gv.PageIndex = 1;
        gv_GridDataBind(sender, e);
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //來源別
        string strFormClass = txtFormClass.Text.Trim();
        string strFormNo = txtFormNo.Text.Trim();

        //取得資料來源
        int recordCount;
        DataTable dtList = BLL_Shipping.GetShippingAdviseBaseItemList(M_公司別, M_單號, strFormClass, strFormNo, M_客戶代號, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("來源單號", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("品號", "品號", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("品名", "品名", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("數量", "數量", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("已交數量", "已交數量", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn("本次出貨數", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
        gv.AddColumn("備註", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dtList;
        gv.DataBind();

        //驗証
        if (recordCount == 0) { MessageInfo.ShowMessage(false, "無符合資料，請確認條件後再試一次!"); }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
        TableCell cellBaseFormNo = gv.GetTableCell(e.Row, "來源單號", false);
        TableCell cellAddQty = gv.GetTableCell(e.Row, "已交數量", false);
        TableCell cellThisQty = gv.GetTableCell(e.Row, "本次出貨數", false);
        TableCell cellRemark = gv.GetTableCell(e.Row, "備註", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            int iShipmentQty = 0, iTotalQty = 0;

            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string BaseClass = Convert.ToString(rowView["來源單別"]).Trim();
            string BaseNumber = Convert.ToString(rowView["來源單號"]).Trim();
            string BaseItemNo = Convert.ToString(rowView["來源項次"]).Trim();
            int.TryParse(rowView["數量"].ToString(), out iTotalQty);
            int.TryParse(rowView["已交數量"].ToString(), out iShipmentQty);
            string Remark = Convert.ToString(rowView["備註"]).Trim();

            //增加標記值至Row
            e.Row.Attributes.Add("BaseClass", BaseClass);
            e.Row.Attributes.Add("BaseNumber", BaseNumber);
            e.Row.Attributes.Add("BaseItemNo", BaseItemNo);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //來源單號
            cellBaseFormNo.Text = BaseClass + "-" + BaseNumber;

            //已交數量
            cellAddQty.Text = iShipmentQty.ToString();

            //本次出貨數
            int sQty = (iTotalQty - iShipmentQty);
            cellThisQty.Text = "<input name='txtQty' type='text' size='4' sQty='" + sQty.ToString() + "' />";

            //本次出貨數
            cellRemark.Text = "<input name='txtRemark' type='text' size='12' value='" + Remark + "' />";
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        #region 儲存出貨通知單項目
        //刪除單據所有項目
        BLL_Shipping.DeleteShippingAdviseItem(M_公司別, M_單號, null, null, null, null);

        //把JSON記錄轉成物件
        JObject objJSON = JObject.Parse(hiddenJSON.Value);

        //LINQ-找出符合資料
        var result = from r in objJSON["items"].Children() select r;
        foreach (var r in result)
        {
            string BaseClass = r["BaseClass"].ToString().Trim('"');
            string BaseNumber = r["BaseNumber"].ToString().Trim('"');
            string BaseItemNo = r["BaseItemNo"].ToString().Trim('"');
            string Qty = r["Qty"].ToString().Trim('"');

            //驗証數量格式是否正確
            int iQty;
            int.TryParse(Qty, out iQty);
            if (iQty > 0)
                BLL_Shipping.InsertShippingAdviseItem(M_公司別, M_單號, M_客戶代號, BaseClass, BaseNumber, BaseItemNo, iQty); //新增單身項目
        }
        #endregion

        #region 記錄備註原因
        //把JSON記錄轉成物件
        JObject objJSON1 = JObject.Parse(hiddenRemark.Value);

        //LINQ-找出符合資料
        var result1 = from r in objJSON1["items"].Children() select r;
        foreach (var r in result1)
        {
            string BaseClass = r["BaseClass"].ToString().Trim('"');
            string BaseNumber = r["BaseNumber"].ToString().Trim('"');
            string BaseItemNo = r["BaseItemNo"].ToString().Trim('"');
            string Remark = r["Remark"].ToString().Trim('"');

            //驗証數量格式是否正確
            BLL_Shipping.ModifyRemark(M_公司別, BaseClass, BaseNumber, BaseItemNo, Remark); //記錄(未)出貨原因
        }
        #endregion

        liScript.Text = "<script type='text/javascript'>" +
                            "alert('作業成功!'); $(parent.window.dialogArguments.window.document).find('#btnReload')[0].click(); WindowClose();" +
                        "</script>";
    }
}