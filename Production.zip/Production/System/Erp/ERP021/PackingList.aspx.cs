﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using CrystalDecisions.CrystalReports.Engine;
using UHR;
using UHR.Util;

public partial class System_Erp_ERP021_PackingList : UHR.BasePage.BasePage
{
    private string M_公司別, M_類別, M_單號;
    ReportDocument rep = new ReportDocument();

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        M_公司別 = Tool.CheckQueryString("company");
        M_類別 = Tool.CheckQueryString("t");
        M_單號 = Tool.CheckQueryString("no");

        if (!IsPostBack)
        {
            DataBind();
        }

        btnQuery_Click(sender, e);
    }

    public new void DataBind()
    {
        //載入替代公司別
        CompanyCollection c = new CompanyCollection();
        ddlReCompany.DataSource = c;
        ddlReCompany.DataBind();
    }

    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (M_類別 == "packinglist")
        {
            palPackingList.Visible = true; //顯示區域

            DataSet ds = BLL_Shipping.GetPackingListFormData(M_公司別, M_單號, ddlReCompany.SelectedValue, txtReCustomCode.Text);

            string strRptName = "";
            switch (rblDelivered.SelectedValue)
            {
                case "air":
                    strRptName = "PackingList_air.rpt"; //空運
                    break;
                case "sea":
                    strRptName = "PackingList_sea.rpt"; //海運
                    break;
            }

            Company c = CompanyCollection.Get(M_公司別); //取得對應公司別

            //報表相關
            crViewer.Visible = true;
            rep.Load(Tool.GetPhysicalPath + strRptName);
            rep.SetDataSource(ds);
            rep.SetParameterValue("InvoiceNo", txtInvoiceNo.Text); //InvoiceNo
            rep.SetParameterValue("PackingUnit", c.PackingUnit.ToString()); //包裝單位
            rep.SetParameterValue("Remark",txtRemark.Text);
            crViewer.ReportSource = rep;
        }
        else if (M_類別 == "shippingmarks")
        {
            DataSet ds = BLL_Shipping.GetPackingListFormData(M_公司別, M_單號, ddlReCompany.SelectedValue, txtReCustomCode.Text);

            //報表相關
            crViewer.Visible = true;
            rep.Load(Tool.GetPhysicalPath + "ShippingMarks.rpt");
            rep.SetDataSource(ds);
            crViewer.ReportSource = rep;
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //匯出Excel檔
        rep.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.Excel, Response, false, "Packing List");
    }

    protected void Page_Unload(object sender, EventArgs e)
    {
        //釋放報表資源
        rep.Close();
        rep.Dispose();
    }
}
