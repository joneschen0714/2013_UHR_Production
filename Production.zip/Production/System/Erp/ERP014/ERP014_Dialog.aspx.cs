﻿using System;
using System.Data;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using System.Linq;
using UHR;
using UHR.Util;

public partial class ERP014_Dialog : UHR.BasePage.BasePage
{
    private string M_Company, M_FormType, M_FormNum, M_ItemNo, M_Qty, M_ProductNo, M_IsCheck;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/json2.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_Company = Tool.CheckQueryString("company"); //公司別
        M_FormType = Tool.CheckQueryString("formtype"); //單別
        M_FormNum = Tool.CheckQueryString("formnum"); //單號
        M_ItemNo = Tool.CheckQueryString("itemno"); //項次
        M_Qty = Tool.CheckQueryString("qty"); //數量
        M_ProductNo = Tool.CheckQueryString("productno"); //品號
        M_IsCheck = Tool.CheckQueryString("ischeck"); //確認碼

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //若單據為確認，則顯示按鈕
        btnSave.Visible = (M_IsCheck == "N");
        btnImport.Visible = (M_IsCheck == "N");

        lbl單身項目.Text = M_ItemNo; //顯示項次
        lbl單身品號.Text = M_ProductNo; //顯示品號

        DataTable dtSerialNo = BLL_ERP.GetSerialData(M_Company, M_ProductNo, null, M_FormType, M_FormNum, lbl單身項目.Text.Trim(), null); //序號資料

        //建立清單
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < int.Parse(M_Qty); i++)
        {
            //序號
            string strSearialNo = "", strProductNo = "";
            if (dtSerialNo.Rows.Count > i)
            {
                strSearialNo = dtSerialNo.Rows[i]["序號"].ToString().Trim();
                strProductNo = M_ProductNo;
            }

            //序號項目Html
            string strItemSN = "<tr><td>{項目}</td>" +
                               "<td><input name='txtSN' type='text' jTag='txtSN' value='{序號}' onchange='FillSearialNoToTextBox(this, event)' onkeydown='CheckEnter(this, event)' style='width:120px;' /></td>" +
                               "<td><span jTag='span品號'>{品號}</span></td><tr>";

            //累加項目
            sb.Append(strItemSN.Replace("{項目}", Convert.ToString(i + 1))
                               .Replace("{序號}", strSearialNo)
                               .Replace("{品號}", strProductNo));
        }
        liItems.Text = sb.ToString();
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        BLL_ERP.DeleteSerialNo(M_Company, null, null, null, M_FormType, M_FormNum, lbl單身項目.Text.Trim(), null); //刪除此單據的品號記錄

        string strVal = txtJSON.Text.TrimEnd('|');
        string[] strItems = strVal.Split('|');

        string strMessage = "";
        foreach (string strItem in strItems)
        {
            if (strItem != "")
            {
                string[] myItem = strItem.Split(',');

                string strSerialNo = myItem[0];
                string strProductNo = (myItem[1] == "" ? lbl單身品號.Text.Trim() : myItem[1]); //若無品號則預設為單身品號

                int iResult = BLL_ERP.ModifySerialNo(M_Company, strProductNo, strSerialNo, null, null, "借入歸還單", M_FormType, M_FormNum, lbl單身項目.Text.Trim(), null, null, null);

                if (iResult <= 0)
                {
                    strMessage += strSerialNo + "寫入錯誤!<br/>";
                }
            }
        }

        //處理結果
        if (string.IsNullOrEmpty(strMessage))
        {
            base.SetPageLoadScript("$(window.opener.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
        else
        {
            MessageInfo.ShowMessage(false, strMessage);
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        string strMessage = "";

        //上傳檔案
        string strFileName = "ERP014.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName); //取得上傳檔案內容

        #region 檢查是否有重覆的序號
        var result = from r in dtCSV.AsEnumerable() group r by r["序號"] into g where g.Count() > 1 select g;

        foreach (var item in result)
            strMessage += string.Format("序號 {0} 重覆<br/>", item.Key);

        if (strMessage != "")
        {
            MessageInfo.ShowMessage(false, strMessage);
            return;
        }
        #endregion

        #region 檢查數量
        int iSerialNoCount = dtCSV.Rows.Count; //序號數量
        if (iSerialNoCount > int.Parse(M_Qty))
        {
            strMessage = string.Format("作業錯誤，序號數量 {0} 大於項目數量 {1}", iSerialNoCount, M_Qty);
            MessageInfo.ShowMessage(false, strMessage);
            return;
        }
        #endregion

        #region 依序寫入序號
        BLL_ERP.DeleteSerialNo(M_Company, null, null, null, M_FormType, M_FormNum, M_ItemNo, null); //刪除此單據的品號記錄

        foreach (DataRow row in dtCSV.Rows)
        {
            string strSerialNo = row["序號"].ToString();

            int iResult = BLL_ERP.ModifySerialNo(M_Company, M_ProductNo, strSerialNo, null, null, "借入歸還單", M_FormType, M_FormNum, M_ItemNo, null, null, null);

            if (iResult <= 0) { strMessage += strSerialNo + "寫入錯誤，可能原因為品號錯誤!<br/>"; }
        }
        #endregion

        //處理結果
        if (strMessage != "") { MessageInfo.ShowMessage(false, strMessage); }
        else
        {
            base.SetPageLoadScript("$(window.opener.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();");
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //取得序號資料 & 資料轉換
        DataTable dtSerialNo = BLL_ERP.GetSerialData(M_Company, M_ProductNo, null, M_FormType, M_FormNum, M_ItemNo, null);
        DataTable dtNew = dtSerialNo.DefaultView.ToTable(false, "序號");

        //匯出CSV檔
        Tool.DataTableToCSV(dtNew, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}