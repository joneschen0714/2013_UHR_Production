﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class ERP017 : UHR.BasePage.BasePage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //CSV下載路徑
        string strPath = "~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode("/System/Erp/ERP017/") + "&FileName=" + Server.UrlEncode("報價單格式.csv");

        //設定GridView工具列
        Literal liToolBar = (Literal)gv.FindControl("liToolBar");
        liToolBar.Text = string.Format("<a href=\"{0}\">CSV格式下載</a>　", ResolveUrl(strPath));

        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //查詢條件 (變數)
            string strCompany = ddlCompany.SelectedValue; //公司別
            string strFormType = txtFormType.Text.Trim();
            string strFormNum = txtFormNum.Text.Trim();
            string strAudit = ddlAudit.SelectedValue;
            string strCustomCode = txtCustomCode.Text.Trim().ToUpper();
            string strUserCode = txtUserCode.Text.Trim().ToUpper();

            //取得資料來源
            int recordCount;
            DataTable dtList = BLL_ERP.GetQuotationHeadList(strCompany, strFormType, strFormNum, strAudit, strCustomCode, strUserCode, gv.PageIndex, gv.GridView.PageSize, out recordCount);

            //增加欄位
            gv.GridView.Columns.Clear();
            gv.AddColumn("項次", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("單號", "", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("日期", "日期", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("客戶全名", "客戶全名", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("員工姓名", "員工姓名", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("備註二", "備註二", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("總數量", "總數量", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("確認碼", "確認碼", false, Unit.Empty, HorizontalAlign.Left, HorizontalAlign.Left);
            gv.AddColumn("管理", "", false, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

            //載入Grid
            gv.RowCount = recordCount;
            gv.GridView.DataSource = dtList;
            gv.DataBind();

            //驗証
            if (recordCount == 0) { MessageInfo.ShowMessage(false, "無符合資料，請確認條件後再試一次!"); }
        }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //表格欄
        TableCell cellItem = gv.GetTableCell(e.Row, "項次", false);
        TableCell cellFormNum = gv.GetTableCell(e.Row, "單號", false);
        TableCell cellDate = gv.GetTableCell(e.Row, "日期", false);
        TableCell cellAudit = gv.GetTableCell(e.Row, "確認碼", false);
        TableCell cellManage = gv.GetTableCell(e.Row, "管理", false);

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strFormType = Convert.ToString(rowView["單別"]);
            string strFormNum = Convert.ToString(rowView["單號"]);
            string strAudit = Convert.ToString(rowView["確認碼"]);

            //自動編號
            int iItem = (gv.GridView.PageSize * (gv.PageIndex - 1)) + (e.Row.RowIndex + 1);
            cellItem.Text = iItem.ToString();

            //單別單號
            cellFormNum.Text = strFormType + "-" + strFormNum;

            //日期
            cellDate.Text = cellDate.Text.Insert(4, "/").Insert(7, "/");

            //確認碼
            switch (strAudit)
            {
                case "Y":
                    cellAudit.Text = "已確認"; break;
                case "N":
                    cellAudit.Text = "未確認"; break;
                case "V":
                    cellAudit.Text = "作廢"; break;
            }

            //管理區
            cellManage.Text = "<img src='" + ResolveUrl("~/images/ToolBar/Edit.gif") + "' style='cursor:pointer' title='編輯' onclick=\"ModifyAction('" + strFormType + "','" + strFormNum + "','" + strAudit + "')\" />";
        }
    }
}