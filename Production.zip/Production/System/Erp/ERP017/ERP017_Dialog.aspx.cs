﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class ERP017_Dialog : UHR.BasePage.BasePage
{
    //全域變數
    private string M_Company, M_單別, M_單號, M_確認碼;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-ui.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_Company = Tool.CheckQueryString("company"); //公司別
        M_單別 = Tool.CheckQueryString("ft");
        M_單號 = Tool.CheckQueryString("fn");
        M_確認碼 = Tool.CheckQueryString("s");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //顯示隱藏匯入區域
        tabs.Visible = (M_確認碼 == "N");

        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
        ddlCompany.Items.Remove(ddlCompany.Items.FindByValue(M_Company));

        lblFormNum.Text = M_單別 + '-' + M_單號;

        //載入單身資料
        DataTable dt = BLL_ERP.GetQuotationBodyList(M_Company, M_單別, M_單號);
        repList.DataSource = dt;
        repList.DataBind();
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源

            //取得控制項
            Label lblItemNo = (Label)e.Item.FindControl("lblItemNo");
            Label lblProductNo = (Label)e.Item.FindControl("lblProductNo");
            Label lblCustomPN = (Label)e.Item.FindControl("lblCustomPN");
            Label lblQty = (Label)e.Item.FindControl("lblQty");
            Label lblUnitPrice = (Label)e.Item.FindControl("lblUnitPrice");
            Label lblDate = (Label)e.Item.FindControl("lblDate");

            //設定值
            lblItemNo.Text = Convert.ToString(rowView["項次"]);
            lblProductNo.Text = Convert.ToString(rowView["品號"]);
            lblCustomPN.Text = Convert.ToString(rowView["客戶品號"]);
            lblQty.Text = Convert.ToInt32(rowView["數量"]).ToString();
            lblUnitPrice.Text = Convert.ToString(rowView["單價"]).TrimEnd('0', '.');
            lblDate.Text = Convert.ToString(rowView["生效日"]).Insert(6,"/").Insert(4,"/");
        }
    }

    //匯入事件
    protected void btnImport_Click(object sender, EventArgs e)
    {
        //驗証
        if (!file.HasFile) { base.SetPageLoadScript("alert('請選擇欲匯入的檔案來源!');"); return; }

        //上傳檔案
        string strFileName = "ERP017.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        DataTable dt = Tool.GetDataSetFromCSV(strPath, strFileName); //取得上傳檔案內容
        bool bUnitPrice = chkUnitPrice.Checked; //是否帶入單價

        //新增或修改報價單資料
        bool bResult = false;
        string strMessage = "";
        BLL_ERP.ModifyQuotationFormData(M_Company, M_單別, M_單號, dt, bUnitPrice, ref bResult, ref strMessage);

        //顯示訊息
        if (strMessage == "")
        {
            base.SetPageLoadScript("alert('作業成功!'); " +
                                   "$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]').click(); " +
                                   "WindowClose();");
        }
        else
        {
            base.SetPageLoadScript("alert('" + strMessage + "');");
        }
    }

    //三角貿易 - 轉入事件
    protected void btnImport1_Click(object sender, EventArgs e)
    {
        //變數
        string strCompany = ddlCompany.SelectedValue;
        string strFormType = txtFormType.Text.Trim();
        string strFormNumber = txtFormNum.Text.Trim();

        bool bResult = false;
        string strMessage = "";
        BLL_ERP.TriangleTradeToQuotation(strCompany, strFormType, strFormNumber, M_Company, M_單別, M_單號, ref bResult, ref strMessage);

        //顯示訊息
        if (strMessage == "")
        {
            base.SetPageLoadScript("alert('作業成功，請確認客戶品號是否正確!'); " +
                                   "$(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]').click(); " +
                                   "WindowClose();");
        }
        else
        {
            base.SetPageLoadScript("alert('作業錯誤，請確定輸入資料是否正確?');");
        }
    }
}