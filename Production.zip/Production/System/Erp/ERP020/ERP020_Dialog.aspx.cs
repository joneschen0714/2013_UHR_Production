﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class ERP020_Dialog : UHR.BasePage.BasePage
{
    //全域變數
    private string M_Company, M_單別, M_單號, M_確認碼;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_Company = Tool.CheckQueryString("company"); //公司別
        M_單別 = Tool.CheckQueryString("ft");
        M_單號 = Tool.CheckQueryString("fn");
        M_確認碼 = Tool.CheckQueryString("s");

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //顯示隱藏匯入區域
        palImport.Visible = (M_確認碼 == "N");

        lblFormNum.Text = M_單別 + '-' + M_單號;
        btnImport.Attributes.Add("onclick", "return confirm('匯入時會重新覆蓋原有資料，是否確定執行?')");

        //載入單身資料
        DataTable dt = BLL_ERP.GetBorrowList(M_Company, M_單別, M_單號);
        repList.DataSource = dt;
        repList.DataBind();
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源

            //取得控制項
            Label lblItemNo = (Label)e.Item.FindControl("lblItemNo");
            Label lblProductNo = (Label)e.Item.FindControl("lblProductNo");
            Label lblDescription = (Label)e.Item.FindControl("lblDescription");
            Label lblQty = (Label)e.Item.FindControl("lblQty");

            //設定值
            lblItemNo.Text = Convert.ToString(rowView["項次"]);
            lblProductNo.Text = Convert.ToString(rowView["品號"]);
            lblDescription.Text = Convert.ToString(rowView["客戶商品描述"]);
            lblQty.Text = Convert.ToInt32(rowView["數量"]).ToString();
        }
    }

    //匯入事件
    protected void btnImport_Click(object sender, EventArgs e)
    {
        //驗証
        if (!file.HasFile) { MessageInfo.ShowMessage(false, "請選擇欲匯入之檔案來源!"); return; }

        //上傳檔案
        string strFileName = "ERP020.csv";
        string strPath = Server.MapPath("~/Temp/");
        file.SaveAs(strPath + strFileName);

        DataTable dt = Tool.GetDataSetFromCSV(strPath, strFileName); //取得上傳檔案內容

        BLL_ERP.DeleteBorrowData(M_Company, M_單別, M_單號); //刪除借入單的單身

        //循序讀取不重覆的品號
        string strMessage = "";
        string 項次 = "0000";
        foreach (DataRow row in dt.Rows)
        {
            //變數
            項次 = Tool.GetPadLeftString(項次, 1);
            string 品號 = row["品號"].ToString().Trim().ToUpper();
            int 數量 = int.Parse(row["數量"].ToString());
            string 預計歸還日 = row["預計歸還日"].ToString();
            string 備註 = row["客戶品號"].ToString();

            //格式驗証
            try { DateTime.ParseExact(預計歸還日, "yyyyMMdd", null, System.Globalization.DateTimeStyles.AllowWhiteSpaces); }
            catch { strMessage += "預計歸還日 " + 預計歸還日 + " 格式錯誤!"; break; }

            //呼叫邏輯層-寫入單身
            bool bResult = BLL_ERP.InsertBorrowData(M_Company, M_單別, M_單號, 項次, 品號, 數量, 預計歸還日, 備註);

            //若寫入單身失敗
            if (!bResult) { strMessage += "品號 " + 品號 + " 寫入錯誤!<br/>"; }
        }

        //重計單頭小計
        BLL_ERP.SubtotalBorrowQty(M_Company, M_單別, M_單號);

        //載入List
        DataBind();

        //顯示訊息
        if (strMessage == "")
        {
            liScript.Text = "<script type='text/javascript'>" +
                                "alert('作業成功!'); $(parent.window.dialogArguments.window.document).find('input[jTag=btnQuery]')[0].click(); WindowClose();" +
                            "</script>";
        }
        else
        {
            MessageInfo.ShowMessage(false, strMessage);
        }
    }
}