﻿using System;
using System.Data;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Newtonsoft.Json;
using UHR;
using UHR.Util;

public partial class ERP012_Dialog : UHR.BasePage.BasePage
{
    private string M_Company, M_FormType, M_FormNum, M_ItemNo, M_Qty, M_ProductNo;

    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/json2.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_Company = Tool.CheckQueryString("company"); //公司別
        M_FormType = Tool.CheckQueryString("formtype"); //單別
        M_FormNum = Tool.CheckQueryString("formnum"); //單號
        M_ItemNo = Tool.CheckQueryString("itemno"); //項次
        M_Qty = Tool.CheckQueryString("qty"); //數量
        M_ProductNo = Tool.CheckQueryString("productno"); //品號

        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        lbl單身項目.Text = M_ItemNo; //顯示項次
        lbl單身品號.Text = M_ProductNo; //顯示品號

        DataTable dtSerialNo = BLL_ERP.GetSerialData(M_Company, M_ProductNo, null, M_FormType, M_FormNum, lbl單身項目.Text.Trim(), null); //序號資料

        //建立清單
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < int.Parse(M_Qty); i++)
        {
            //序號
            string strSearialNo = "", strProductNo = "", strReasonQA = "", strSellingFormNumber = "";
            if (dtSerialNo.Rows.Count > i)
            {
                strSearialNo = dtSerialNo.Rows[i]["序號"].ToString().Trim();
                strProductNo = M_ProductNo;
                strReasonQA = dtSerialNo.Rows[i]["ReasonQA"].ToString().Trim();
                strSellingFormNumber = BLL_ERP.GetLastSellingFormNumber(M_Company, strSearialNo);
            }

            //序號項目Html
            string strItemSN = "<tr><td>{項目}</td>" +
                               "<td><input name='txtSN' type='text' jTag='txtSN' value='{序號}' style='width:120px;' /></td>" +
                               "<td><span jTag='span品號'>{品號}</span></td>" +
                               "<td><span>{ReasonQA}</span></td>" +
                               "<td><span>{銷貨單號}</span></td><tr>";

            //累加項目
            sb.Append(strItemSN.Replace("{項目}", Convert.ToString(i + 1))
                               .Replace("{序號}", strSearialNo)
                               .Replace("{品號}", strProductNo)
                               .Replace("{ReasonQA}", strReasonQA)
                               .Replace("{銷貨單號}", strSellingFormNumber));
        }
        liItems.Text = sb.ToString();
    }
}