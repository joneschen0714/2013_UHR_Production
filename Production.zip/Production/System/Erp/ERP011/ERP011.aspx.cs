﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class ERP011 : UHR.BasePage.BasePage
{
    private DataTable dtSerialNo = null;

    protected void Page_Init(object sender, EventArgs e)
    {
        repList.ItemDataBound += new RepeaterItemEventHandler(repList_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //載入公司別
        CompanyCollection c = new CompanyCollection();
        ddlCompany.DataSource = c;
        ddlCompany.DataBind();
    }

    //檢查單號是否存在
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //資料變數
            string strCompany = ddlCompany.SelectedValue; //公司別
            string strFormType = txtFormType.Text.Trim(); //單別
            string strFormNumber = txtFormNumber.Text.Trim(); //單號

            //資料清單繫結
            dtSerialNo = BLL_ERP.GetSerialData(strCompany, null, null, strFormType, strFormNumber, null, null); //序號資料
            DataTable dt = BLL_ERP.GetSellingList(strCompany, strFormType, strFormNumber);
            repList.DataSource = dt;
            repList.DataBind();

            if (dt.Rows.Count > 0)
            {
                palList.Visible = true;
                lblCustomName.Text = dt.Rows[0]["客戶名稱"].ToString();

                //匯入區域顯示
                string strCheck = dt.Rows[0]["確認碼"].ToString();
                trImport.Visible = (strCheck == "N" || dtSerialNo.Rows.Count == 0);
                //trImport.Visible = true;
            }
        }
    }

    protected void repList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView rowView = (DataRowView)e.Item.DataItem; //資料來源

            //取得控制項
            Label lblItemNo = (Label)e.Item.FindControl("lblItemNo");
            HyperLink linkProductNo = (HyperLink)e.Item.FindControl("linkProductNo");
            Label lblQty = (Label)e.Item.FindControl("lblQty");
            Label lblSerialQty = (Label)e.Item.FindControl("lblSerialQty");

            //設定值
            lblItemNo.Text = Convert.ToString(rowView["項次"]);
            linkProductNo.Text = Convert.ToString(rowView["品號"]);
            linkProductNo.Attributes.Add("onclick", string.Format("OpenItemDialog('{0}','{1}',this)", rowView["項次"], Convert.ToInt32(rowView["數量"])));
            lblQty.Text = Convert.ToInt32(rowView["數量"]).ToString();
            lblSerialQty.Text = dtSerialNo.Select("項次='" + Convert.ToString(rowView["項次"]) + "'").Length.ToString();

            //若數量不相等，用紅色註記
            if (lblQty.Text.Trim() != lblSerialQty.Text.Trim()) { lblSerialQty.Text += "　<img align='absmiddle' src='../../../images/error.png' />"; }
        }
    }

    protected void btnImport_Click(object sender, EventArgs e)
    {
        if (file.HasFile)
        {
            //資料變數
            string strCompany = ddlCompany.SelectedValue; //公司別
            string strFormType = txtFormType.Text.Trim(); //單別
            string strFormNumber = txtFormNumber.Text.Trim(); //單號

            //上傳檔案
            string strFileName = "ERP011.csv";
            string strPath = Server.MapPath("~/Temp/");
            file.SaveAs(strPath + strFileName);

            DataTable dt = BLL_ERP.GetSellingList(strCompany, strFormType, strFormNumber); //取得單據內容
            DataTable dtCSV = Tool.GetDataSetFromCSV(strPath, strFileName); //取得上傳檔案內容

            //循序檢查品號的數量是否符合
            string strMessage = "";
            DataTable dtProductNo = dtCSV.DefaultView.ToTable(true, "品號"); //取出檔案內容不重複的品號
            foreach (DataRow row in dtProductNo.Rows)
            {
                int iSerialNoCount = dtCSV.Select("品號='" + row["品號"].ToString() + "'").Length; //檔案內容序號數量

                int iProductNoQty = 0;
                DataRow[] rows = dt.Select("品號='" + row["品號"].ToString() + "'");
                foreach (DataRow rowFormItem in rows)
                    iProductNoQty += Convert.ToInt32(rowFormItem["數量"]); //品號的出貨數量

                if (iSerialNoCount != iProductNoQty) { strMessage += row["品號"].ToString() + "數量為" + iProductNoQty.ToString() + ", 序號數量為" + iSerialNoCount.ToString() + ", 數量不符!<br />"; }
            }

            //顯示數量不符訊息
            if (strMessage != "")
            {
                MessageInfo.ShowMessage(false, strMessage);
            }
            else
            {
                BLL_ERP.DeleteSerialNo(strCompany, null, null, null, strFormType, strFormNumber, null, null); //刪除此單據的品號記錄

                foreach (DataRow row in dt.Rows)
                {
                    //資料參數
                    string strProductNo = row["品號"].ToString();
                    int iQty = Convert.ToInt32(row["數量"]);
                    string strItemNo = row["項次"].ToString().PadLeft(4, '0');

                    //取出此品號的序號資料
                    DataRow[] rowsSerialNo = dtCSV.Select("品號='" + strProductNo + "'");

                    if (rowsSerialNo.Length > 0)
                        for (int i = (iQty - 1); i >= 0; i--)
                        {
                            DataRow rowSerialNo = rowsSerialNo[i];

                            string strSerialNo = rowSerialNo["序號"].ToString();
                            int iResult = BLL_ERP.ModifySerialNo(strCompany, strProductNo, strSerialNo, null, null, "銷貨單", strFormType, strFormNumber, strItemNo, null, null, null);

                            if (iResult <= 0) { strMessage += strSerialNo + "寫入錯誤!<br/>"; }
                            else { dtCSV.Rows.Remove(rowSerialNo); }
                        }
                }

                if (strMessage != "") { MessageInfo.ShowMessage(false, strMessage); }
                else
                {
                    btnQuery_Click(sender, e);
                    MessageInfo.ShowMessage(true, "作業成功，請再次確認品號數量與序號數量符合!");
                }
            }
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        //資料變數
        string strCompany = ddlCompany.SelectedValue; //公司別
        string strFormType = txtFormType.Text.Trim(); //單別
        string strFormNumber = txtFormNumber.Text.Trim(); //單號

        //檔案路徑設定
        string strPath = "/Temp/";
        string strFile = "ExportData.csv";
        string strFilePath = Server.MapPath("~" + strPath + strFile);

        //匯出CSV檔
        DataTable dtList = BLL_ERP.ExportSellingData(strCompany, strFormType, strFormNumber);

        Tool.DataTableToCSV(dtList, strFilePath);
        Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
    }
}