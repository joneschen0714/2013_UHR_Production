﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Linq;
using UHR;
using UHR.Util;

public partial class ERP023 : UHR.BasePage.BasePage
{
    //查詢事件
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        //是否驗証成功
        if (Page.IsValid)
        {
            //LINQ-取得各月份的出貨數與RMA數
            var grouped = from row in GetRMADataTable.AsEnumerable()
                          group row by row["銷貨年月"] into g
                          orderby g.Key
                          select new
                          {
                              銷貨月份 = g.Key,
                              出貨數 = g.Count(),
                              RMA數 = (from row2 in g where row2["RMA單號"].ToString() != "" select row2).Count()
                          };

            //循序顯示結果
            foreach (var group in grouped)
            {
                //RMA率
                decimal dRate = 0;
                if (group.出貨數 > 0)
                    dRate = (Convert.ToDecimal(group.RMA數) / Convert.ToDecimal(group.出貨數));

                liItems.Text += "<tr/>" +
                                  "<td>" + group.銷貨月份 + "</td>" +
                                  "<td>" + group.出貨數 + "</td>" +
                                  "<td>" + group.RMA數 + "</td>" +
                                  "<td>" + dRate.ToString("P") + "</td>" +
                               "</tr>";
            }
        }
        else
        {
            return;
        }
    }

    //匯出事件
    protected void btnExport_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            //檔案路徑設定
            string strPath = "/Temp/";
            string strFile = "ExportData.csv";
            string strFilePath = Server.MapPath("~" + strPath + strFile);

            Tool.DataTableToCSV(GetRMADataTable, strFilePath);
            Response.Redirect("~/controls/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
        }
    }

    private DataTable GetRMADataTable
    {
        get
        {
            //控制項值
            string S出貨期間 = txtSellingDate1.Text.ToUpper().Trim();
            string E出貨期間 = txtSellingDate2.Text.ToUpper().Trim();
            string 品號 = txtPartNumber.Text.ToUpper().Trim();

            DataTable dt = BLL_ERP.ExportMonthRMARateData(null, null, S出貨期間, E出貨期間, 品號);
            return dt;
        }
    }
}