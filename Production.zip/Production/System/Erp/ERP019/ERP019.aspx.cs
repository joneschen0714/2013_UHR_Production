﻿ using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using UHR;
using UHR.Util;

public partial class ERP019 : UHR.BasePage.BasePage
{
    //查詢事件
    protected void btnQuery_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            DataSet ds = GetRMADataSet;

            //循序讀取品號清單
            int totalSell = 0, totalRma = 0;
            foreach (DataRow row in ds.Tables["Summary"].Rows)
            {
                //變數值
                string strPartNo = row["品號"].ToString();
                int SellQty = Convert.ToInt32(row["出貨數"]);
                int RmaQty = Convert.ToInt32(row["RMA數"]);
                decimal dRate = 0;

                //RMA率
                if (SellQty > 0)
                    dRate = (Convert.ToDecimal(RmaQty) / Convert.ToDecimal(SellQty));

                //累加顯示訊息
                liChart.Text += "<tr><td>{品號}</td><td>{出貨數}</td><td>{RMA數}</td><td>{RMA率}</td></tr>"
                                .Replace("{品號}", strPartNo)
                                .Replace("{出貨數}", SellQty.ToString())
                                .Replace("{RMA數}", RmaQty.ToString())
                                .Replace("{RMA率}", dRate.ToString("P"));

                //累加總數
                totalSell += SellQty;
                totalRma += RmaQty;
            }

            liTotal.Text = "<tr><td colspan='4'>總出貨數:{總出貨數}　　　　　總RMA數:{總RMA數}<br/><hr></td></tr>"
                           .Replace("{總出貨數}", totalSell.ToString())
                           .Replace("{總RMA數}", totalRma.ToString());
        }
    }

    //匯出事件
    protected void btnExport_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            DataSet ds = GetRMADataSet;

            //RMA-檔案路徑設定
            string strPath = "/Temp/";
            string strFile = "RMAData.csv";
            string strFilePath = Server.MapPath("~" + strPath + strFile);
            Tool.DataTableToCSV(ds.Tables["RMA"], strFilePath);

            //銷貨-檔案路徑設定
            string strFile1 = "SellData.csv";
            string strFilePath1 = Server.MapPath("~" + strPath + strFile1);
            Tool.DataTableToCSV(ds.Tables["Sell"], strFilePath1);

            //銷貨-檔案路徑設定
            string strFile2 = "Summary.csv";
            string strFilePath2 = Server.MapPath("~" + strPath + strFile2);
            Tool.DataTableToCSV(ds.Tables["Summary"], strFilePath2);

            //壓縮檔案
            List<string> fileList = new List<string>();
            fileList.Add(strFilePath);
            fileList.Add(strFilePath1);
            fileList.Add(strFilePath2);
            Tool.Zip(fileList, Server.MapPath("~/Temp/RMAZip.zip"), 5, 5);

            //刪除暫存檔
            System.IO.File.Delete(strFilePath);
            System.IO.File.Delete(strFilePath1);
            System.IO.File.Delete(strFilePath2);

            //下載壓縮檔
            Response.Redirect("~/Temp/RMAZip.zip");
        }
    }

    private DataSet GetRMADataSet
    {
        get
        {
            //控制項值
            string S製造期間 = txtDate1.Text.ToUpper().Trim();
            string E製造期間 = txtDate2.Text.ToUpper().Trim();
            string S出貨期間 = txtSellingDate1.Text.ToUpper().Trim();
            string E出貨期間 = txtSellingDate2.Text.ToUpper().Trim();
            string S借入期間 = txtInDate1.Text.ToUpper().Trim();
            string E借入期間 = txtInDate2.Text.ToUpper().Trim();
            string 品號 = txtPartNumber.Text.ToUpper().Trim();
            string 版次 = txtVersion.Text.ToUpper().Trim();
            string 客戶代號 = txtCustomNum.Text.ToUpper().Trim();

            DataSet ds = BLL_ERP.ExportRMARateData(S製造期間, E製造期間, S出貨期間, E出貨期間, S借入期間, E借入期間, 品號, 版次, 客戶代號);
            return ds;
        }
    }
}