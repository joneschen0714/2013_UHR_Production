﻿function fn_WindowOpen(url, name, width, height)
{
    var args = (height != 0 ? ",height="+ height : "");
	    args += (width != 0 ? ",width="+ width : "");

    window.open(url, name, 'modal=yes,resizable=yes,scrollbars=yes,location=no,status=yes,menubar=no'+ args);
}

//Dialog鎖定開窗
function fn_openThisWindowDialog(path, width, height)
{
	var args = (height != 0 ? "dialogHeight:"+ height +"px;" : "");
	args += (width != 0 ? "dialogWidth:"+ width +"px;" : "");

	window.showModalDialog(path, self, 'status:no;resizable:yes;center:yes;'+ args);
}

function fn_openWindowDialog(DialogPath, Path, Title, Width, Height)
{
    //日期
    var myDate = new Date();            //建立一個 myDate 日期物件用來存放取得的現在日期時間 
    var H = new String(myDate.getHours());          //取得現在時間的時 
    var M = new String(myDate.getMinutes());        //取得現在時間的分 
    var S = new String(myDate.getSeconds());        //取得現在時間的秒 
    var target = H + "-" + M + "-" + S;

    //加入標記
    if (Path.indexOf("?") != -1) { Path += "&timer=" + target; }
    else { Path += "?timer=" + target; }

    //參數物件
    var obj = new Object();
    obj.window = window;
    obj.title = Title;
    obj.path = Path;
    obj.width = Width;

    var condition = "";
    if(Width != null) condition += "dialogWidth:"+ Width + "px;";
    if(Height != null) condition += "dialogHeight:"+ Height + "px;";

    window.showModalDialog(DialogPath, obj, "status:no;resizable:yes;center:yes;"+ condition);
}

//關閉視窗
function WindowClose() {
    parent.window.close();
}