function showHide(id) {

    var node_all = document.getElementById("tree").getElementsByTagName("A");
    var el = document.getElementById(id);
    var bExpand = true;
    var images = el.getElementsByTagName("IMG");
    if (images[0].src.indexOf("file.gif") != -1) {
        bExpand = false;
        images[0].src = "images/folder_closed.gif";
    } else {
        images[0].src = "images/folder_open.gif";
    }
    var subs = el.lastChild;
    var node_a = el.getElementsByTagName("A");
    if (bExpand) {
        subs.style.display = "block";
    } else {
        subs.style.display = "none";
    }
}

function checkStyle(id) {
    var check = document.getElementById(id);
    arrayA = check.getElementsByTagName("A");
    arrayA[0].style.color = "#890000";
    if (id == '1') {
        showHide('4');
    } else if (id == '3') {
        showHide('4');
    } else {
        showHide(id);
    }
}
