function FlashPicture(imgdiv,c){
	var p = new CFlashPicture(imgdiv,c);
	p.setAuto();
}

function CFlashPicture(flash,n,imgdiv,c) {
flash.img=imgdiv.getElementsByTagName("div");
flash.auto;
flash.now=1;
flash.def=0;
flash.speed=10000;
flash.count = c;
flash.name = n;
for(var i=0;i<flash.count;i++){
	flash.img[i].style.display = "none";
	flash.img[i].onmouseover = function(){flash.clearAuto()}
	flash.img[i].onmouseout = function(){flash.setAuto()}
}

flash.img[flash.def].style.display = "block";


flash.setImg = function (v){	
	try{
		with (bimg){
			filters[0].Apply(); 
			for(var i=0;i<flash.count;i++){
				flash.img[i].style.display = 'none';	
			}	
			flash.img[v].style.display = 'block';
			filters[0].play(); 	
		}
	}
	catch(e){		
		for(var i=0;i<flash.count;i++){
			flash.img[i].style.display = 'none';	
		}			
		flash.img[v].style.display = 'block';
	}
}

flash.changeBar = function (v){
	flash.setImg(v);
	flash.now= v+1;
} 

flash.setChange = function (){
	if(flash.now<flash.count){
		flash.changeBar(flash.now);		
		}
	else{
		flash.now = 0;
		flash.changeBar(flash.now);
	}
}
flash.setAuto = function() {
	flash.auto = setInterval(flash.name + '.setChange()', flash.speed)}

flash.clearAuto = function (){
	clearInterval(flash.auto)}

return flash;
}

function ShowAdobeFlash(url, width, height, mode) {   
 var arr = new Array();   
 var str="";   
 arr.push("<object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"" + width + "\" height=\"" + height + "\"> ");   
 arr.push("<param name=\"movie\" value=\"" + url + "\">");   
 arr.push("<param name=\"quality\" value=\"high\"> ");   
 if (mode) {   
  arr.push("<param name=\"wmode\" value=\"transparent\">");   
 }   
 arr.push("<param name=\"menu\" value=\"false\">");   
 arr.push("<embed src=\"" + url + "\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"" + width + "\" height=\"" + height + "\"></embed>");   
 arr.push("</object>");   
 str = arr.join("");   
document.write(str);
}