
/******************************************************/
//前端檢核函式
//最後更新者：Steve Lee, guoyang
//最後更新日：2005/8/1
/******************************************************/

//定義發生錯誤時欄位所顯示之顏色
var pub_err_bakground = "#FF9966";
var pub_begin_background = "#FFFFFF";
function chk_Clear(obj) {
	for (n = 0; n < obj.all.length; n++) {
		if (obj.all[n].type == "text" || obj.all[n].type == "password" || obj.all[n].type == "file" || obj.all[n].type == "textarea" || (obj.all[n].type == "button" && obj.all[n].className != "PageTable-button")) {
			obj.all[n].style.background = pub_begin_background;
		}
	}
}
function chk_Blur(obj) {
	for (n = 0; n < obj.all.length; n++) {
		if (obj.all[n].name == document.activeElement.name) {
		} else {
			if (obj.all[n].type == "text" || obj.all[n].type == "password" || obj.all[n].type == "file" || obj.all[n].type == "textarea" || (obj.all[n].type == "button" && obj.all[n].className != "PageTable-button")) {
				obj.all[n].style.background = pub_begin_background;
			}
		}
	}
}



//由每個畫面所呼叫之檢核
function chkMulitSubmit(arrObj_ck, arrObj_cn,obj_Message) {
	var flag = false;
	var chkFlag = false;
	if (arrObj_ck[0] != "1") {
	    for (var i = 0; i < arrObj_ck.length; i++) {
	        if (event.srcElement.id == arrObj_ck[i]) {
	            chkFlag = true;
	            break;
	        }
	    }
	    if (chkFlag) {
	        var arrObj = new Array(1);
	        arrObj[0] = new Array(event.srcElement, ["Chk"]);
	        for (var i = 0; i < arrObj.length; i++) {
	            flag = CheckInput_Main(arrObj[i][0], arrObj[i][1]);
	            if (!flag) {
	                return false;
	            }
	        }
	    }
	}
	var message = "";
	var obj;
    if (!chkFlag) {
        if (arrObj_cn.length != 0) {
            for (var i = 0; i < arrObj_cn.length; i++) {
                flag = CheckInput_Main_MSN(arrObj_cn[i][0], arrObj_cn[i][1], arrObj_cn[i][2]);
                if (flag != "") {
                    //return false;
                    obj = arrObj_cn[i][0].parentElement.previousSibling;
                    if (obj != null)
                        flag = obj.innerText.replace('*','') + flag;
                        
                    if (message == "")
                        message = flag;
                    else
                        message += "<br />" + flag;
                }
            }
            if (message != "") {
                //alert(message);
                obj_Message.style.display = "inline";
                obj_Message.innerHTML = "<h3>Error</h3><p>" + message + "</p>";
                return false;
            }
        } else {
            return true;
        }
    }
	return true;
}
    
    

//檢查（Single Event）
function CheckInput_Main(objO, arrA) {
	if (objO.type != null && objO.type != undefined) {
		objO.value = Function_TrimLeft(objO.value);
		objO.value = Function_TrimRight(objO.value);
	}
	var arrILen = arrA.length;
	if (!isNaN(arrILen)) {
		for (var i = 0; i < arrILen; i++) {
			var strB = eval(arrA[i])(objO);
			if (strB) {
				event.srcElement.style.background = pub_err_bakground;
				if (objO.type == "text" || objO.type == "password" || objO.type == "file" || objO.type == "textarea") {
					objO.style.background = pub_err_bakground;
					objO.select();
				}
				if (objO.type == "select-one") {
					objO.style.background = pub_err_bakground;
				}
				alert(strB);
				return false;
			}
		}
	} else {
		var strB;
		if (objO.type == "password") {
			strB = chkPwd(objO, arrA);
		} else {
			strB = chkDateSE(objO, arrA);
		}
		if (strB) {
			//objO.select();
			event.srcElement.style.background = pub_err_bakground;
			alert(strB);
			return false;
		}
	}
	return true;
}
function IP(objO) {
	return CheckInput_CheckIP(objO);
}
function MonY(objO) {
	return CheckInput_CheckMoney(objO);
}
function Nul(objO) {
	return CheckInput_CheckNull(objO);
}
function Mal(objO) {
	return CheckInput_CheckMailAddress(objO);
}
function Num(objO) {
	return CheckInput_CheckInteger(objO);
}
function Flo(objO) {
	return CheckInput_CheckFloat(objO);
}
function Dat(objO) {
	return CheckInput_DateFormat(objO);
}
function Crd(objO) {
	return CheckInput_checkCrd(objO);
}
function chkDateSE(objO1, objO2) {
	return CheckInput_CheckDateSE(objO1, objO2);
}
function chkPwd(objO1, objO2) {
	return CheckInput_CheckTwoFieldPwd(objO1, objO2);
}
function Pid(objO) {
	return fnIDChecker(objO);
}
function Pwd(objO) {
	return CheckInput_CheckPwdType(objO);
}
function Mon(objO) {
	return CheckInput_DateFormat1(objO);
}

//檢查是否為數字********************************************************
function CheckInput_CheckInteger(objO) {
	if (isNaN(objO.value)) {
		return "\u6b64\u6b04\u5fc5\u9808\u662f\u6578\u5b57\uff01";
	} else {
		return false;
	}
}
//檢查是否為浮點形********************************************************
function CheckInput_CheckFloat(objO) {
	var patrn = /^\d{1,4}(\.\d{1,2})?$/;
	if (!patrn.test(objO.value)) {
		return ("\u6b64\u6b04\u5fc5\u9808\u662f\u6578\u5b57\u4e14\u6700\u591a\u5169\u4f4d\u5c0f\u6578\uff01");
	} else {
		return false;
	}
}
//檢查是否為mail標準格式********************************************************
function CheckInput_CheckMailAddress(objO) {
	if (objO.value != "") {
		if (objO.value.indexOf("@", 0) == -1 || objO.value.indexOf(".", 0) == -1) {
			return "\u932f\u8aa4\u7684mail\u683c\u5f0f\uff01";
		} else {
			return false;
		}
	}
}

//檢查是否空值********************************************************
function CheckInput_CheckNull(objO) {
	var uiControl;
	uiControl = Trim(objO.value).replace(/[\s　]+/g, "");    // s & 全形空白
//	if(Trim(objO.value)==null || Trim(objO.value)==""){
	if (uiControl == null || uiControl == "") {		// 2006-02-21 update by oli 
		return "\u6b64\u6b04\u4f4d\u4e0d\u53ef\u7a7a\u503c\uff01";
	} else {
		return false;
	}
}
function CheckInput_CheckIP(objO) {
	var str = WSAddForm.txtWSIP.value;
	var count = 0;
	for (n = 0; n < str.length; n++) {
		if (str.charAt(n) == ".") {
			count++;
		}
	}
	if (count != 3) {
		return "\u932f\u8aa4\u7684IP\u683c\u5f0f\uff01";
	} else {
		arr = str.split(".");
		for (n = 0; n < arr.length; n++) {
			if (arr[n].length > 3) {
				return "\u932f\u8aa4\u7684IP\u683c\u5f0f\uff01";
				break;
			}
			if (isNaN(arr[n])) {
				return "\u932f\u8aa4\u7684IP\u683c\u5f0f\uff01";
				break;
			}
			if (arr[n] > 255) {
				return "\u932f\u8aa4\u7684IP\u683c\u5f0f\uff01";
				break;
			}
		}
	}
	return false;
}
function CheckInput_CheckMoney(objO) {
	var count = 0;
	/*修改之前有100.023這樣的金額格式，現修改為只有100的樣式
    for (n=0; n<objO.value.length; n++) {
        if(objO.value.charAt(n) == '.') {
            count ++;
        }
    }*/
	for (n = 0; n < objO.value.length; n++) {
		if (objO.value.charAt(n) == ".") {
			count = 2;
		}
	}
	if (count > 1) {
		return "\u932f\u8aa4\u7684\u91d1\u984d\u683c\u5f0f\uff01";
	} else {
		var index = objO.value.indexOf(".");
		if (index == 0 || index == objO.value.length - 1) {
			return "\u932f\u8aa4\u7684\u91d1\u984d\u683c\u5f0f\uff01";
		} else {
			index = objO.value.indexOf(".");
			var str = objO.value.substring(0, index) + objO.value.substring(index + 1, objO.value.length);
			if (isNaN(str)) {
				return "\u932f\u8aa4\u7684\u91d1\u984d\u683c\u5f0f\uff01";
			} else {
				return false;
			}
		}
	}
}


//檢查欄位是否為 0~9 或 a~z 或 A~Z"********************************************************
function CheckInput_CheckPwdType(objO) {
	var baseStr = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for (var i = 0; i < objO.value.length; i++) {
		if (baseStr.indexOf(objO.value.substr(i, 1)) == -1) {
			return "\u5bc6\u78bc\u6b04\u4f4d\u683c\u5f0f\u6709\u8aa4\uff01\n\u5fc5\u9700\uff1a0~9 \u6216 a~z \u6216 A~Z";
		}
	}
	return false;
}

//檢查兩欄位密碼是否相符********************************************************
function CheckInput_CheckTwoFieldPwd(objO1, objO2) {
	if (objO1.value == "" || objO2.value == "") {
		if (objO1.value == "") {
			objO1.style.background = "tomato";
			objO1.select();
		}
		if (objO2.value == "") {
			objO2.style.background = "tomato";
			objO2.select();
		}
		return "\u6b64\u6b04\u4e0d\u53ef\u70ba\u7a7a\u503c\uff01";
	} else {
		if (objO1.value != objO2.value) {
			objO1.style.background = "tomato";
			objO2.style.background = "tomato";
			objO2.select();
			return "\u5169\u6b04\u4f4d\u5bc6\u78bc\u4e0d\u76f8\u7b26\uff01";
		} else {
			var strS = CheckInput_CheckPwdType(objO1);
			if (strS) {
				objO1.style.background = "tomato";
				objO1.select();
				return strS;
			}
			var strS = CheckInput_CheckPwdType(objO2);
			if (strS) {
				objO2.style.background = "tomato";
				objO2.select();
				return strS;
			}
			return false;
		}
	}
}

//檢查畫面上checkbox欄位是否有勾選********************************************************
function CheckInput_ConfirmCheckBox(objO) {
	var chkflag = true;
	for (var i = 0; i < event.srcElement.form.elements.length; i++) {
		var e = event.srcElement.form.elements[i];
		if (e.type == "checkbox" && e.checked) {
			chkflag = false;
                        //return false;
		}
	}
	if (chkflag) {
		for (var i = 0; i < event.srcElement.form.elements.length; i++) {
			var e = event.srcElement.form.elements[i];
			if (e.type == "checkbox") {
				e.style.background = "tomato";
			}
		}
		return "\u8cc7\u6599\u672a\u52fe\u9078\uff01";
	}
	if (event.srcElement.value == "\u522a\u9664") {
		if (confirm("\u78ba\u8a8d\u522a\u9664\uff01")) {
			return false;
		} else {
			return "\u522a\u9664\u5df2\u53d6\u6d88\uff01";
		}
	}
	return false;
}

//將所傳入的formObj中所有的checkbox勾選起來********************************************************
function CheckInput_CheckBoxSelectAll(objF) {
	for (var i = 0; i < objF.elements.length; i++) {
		var e = objF.elements[i];
		if (e.type == "checkbox") {
			e.checked = true;
		}
	}
}

//檢查日期起迄兩欄位********************************************************
function CheckInput_CheckDateSE(objO1, objO2) {
	var startDate = "";
	var endDate = "";
	//objO1.value=Function_DeleteEscapeMark(objO1.value);
	//objO2.value=Function_DeleteEscapeMark(objO2.value);
	startDate = Function_DeleteEscapeMark(objO1.value);
	endDate = Function_DeleteEscapeMark(objO2.value);
	if (startDate != "" && endDate == "") {
		objO2.style.background = pub_err_bakground;
		objO2.select();
		return "\u6b64\u6b04\u4e0d\u53ef\u70ba\u7a7a\u503c\uff01";
	} else {
		if (startDate == "" && endDate != "") {
			objO1.style.background = pub_err_bakground;
			objO1.select();
			return "\u6b64\u6b04\u4e0d\u53ef\u70ba\u7a7a\u503c\uff01";
		} else {
			if (startDate != "" && endDate != "") {
				if (endDate < startDate) {
					objO1.style.background = pub_err_bakground;
					objO2.style.background = pub_err_bakground;
					objO1.select();
					return "\u8fc4\u65e5\u5fc5\u9700\u5927\u65bc\u8d77\u65e5\uff01";
				}
			} else {
				return false;
			}
		}
	}
}

//日期標準格式（西元年月日-YYYYMMDD）
function CheckInput_DateFormat(objO) {
	if (objO.value != "") {
		if (objO.value.length != 10) {
			return "\u65e5\u671f\u683c\u5f0f\u6709\u8aa4\uff01";
		}
	}
	if (Data_Check(objO.value, "YMD", "F")) {
		return false;
	} else {
		if (objO.value != "") {
			return "\u65e5\u671f\u683c\u5f0f\u6709\u8aa4\uff01";
		}
	}
}
/*
//日期標準格式（民國年月日-YYYYMMDD）

function CheckInput_DateFormat(objO){
	if(objO.value!=''){
		if(objO.value.length!=7){return "日期格式有誤！";}
	}
	if(Data_Check(objO.value,'YMD','')){
		return false;
	}
	else{
		if(objO.value!='')
			return "日期格式有誤！";
	}
}
*/


//檢核日期;tmpDate:日期字串,check_type:日期格式(YM/MD/YMD),editType:年表示法(西元年"F"/民國年default)
function Data_Check(tmpDate, check_type, editType) {
	var tmpYear, tmpMonth, tmpDay;
	var d = new Date();
	tmpDate = Function_DeleteEscapeMark(tmpDate);
	if (isNaN(tmpDate)) {
		return false;
	}
	if (editType == "F") {
		if (check_type == "YM") {
			tmpYear = tmpDate.substr(0, 4);
			tmpMonth = tmpDate.substr(4, 2);
			tmpDay = 1;
		} else {
			if (check_type == "MD") {
				tmpYear = d.getYear();
				tmpMonth = tmpDate.substr(0, 2);
				tmpDay = tmpDate.substr(2, 2);
			} else {
				tmpYear = tmpDate.substr(0, 4);
				tmpMonth = tmpDate.substr(4, 2);
				tmpDay = tmpDate.substr(6, 2);
			}
		}
	} else {
		if (check_type == "YM") {
			tmpYear = parseFloat(tmpDate.substr(0, 3)) + 1911;
			tmpMonth = tmpDate.substr(3, 2);
			tmpDay = 1;
		} else {
			if (check_type == "MD") {
				tmpYear = parseFloat(d.getYear());
				tmpMonth = tmpDate.substr(0, 2);
				tmpDay = tmpDate.substr(2, 2);
			} else {
				tmpYear = parseFloat(tmpDate.substr(0, 3)) + 1911;
				tmpMonth = tmpDate.substr(3, 2);
				tmpDay = tmpDate.substr(5, 2);
			}
		}
	}
	if (tmpYear < 2000) {
		tmpYear -= 1900;
	}
	var tempMonth = parseFloat(tmpMonth) - 1;
	d.setYear(tmpYear);
	d.setMonth(tempMonth);
	d.setDate(tmpDay);
	if (tmpYear == d.getYear(d.setYear(tmpYear)) && parseFloat(tmpMonth) == d.getMonth(d.setMonth(tempMonth)) + 1 && parseFloat(tmpDay) == d.getDate(d.setDate(tmpDay))) {
		return true;
	} else {
		return false;
	}
}

//信用卡檢核
function CheckInput_checkCrd(objO) {
	var arrCard = objO.value.split("\n");
	var re = / /gi;
	//var fieldID = event.srcElement.id;
	//var strCard = event.srcElement.value;
	var fx_seq = "21212121212121212";
	var fx_beg, fx_chk, fx_chr;
	var strTemp;
	var i, j, k;
	for (k = 0; k < arrCard.length; k++) {
		var strCard = arrCard[k].substring(0, 16).replace(re, "");
		var fx_len = strCard.length;
		try {
			//if (strCard.substr(0,1) >= "0" && strCard.substr(0,1) <= "3") return true; //不檢核
			if (fx_len % 2 == 0) {
				fx_beg = 1;
			} else {
				fx_beg = 2;
			}
			i = 1;
			j = fx_beg - 1;
			fx_chk = 0;
			for (i = 0; i < fx_len; i++) {
				fx_chr = parseInt(strCard.substr(i, 1)) * parseInt(fx_seq.substr(j, 1));
				if (fx_chr >= 10) {
					strTemp = fx_chr.toString();
					fx_chr = parseInt(strTemp.substr(0, 1)) + parseInt(strTemp.substr(1, 1));
				}
				fx_chk = fx_chk + fx_chr;
				j++;
			}
			if (fx_chk % 10 == 0) {
				return false;
			} else {
				//throw e;
				return "\u4fe1\u7528\u5361\u865f\u6709\u8aa4\uff01\n" + strCard;
			}
		}
		catch (e) {
		//document.all.item(fieldID).focus();
		//MessageControl_lblMsg.innerText="信用卡號有誤!!";
		}
	}
}


//檢查身分證欄位是否為正確"********************************************************
function fnIDChecker(objO) {
	var strID = objO.value;
	var Code = "";
	var str = "";
	if (strID != "") {	
    // 長度須為 10
		if (!(strID.length == 10)) {
			return "\u9577\u5ea6\u9808\u70ba 10";
		} 
    // 第一位須為 A~Z
		Code = strID.substring(0, 1).toUpperCase().charCodeAt();
		if (Code < 65 || Code > 90) {
			return "\u7b2c\u4e00\u4f4d\u9808\u70ba A~Z";
		} 
    
    // 第二位須為 1 或 2
		if (strID.substring(1, 2) != "1" && strID.substring(1, 2) != "2") {
			return "\u7b2c\u4e8c\u4f4d\u9808\u70ba 1 \u6216 2";
		}
    // 第三位以後須為數字
		if (isNaN(strID.substring(2, 10))) {
			return "\u7b2c\u4e09\u4f4d\u4ee5\u5f8c\u9808\u70ba\u6578\u5b57";
		} 
    //第一位轉換成大寫
		objO.value = strID.substring(0, 1).toUpperCase() + strID.substring(1, 10);
	}
	return false;
}

//日期標準格式（西元年月-YYYYMM）*************************************
function CheckInput_DateFormat1(objO) {
	if (objO.value != "") {
		if (objO.value.length != 6) {
			return "\u65e5\u671f\u683c\u5f0f\u6709\u8aa4\uff01";
		}
	}
	if (Data_Check(objO.value, "YM", "F")) {
		return false;
	} else {
		if (objO.value != "") {
			return "\u65e5\u671f\u683c\u5f0f\u6709\u8aa4\uff01";
		}
	}
}

//按鈕及欄位背景色恢復(20041117)"********************************************************
function resetFormColor(objF) {
	for (var i = 0; i < objF.elements.length; i++) {
		var e = objF.elements[i];
		if (e.type == "text" || e.type == "checkbox" || e.type == "radio" || e.type == "select-one" || e.type == "select-multiple") {
			e.style.background = "white";
   //alert(e.type);
		} else {
			if (e.type == "button" && e != objF.pageUp && e != objF.pageDown) {
				e.style.background = "lightgrey";
			}
		}
	}
}
 
//<input name="btnReset" id="btnReset" type="button" value="重設條件" onclick="javascript:resetFormColor(this.form);Clear()" ></font>


//清除Form上所有TextBox的頭尾空白
function trimFormTextBox(objF) {
	for (var i = 0; i < objF.elements.length; i++) {
		var e = objF.elements[i];
  
  //if(e.type=='text' || e.type=='textarea'){
  //不處理textArea
		if (e.type == "text") {
			e.value = Trim(e.value);
		}
	}
}
function Trim(s) {
  // Remove leading spaces and carriage returns
	while ((s.substring(0, 1) == " ") || (s.substring(0, 1) == "\n") || (s.substring(0, 1) == "\r")) {
		s = s.substring(1, s.length);
	}
 
  // Remove trailing spaces and carriage returns
	while ((s.substring(s.length - 1, s.length) == " ") || (s.substring(s.length - 1, s.length) == "\n") || (s.substring(s.length - 1, s.length) == "\r")) {
		s = s.substring(0, s.length - 1);
	}
	return s;
}
function MLen(obj0, para) {
	return CheckInput_CheckTextMustlength(obj0, para);
}
function CheckInput_CheckTextMustlength(obj0, length) {
	if (CheckInput_CaculateStringLength(obj0.value) != length) {
		return "\u6b64\u6b04\u4f4d\u9577\u5ea6\u4e0d\u6b63\u78ba";
	} else {
		return false;
	}
}
//Added start by MSN...

//檢察傳入的畫面元素中輸入字符數有沒有超過限制******************************************************
function Len(obj0, para) {
	return CheckInput_CheckTextLength(obj0, para);
}
//檢察傳入的畫面元素中輸入字符數有沒有超過限制******************************************************
function CheckInput_CheckTextLength(obj0, length) {
	if (CheckInput_CaculateStringLength(obj0.value) > length) {
		//return '此欄位長度超過上限';//DELETE BY WANGZHAOYANG DT:03/19
		//為了能夠提示用戶在輸入字符超長時候告知輸入超長了多少字或字節
		//ADD BY WANGZHAOYANG DT"03/19
		var allnum = parseInt(CheckInput_CaculateStringLength(obj0.value)) - parseInt(length);
		var chinanum = 0;
		chinanum = parseInt(allnum / 2);
		return "\u6b64\u6b04\u4f4d\u9577\u5ea6\u8d85\u904e\u4e0a\u9650!\n\u76ee\u524d\u8d85\u51fa" + chinanum + "\u500b\u6f22\u5b57\u6216" + allnum + "\u500b\u5b57\u5143";
	    
		//END BY
	} else {
		return false;
	}
}
//返回String長度
function CheckInput_CaculateStringLength(input) {
//by guoyang. Jul.22nd,2005.
	var length = 0;
	var reg = /^[\u0391-\uFFE5]+$/;
	while (input.length > 0) {
		var achar = input.substring(0, 1);
		if (reg.test(achar)) {
			length += 2;
		} else {
			length++;
		}
		input = input.substring(1);
	}
	return length;
}
//檢查（Single Event） 修改於2005.8.1,為了將檢核長度的功能加入到原先的js函數中去,將上部原有的js函數copy來rename,
//原先呼叫CheckInput_Main的部份按情況而定呼叫CheckInput_Main_MSN,  多增加一個傳入參數,為需要檢核的長度上限.
function CheckInput_Main_MSN(objO, arrA, para) {
	if (objO.type != undefined) {
		objO.value = Function_TrimLeft(objO.value);
		objO.value = Function_TrimRight(objO.value);
	}
	var arrILen = arrA.length;
	if (!isNaN(arrILen)) {
	    for (var i = 0; i < arrILen; i++) {
	        var strB;
	        if (("" + para != "undefined") && (arrA[i] == "Len")) {//發現檢核長度的需求,調用特殊的函數
	            strB = eval(arrA[i])(objO, para);
	        } else {
	            if (("" + para != "undefined") && (arrA[i] == "MLen")) {
	                strB = eval(arrA[i])(objO, para);
	            } else {
	                strB = eval(arrA[i])(objO);
	            }
	        }
	        return strB;
	        //			if (strB) {
	        //				event.srcElement.style.background = pub_err_bakground;
	        //				if (objO.type == "text" || objO.type == "password" || objO.type == "file" || objO.type == "textarea") {
	        //					objO.style.background = pub_err_bakground;
	        //					objO.select();
	        //				}
	        //				if (objO.type == "select-one") {
	        //					objO.style.background = pub_err_bakground;
	        //				}
	        //				//alert(strB);
	        //				//return false;
	        //				return strB;
	        //			}
	    }
	} else {
		var strB;
		if (objO.type == "password") {
			strB = chkPwd(objO, arrA);
		} else {
			strB = chkDateSE(objO, arrA);
		}
		if (strB) {
			//objO.select();
			//event.srcElement.style.background = pub_err_bakground;
			//alert(strB);
			//return false;
			return strB;
		}
	}
	return "";
}
/******************************************************/
//前端檢核函數
//最後更新者：guoyang
//最後更新日：2005/8/3
/******************************************************/
addEvent(window, "load", function () {
	//以下處理畫面的欄位的最大值問題,這一段檢查的是按英文/數字類型的長度檢核(中英數都當作1個單位長度)
	//本段是對應LengthLimitEnglishNoSpan屬性,此屬性使用時不會對畫面的<span></span>標籤採取行動
	var counts = document.getElementsNeedLimitLengthEnglishNoSpan();
	var i, count, matches, countHolder;
	for (i = 0; i < counts.length; i++) {
		count = counts[i];
		var ss = count.className.split(";");
		var maxlength = 0;
		for (var j = 0; j < ss.length; j++) {
			if (ss[j].indexOf("LengthLimitEnglishNoSpan=") > -1) {
				maxlength = ss[j].substring(25);
				break;
			}
		}
		if (isNaN(maxlength)) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176 LengthLimitEnglishNoSpan \u5c6c\u6027\u5fc5\u9808\u70ba\u6578\u5b57!");
			return;
		} else {
			if (maxlength.indexOf(".") > -1) {
				alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176 LengthLimitEnglishNoSpan \u5c6c\u6027\u5fc5\u9808\u70ba\u6574\u6578!");
				return;
			}
		}
		count.maxVal = maxlength;
		count.onkeyup = function () {
			//alert(this.value.length +'>'+ this.maxVal)
			if (this.value.length > this.maxVal) {
				this.value = this.value.substring(0, this.maxVal);
			}
		};
	}	
	//以下處理畫面的欄位的最大值問題,這一段檢查的是按中文類型的長度檢核(中文當做2個單位,英文數字當作1個單位長度)
	//本段是對應LengthLimitChineseNoSpan屬性,此屬性使用時不會對畫面的<span></span>標籤採取行動
	counts = document.getElementsNeedLimitLengthChineseNoSpan();
	//var i, count, matches, countHolder;
	for (i = 0; i < counts.length; i++) {
		count = counts[i];	
		//alert(count)
		var ss = count.className.split(";");
		var maxlength = 0;
		for (var j = 0; j < ss.length; j++) {
			if (ss[j].indexOf("LengthLimitChineseNoSpan=") > -1) {
				maxlength = ss[j].substring(25);
				break;
			}
		}
		if (isNaN(maxlength)) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176 LengthLimitChineseNoSpan \u5c6c\u6027\u5fc5\u9808\u70ba\u6578\u5b57!");
			return;
		} else {
			if (maxlength.indexOf(".") > -1) {
				alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176 LengthLimitChineseNoSpan \u5c6c\u6027\u5fc5\u9808\u70ba\u6574\u6578!");
				return;
			}
		}
		count.maxVal = maxlength;
		count.onkeyup = function () {
			//alert(CheckInput_CaculateStringLength(this.value)+','+this.maxVal);
			if (CheckInput_CaculateStringLength(this.value) > this.maxVal) {
				//alert('this.value='+this.value+'nacceptmaxnum='+acceptmaxnum)
				var acceptmaxnum = 0;
				for (var number = 0; number < this.value.length; number++) {
					if (CheckInput_CaculateStringLength(this.value.substring(0, number)) <= this.maxVal) {
						if (CheckInput_CaculateStringLength(this.value.substring(0, number + 1)) > this.maxVal) {
							acceptmaxnum = number;
							break;
						}
					}
				}
				this.value = this.value.substring(0, acceptmaxnum);
			}
		};
	}	

	//以下處理畫面的欄位的最大值問題,這一段檢查的是按英文/數字類型的長度檢核(中英數都當作1個單位長度)
	//本段是對應LengthLimitEnglishSpan屬性,此屬性使用時必須有對應的用來顯示剩餘字數的同名的<span></span>
	counts = document.getElementsNeedLimitLengthEnglishSpan();
	//var i, count, matches, countHolder;
	for (i = 0; i < counts.length; i++) {
		count = counts[i];
		var ss = count.className.split(";");
		var maxlength = 0;
		for (var j = 0; j < ss.length; j++) {
			if (ss[j].indexOf("LengthLimitEnglishSpan=") > -1) {
				maxlength = ss[j].substring(23);
				break;
			}
		}
		if (isNaN(maxlength)) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176LengthLimitEnglishSpan\u5c6c\u6027\u5fc5\u9808\u70ba\u6578\u5b57!");
			return;
		} else {
			if (maxlength.indexOf(".") > -1) {
				alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176LengthLimitEnglishSpan\u5c6c\u6027\u5fc5\u9808\u70ba\u6574\u6578!");
				return;
			}
		}
		count.maxVal = maxlength;
		count.holder = document.getElementById("" + count.name);
		var hasspan = ("" + count.holder.type) == "undefined";//判斷是否存在此<span>
		if (!hasspan) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176LengthLimitEnglishSpan\u6642\u5fc5\u9808\u6709\u540cid\u7684<span></span>!");
			return;
		}
		if (count.holder) {
			if (hasspan) {//存在此<span>
			}
			count.holder.innerHTML = count.maxVal - count.value.length;
			count.onkeyup = function () {
				if (this.value.length > this.maxVal) {
					this.value = this.value.substring(0, this.maxVal);
				}
				if (hasspan) {////存在此<span>
				}
				this.holder.innerHTML = this.maxVal - this.value.length;
			};
		}
	}	
	//以下處理畫面的欄位的最大值問題,這一段檢查的是按中文類型的長度檢核(中文當做2個單位,英文數字當作1個單位長度)
	//本段是對應 LengthLimitChineseSpan 屬性,此屬性使用時必須有對應的用來顯示剩餘字數的同名的<span></span>
	counts = document.getElementsNeedLimitLengthChineseSpan();
	//var i, count, matches, countHolder;
	for (i = 0; i < counts.length; i++) {
		count = counts[i];
		var ss = count.className.split(";");
		var maxlength = 0;
		for (var j = 0; j < ss.length; j++) {
			if (ss[j].indexOf("LengthLimitChineseSpan=") > -1) {
				maxlength = ss[j].substring(23);
				break;
			}
		}
		if (isNaN(maxlength)) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176LengthLimitChineseSpan\u5c6c\u6027\u5fc5\u9808\u70ba\u6578\u5b57!");
			return;
		} else {
			if (maxlength.indexOf(".") > -1) {
				alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176LengthLimitChineseSpan\u5c6c\u6027\u5fc5\u9808\u70ba\u6574\u6578!");
				return;
			}
		}
		count.maxVal = maxlength;
		count.holder = document.getElementById("" + count.name);
		var hasspan = ("" + count.holder.type) == "undefined";//判斷是否存在此<span>
		//alert(hasspan)
		if (!hasspan) {
			alert("\u756b\u9762\u683c\u5f0f\u932f\u8aa4.\n\u932f\u8aa4\u5143\u7d20\u70ba:" + count.name + ",\u5176 LengthLimitChineseSpan \u6642\u5fc5\u9808\u6709\u540cid\u7684<span></span>!");
			return;
		}
		if (count.holder) {
			if (hasspan) {//存在此<span>
			}
			count.holder.innerHTML = count.maxVal - CheckInput_CaculateStringLength(count.value);
			count.onkeyup = function () {
				//alert(CheckInput_CaculateStringLength(this.value)+','+this.maxVal);
				if (CheckInput_CaculateStringLength(this.value) > this.maxVal) {
					//alert('this.value='+this.value+'nacceptmaxnum='+acceptmaxnum)
					var acceptmaxnum = 0;
					for (var number = 0; number < this.value.length; number++) {
						if (CheckInput_CaculateStringLength(this.value.substring(0, number)) <= this.maxVal) {
							if (CheckInput_CaculateStringLength(this.value.substring(0, number + 1)) > this.maxVal) {
								acceptmaxnum = number;
								break;
							}
						}
					}
					this.value = this.value.substring(0, acceptmaxnum);
				}
				if (hasspan) {//存在此<span>
				}
				this.holder.innerHTML = this.maxVal - CheckInput_CaculateStringLength(this.value);
			};
		}
	}
});
document.getElementsNeedLimitLengthEnglishNoSpan = function () {
	var my_array = document.getElementsByTagName("*");
	var retvalue = new Array();
	var i;
	var j;
	for (i = 0, j = 0; i < my_array.length; i++) {
		var theclassname = "" + my_array[i].className;
		var reg = /LengthLimitEnglishNoSpan=/;
		if (reg.test(theclassname)) {
			retvalue[j++] = my_array[i];
		}
	}
	return retvalue;
};
document.getElementsNeedLimitLengthChineseNoSpan = function () {
	var my_array = document.getElementsByTagName("*");
	var retvalue = new Array();
	var i;
	var j;
	for (i = 0, j = 0; i < my_array.length; i++) {
		var theclassname = "" + my_array[i].className;
		var reg = /LengthLimitChineseNoSpan=/;
		if (reg.test(theclassname)) {
			retvalue[j++] = my_array[i];
		}
	}
	return retvalue;
};
function addEvent(obj, evType, fn) {
	if (obj.addEventListener) {
		obj.addEventListener(evType, fn, true);
		return true;
	} else {
		if (obj.attachEvent) {
			var r = obj.attachEvent("on" + evType, fn);
			return r;
		} else {
			return false;
		}
	}
}
document.getElementsNeedLimitLengthEnglishSpan = function () {
	var my_array = document.getElementsByTagName("*");
	var retvalue = new Array();
	var i;
	var j;
	for (i = 0, j = 0; i < my_array.length; i++) {
		var theclassname = "" + my_array[i].className;
		var reg = /LengthLimitEnglishSpan=/;
		if (reg.test(theclassname)) {
			retvalue[j++] = my_array[i];
		}
	}
	return retvalue;
};
document.getElementsNeedLimitLengthChineseSpan = function () {
	var my_array = document.getElementsByTagName("*");
	var retvalue = new Array();
	var i;
	var j;
	for (i = 0, j = 0; i < my_array.length; i++) {
		var theclassname = "" + my_array[i].className;
		var reg = /LengthLimitChineseSpan=/;
		if (reg.test(theclassname)) {
			retvalue[j++] = my_array[i];
		}
	}
	return retvalue;
};

//返回String中所含有的中文字數
function MSN_CaculateChineseCharacter(input) {
	var num = 0;
	var reg = /^[\u0391-\uFFE5]+$/;
	while (input.length > 0) {
		var achar = input.substring(0, 1);
		if (reg.test(achar)) {
			num++;
		}
		input = input.substring(1);
	}
	return num;
}
//將元素的鼠標樣式改成手狀:
function MSN_ChangeStateToHand(obj) {
	obj.style.cursor = "hand";
}

//檢查是否為負數********************************************************
function Pos(objO) {
	return CheckInput_CheckNotNegative(objO);
}

//檢查是否為負數********************************************************
function CheckInput_CheckNotNegative(objO) {
	if (isNaN(objO.value)) {
		return "\u6b64\u6b04\u4f4d\u5fc5\u9808\u70ba\u6578\u5b57!";
	} else {
		if (("" + objO.value).indexOf("-") > -1) {
			return "\u6b64\u6b04\u4f4d\u4e0d\u80fd\u70ba\u8ca0\u6578!";
		} else {
			return false;
		}
	}
}

//去除字串符號********************************************************
function Function_TrimMark(tmpString, strMark) {
	var i = tmpString.length;
	var e_string = "";
	var z = strMark.length;
	var flag = false;
	for (var j = 0; j < i; j++) {
		flag = false;
		for (var k = 0; k < z; k++) {
			if (tmpString.substr(j, 1) == strMark.substr(k, 1)) {
				flag = true;
				break;
			}
		}
		if (!flag) {
			e_string += tmpString.substr(j, 1);
		}
	}
	return e_string;
}



//去除字串多餘的符號********************************************************
function Function_DeleteEscapeMark(tmpString) {
	var i = tmpString.length;
	var e_string = "";
	for (var j = 0; j < i; j++) {
		if (tmpString.substr(j, 1) == "." || tmpString.substr(j, 1) == "," || tmpString.substr(j, 1) == "+" || tmpString.substr(j, 1) == "-" || tmpString.substr(j, 1) == "/" || tmpString.substr(j, 1) == " " || tmpString.substr(j, 1) == ":" || tmpString.substr(j, 1) == "'" || tmpString.substr(j, 1) == "=") {
		} else {
			e_string += tmpString.substr(j, 1);
		}
	}
	return e_string;
}


//去除空白字串********************************************************
function Function_Trim(str) {
	return Function_TrimRight(Function_TrimLeft(str));
}


//去除左空白字串********************************************************
function Function_TrimLeft(originalStr) {
	//var originalStr = new String(this);
	var newStr = originalStr;
	var len = originalStr.length;
	var x = 0;
	while (x < len) {
		if (newStr.charAt(0) == " ") {
			var newStr = newStr.substring(1, len);
		}
		x++;
	}
	return newStr;
}



//去除右空白字串********************************************************
function Function_TrimRight(originalStr) {
	//var originalStr = new String(this);
	var newStr = originalStr;
	var len = originalStr.length;
	var x = len;
	while (x > 0) {
		if (newStr.charAt(x - 1) == " ") {
			var newStr = newStr.substring(0, x - 1);
			x--;
		} else {
			break;
		}
	}
	return newStr;
}
/*
  提交前鎖定按鈕，radio
*/
function lockButton() {
	var i = 0;
	if (document.forms == null) {
		return;
	}
	for (i = 0; i < document.forms[0].all.length; i++) {
		var tempobj = document.forms[0].all[i];
		if (tempobj.type != null && (tempobj.type == "button" || tempobj.tagName == "SELECT")) {
			tempobj.disabled = true;
		}
		if (tempobj.type != null && (tempobj.type == "text")) {
			tempobj.readOnly = true;
		}
	}
}
//Added end by MSN...
/**

將傳入的字符串轉換為***,***.**格式
*/
function getFormatMoney(str) {
	if (str == null || "" == (str)) {
		return "0";
	}
	var re = / /g;             // 创建正则表达式模式。
	str = str.replace(re, "");
	var str1 = str.split(".")[0];
	var i = 0;
	var list = new Array();
	var j = 0;
	while (str1.length > 3) {
		list[j] = (str1.substring(str1.length - 3, str1.length));
		str1 = str1.substring(0, str1.length - 3);
		j++;
	}
	if (str1.length > 0) {
		list[j] = (str1);
	}
	i = list.length - 1;
	var str2 = "";
	while (i > -1) {
		if (i != 0) {
			str2 += (list[i] + ",");
		} else {
			str2 += (list[i]);
		}
		i--;
	}
	if (str.split(".").length > 1) {
		str2 += "." + str.split(".")[1];
	}
	return (str2);
}

