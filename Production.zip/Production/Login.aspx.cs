﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;
using UHR.Authority;

public partial class Manage_Login : Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (UserInfo.Exists)
            {
                Response.Redirect("ManageMain.aspx");
            }
            else
            {
                txtEmail.Text = ProductionAccount; //取回上次登入的帳號
            }
        }
    }

    protected void login_Click(object sender, EventArgs e)
    {
        string Account = this.txtEmail.Text.Trim();
        string PassWord = this.txtPassword.Text.Trim();

        if (Account == "" || PassWord.Trim() == "")
        {
            lblMessage.Text = "<font color=Red>Email and Password can not empty!!</font>";
            return;
        }

        DataRow rowUser = BLL.GetUserInfo("", "", Account);
        if (rowUser != null)
        {
            //驗証密碼
            int iCompare = string.Compare(PassWord, rowUser["Password"].ToString(), true);
            if (iCompare != 0)
            {
                lblMessage.Text = "<font color=Red>Password is error!</font>";
                return;
            }

            //是否鎖定
            string strIsLock = rowUser["IsLock"].ToString();
            if (!"0".Equals(strIsLock))
            {
                lblMessage.Text = "<font color=Red>You have been locked!</font>";
                return;
            }

            //設定UserInfo物件
            UserInfo ui = new UserInfo(rowUser["ID"], rowUser["Email"], rowUser["Account"], rowUser["DutyID"], rowUser["FirstName"], rowUser["LastName"], rowUser["GroupNumber"], rowUser["IsSuper"]);
            UserInfo.SessionState = ui;

            ProductionAccount = Account; //記錄本次的登入帳號

            //頁面轉向
            Response.Redirect("ManageMain.aspx");
        }
    }

    //記錄Cookie的上一次登入帳號
    private string ProductionAccount
    {
        set
        {
            HttpCookie cookie = new HttpCookie("ProductionAccount", value);
            cookie.Expires = DateTime.Now.AddDays(365);
            Response.Cookies.Add(cookie);
        }
        get
        {
            if (Request.Cookies["ProductionAccount"] == null)
                return "";
            else
                return Request.Cookies["ProductionAccount"].Value;
        }
    }
}
