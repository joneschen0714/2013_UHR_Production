﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NestedMasterPage : MasterPage
{
    private string query;

    public string Query
    {
        get { return query; }
        set { query = value; }
    }

    private bool isShowOther;

    public bool IsShowOther
    {
        get { return isShowOther; }
        set { isShowOther = value; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        tabMenu.Query = Query;
        tabMenu.IsShowOther = IsShowOther;
    }
}