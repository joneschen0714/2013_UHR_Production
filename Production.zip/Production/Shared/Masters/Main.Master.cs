﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Web.UI.HtmlControls;
using UHR;
using UHR.Authority;

public partial class Main : MasterPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/jQuery/jquery-1.7.1.min.js") + "'></script>"));
        Page.Header.Controls.Add(new LiteralControl("<script type='text/javascript' src='" + ResolveClientUrl("~/configuration/js/fn_WindowOpen.js") + "'></script>"));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.liName.Text = UserInfo.SessionState.FirstName + " " + UserInfo.SessionState.LastName;
        }
    }

    protected void linkLogout_Click(object sender, EventArgs e)
    {
        UserInfo.Remove();
        Session.Remove("MSNCMS_MENU"); //移除MainMenu選單
        Response.Redirect("~/login.aspx");
    }
}
